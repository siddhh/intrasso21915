<?php

$page = 'grille';
$cmdb = 'cmd_pre';
$titre_tableau = 'Calendrier prévisionnel';
$realise = false;

require 'inc/page.php';

?>
