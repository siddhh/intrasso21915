<?php

    require '../inc/.pg_connect.php';

    $mdpcrypt = crypt('sppe', CRYPT_SHA256);
    $req = 'Update utilisateurs Set uti_mdp=$1';
    $prm = array($mdpcrypt);
    pg_query_params($db, $req, $prm);
?>
