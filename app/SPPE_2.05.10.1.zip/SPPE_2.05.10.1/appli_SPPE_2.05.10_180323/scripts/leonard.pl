#!/usr/bin/perl
# leonard.pl
# 
# Application SPPE
# --------------------------------------------------------------------------------------------------
# Script de chargement des données en provenance de l'application LEONARD.
# Programme lancé par CRON. Voir crontab -l pour l'utilisateur dba.
# --------------------------------------------------------------------------------------------------
# JMD - v1.02 - 13 janvier 2015
#  - pro_timbre dans update processus
# --------------------------------------------------------------------------------------------------

use strict;
use Data::Dumper;
use DBI;
use File::Copy;
use utf8;
use XML::Simple qw(:strict);
use POSIX qw(strftime);
use Scalar::Util qw/reftype/;

no utf8;

# Chaine -------------------------------------------------------------------------------------------
# Extrait la chaîne d'un tag XML retourné par XML::Simple
# %xml = XML
# $tag = tag analysé
# --> chaîne
sub chaine {

    # ARGUMENTS ------------
    my ($xmlref, $tag) = @_;
    # ----------------------

    my %xml = %$xmlref;

    my $rc = '';

    if (exists $xml{$tag}) {
        if (ref $xml{$tag}[0] ne ref {}) {
            $rc = $xml{$tag}[0];
            $rc =~ s/^\s+//;
            $rc =~ s/\s+$//;
            utf8::encode($rc);
        }
    }

    return $rc;
}

# Validation d'une structure XML -------------------------------------------------------------------
# %xml = hachage XML
# --> code erreur ou zéro si OK
sub valideXML {

    # ARGUMENTS ------
    my ($xmlref) = @_;
    # ----------------

    my %xml = %$xmlref;

    my $erreur = 0;

    # index
    if (not exists $xml{index}) {
        $erreur = 1;
    }

    # nom du processus
    if (chaine(\%xml, 'nom') eq '') {
        $erreur = 2;
    }

    # jobs
    if (not exists $xml{jobs}) {
        $erreur = 3;
    } else {

        # Lecture des jobs ----------
        my $jobsref = $xml{jobs}[0];
        my %jobshac = %$jobsref;
        my $jobstab = $jobshac{job};
        my @jobs = @$jobstab;

        for my $jobref (@jobs) {
            my %job = %$jobref;

            # nom du job
            if (chaine(\%xml, 'nom') eq '') {
                $erreur = 4;
            }
        }
    }

    # version processus
    if (exists $xml{version}) {
        my $ver = $xml{version}[0];
        my %version = %$ver;
        if (not exists $version{index}) {
            $erreur = 5;
        }
    } else {
        $erreur = 6;
    }

    # présence d'une règle
    if (chaine(\%xml, 'reglesPlanification') eq '') {
        $erreur = 7;
    }

    return $erreur;
}

# Modification de la mise au plan ------------------------------------------------------------------
# $db = connexion à la base de données
# $pro_index = index LEONARD
sub modifPlan {

    # ARGUMENTS --------------
    my ($db, $pro_index) = @_;
    # ------------------------

    # Lecture de l'identifiant processus

    my $req = qq(SELECT pro_id FROM processus WHERE pro_index=?;);
    my $sql = $db->prepare($req);
    $sql->execute($pro_index) or die $DBI::errstr;
    my $pro_id = $sql->fetchrow_array;

    # Mettre à confirmer les mises au plan pour lesquelles il n'existe pas de réalisé

    $req = qq(  UPDATE plan SET
        		pln_confirm='f',
        		pln_timbre=current_timestamp
        		WHERE pro_id=? AND pln_confirm AND pln_fin IS NULL;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id) or die $DBI::errstr;

    # Placer le processus dans la liste des plans à recalculer pour traitement en PHP

    $req = qq(DELETE FROM recalcul WHERE pro_id=?;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id) or die $DBI::errstr;

    $req = qq(INSERT INTO recalcul values(?););
    $sql = $db->prepare($req);
    $sql->execute($pro_id) or die $DBI::errstr;
}

# Complémente le processus -------------------------------------------------------------------------
# $db = connexion à la base de données
# %xml = hachage XML
sub complemente {

    # ARGUMENTS -----------
    my ($db, $xmlref) = @_;
    # ---------------------

    my %xml = %$xmlref;

    # Lecture de l'identifiant processus
    my $req = qq(SELECT pro_id, pro_version FROM processus WHERE pro_index=?;);
    my $sql = $db->prepare($req);
    $sql->execute($xml{index}) or die $DBI::errstr;
    my $lu = $sql->fetchrow_arrayref;
    my ($pro_id, $pro_version) = @$lu;

    # Lecture des chaînes

    $req = qq(  SELECT DISTINCT c.chn_nom
        		FROM liens l
            	JOIN processus p ON p.pro_id=l.pro_id AND p.pro_version=l.pro_version
            	JOIN membrex m ON m.mbx_id=l.mbx_id
            	JOIN chaines c ON c.chn_id=m.chn_id
        		WHERE p.pro_id=?
        		AND p.pro_version=?
        		ORDER BY c.chn_nom;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id, $pro_version) or die $DBI::errstr;

    my $liste = '';

    my @lu;
    while (@lu = $sql->fetchrow_array) {
        $liste .= ($lu[0].' ');
    }

    # Écriture de la liste des chaînes

    $req = qq(DELETE FROM liste WHERE pro_id=? AND pro_version=?;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id, $pro_version) or die $DBI::errstr;

    $req = qq(INSERT INTO liste (pro_id, pro_version, lst_chaines) VALUES (?, ?, ?););
    $sql = $db->prepare($req);
    $sql->execute($pro_id, $pro_version, $liste) or die $DBI::errstr;

    # Indication de rupture

    $req = qq(  UPDATE processus SET
        		pro_rupture=(
        			(SELECT COUNT(*)
            		FROM liens l
                	JOIN processus p ON p.pro_id=l.pro_id AND p.pro_version=l.pro_version
                	JOIN membrex m ON m.mbx_id=l.mbx_id
            		WHERE p.pro_id=? AND p.pro_version=? AND m.mbx_rupture) > 0
            	)
        		WHERE pro_id=? AND pro_version=?;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id, $pro_version, $pro_id, $pro_version) or die $DBI::errstr;
}


# Création du processus ----------------------------------------------------------------------------
# $db = connexion à la base de données
# %xml = hachage XML
sub creeProcessus {

    # ARGUMENTS -----------
    my ($db, $xmlref) = @_;
    # ---------------------

    my %xml = %$xmlref;

    # Lecture du processus ----------

    my %processus = ();

    # index
    $processus{index} = $xml{index};

    # nom
    $processus{nom} = chaine($xmlref, 'nom');

    # libelle
    $processus{lib} = chaine($xmlref, 'libelle');

    # objet (apport version 1.2)
    $processus{objet} = '';
    if (exists $xml{objet}) {
        $processus{objet} = chaine($xmlref, 'objet');
        $processus{objet} =~ s/<br?\/>/ - /ig;
    }

    # début de validité
    $processus{debut} = '1900-01-01';
    my $deb = chaine($xmlref, 'debutValidite');
    if ($deb ne '') {
        $processus{debut} = $deb;
    }

    # fin de validité
    $processus{fin} = '3333-01-01';
    my $fin = chaine($xmlref, 'finValidite');
    if ($fin ne '') {
        $processus{fin} = $fin;
    }

    # règle de planification
    $processus{regle} = '';
    if (exists $xml{reglesPlanification}) {
        $processus{regle} = chaine($xmlref, 'reglesPlanification');
    }
    $processus{reglehtml} = '';
    if (exists $xml{reglesPlanificationLisible}) {
        $processus{reglehtml} = chaine($xmlref, 'reglesPlanificationLisible');
        $processus{reglehtml} =~ s/<br?\/>/ - /ig;
    }

    # suivi dans SPPE
    $processus{suivi} = 'f';
    if (exists $xml{suiviSimplifie}) {
        if ($xml{suiviSimplifie}[0] ne '0') {
            $processus{suivi} = 't';
        }
    }

    # version
    $processus{version} = '';
    $processus{libelle} = '';
    $processus{nouveautes} = '';
    if (exists $xml{version}) {
        my $ver = $xml{version}[0];
        my %version = %$ver;
        $processus{vindex} = $version{index};
        $processus{version} = chaine($ver, 'nom').' '.chaine($ver, 'creation');
        $processus{libelle} = chaine($ver, 'libelle');
        $processus{nouveautes} = chaine($ver, 'nouveautes');
    }

    # Existence du processus
    my $req = qq(SELECT pro_id, pro_regle, pro_debut, pro_fin FROM processus WHERE pro_index=?;);
    my $sql = $db->prepare($req);
    $sql->execute($processus{index}) or die $DBI::errstr;

    if (my $luref = $sql->fetchrow_hashref) {

        # Mise à jour du processus

        my %lu = %$luref;
        $req = qq(UPDATE processus SET 
					pro_nom=?,
					pro_lib=?,
					pro_objet=?,
					pro_regle=?,
            		pro_reglehtml=?,
            		pro_debut=?,
            		pro_fin=?,
            		pro_suivi=?,
            		pro_vindex=?,
            		pro_version=?,
            		pro_libelle=?,
            		pro_nouveautes=?,
            		pro_timbre=current_timestamp
            		WHERE pro_index=?;);
        $sql = $db->prepare($req);
        $sql->execute($processus{nom}, $processus{lib}, $processus{objet},
            $processus{regle}, $processus{reglehtml},
            $processus{debut}, $processus{fin}, $processus{suivi},
            $processus{vindex}, $processus{version}, $processus{libelle},
            $processus{nouveautes}, $processus{index})
            or die $DBI::errstr;

        if (($lu{pro_regle} ne $processus{regle}) or
            ($lu{pro_debut} ne $processus{debut}) or
            ($lu{pro_fin} ne $processus{fin})) {

            # Modification de la planification

            modifPlan $db, $processus{index};
        }

    } else {

        # Création du processus

        $req = qq(INSERT INTO processus
            			(pro_index, pro_nom, pro_lib, pro_objet, pro_regle, pro_reglehtml, pro_debut, pro_fin, pro_suivi, pro_vindex, pro_version, pro_libelle, pro_nouveautes)
            		values
            			(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            	);
        $sql = $db->prepare($req);
        $sql->execute($processus{index}, $processus{nom}, $processus{lib}, $processus{objet},
            $processus{regle}, $processus{reglehtml}, $processus{debut},
            $processus{fin}, $processus{suivi}, $processus{vindex},
            $processus{version}, $processus{libelle}, $processus{nouveautes})
            or die $DBI::errstr;

        # Modification de la planification

        modifPlan $db, $processus{index};
    }
}

# Création des jobs membrex ------------------------------------------------------------------------
# $db = connexion à la base de données
# $jobstab = réfécence au tableau des jobs
# $pro_index = index du processus
sub creeJobs {

    # ARGUMENTS ------------------------
    my ($db, $jobstab, $pro_index) = @_;
    # ----------------------------------

    my @jobs = @$jobstab;

    # Lecture de l'identifiant processus
    my $req = qq(select pro_id, pro_version from processus where pro_index=?;);
    my $sql = $db->prepare($req);
    $sql->execute($pro_index) or die $DBI::errstr;
    my $lu = $sql->fetchrow_arrayref;
    my ($pro_id, $pro_version) = @$lu;

    my $tous = 0;
    my $clermont = 0;
    my $marseille = 0;
    my $nantes = 0;
    my $reims = 0;
    my $nevers = 0;

    my $rang = 0;   # rang du job dans le déroulement du processus

    foreach (@jobs) {
        
        my %job = %$_;
        my %membrex = ();

        # nom
        $membrex{nom} = uc(chaine($_, 'nom'));

        # libelle
        $membrex{lib} = chaine($_, 'libelle');

        # rupture
        $membrex{rupture} = 'f';
        if (exists $job{rupture}) {
            if ($job{rupture}[0] ne '0') {
                $membrex{rupture} = 't';
            }
        }

        # domaine
        if (exists $job{domaine}) {

            $membrex{exclus} = chaine($job{domaine}[0], 'exclus');
            $membrex{inclus} = chaine($job{domaine}[0], 'inclus');
            $membrex{etendue} = chaine($job{domaine}[0], 'etendue');
            $membrex{type} = chaine($job{domaine}[0], 'type');

        } else {

            $membrex{exclus} = '';
            $membrex{inclus} = '';
            $membrex{etendue} = '';
            $membrex{type} = '';
        }

        # machine
        if (exists $job{machine}) {

            my $m = $job{machine}[0]{index};
            $membrex{mac_nom} = $job{machine}[0]{content};
            $membrex{mac_index} = $m;

            if ($m eq '7') {
                $clermont = 1;
                $marseille = 1;
                $nantes = 1;
                $reims = 1;
            } else {
                if ($m eq '1') {
                    $nantes = 1;
                } else {
                    if ($m eq '2') {
                        $clermont = 1;
                    } else {
                        if ($m eq '3') {
                            $marseille = 1;
                        } else {
                            if ($m eq 4) {
                                $reims = 1;
                            }else{
                            	if ($m eq 6){
                            		$nevers = 1;
                            	}
                            }
                        }
                    }
                }
            }

        } else {
            
            $membrex{mac_nom} = '';
            $membrex{mac_index} = 0;
        }

        # Existence du job
        $req = qq(select count(*) from membrex where mbx_nom=?;);
        $sql = $db->prepare($req);
        $sql->execute($membrex{nom}) or die $DBI::errstr;
        my $existe = $sql->fetchrow_array;

        if ($existe) {

            # Mise à jour du membrex

            $req = qq(update membrex set mbx_lib=?, mbx_rupture=?,
                mbx_exclus=?, mbx_inclus=?, mbx_etendue=?, mbx_type=?,
                mbx_mac_nom=?, mbx_mac_index=? where mbx_nom=?;);
            $sql = $db->prepare($req);
            $sql->execute($membrex{lib}, $membrex{rupture}, $membrex{exclus},
                $membrex{inclus}, $membrex{etendue}, $membrex{type}, $membrex{mac_nom},
                $membrex{mac_index}, $membrex{nom}) or die $DBI::errstr;

        } else {

            # Rattachement à un application

            my $app = substr($membrex{nom}, 0, 3);
            $app =~ s/-//;

            $req = qq(select count(*) from applications where app_nom=?;);
            $sql = $db->prepare($req);
            $sql->execute($app) or die $DBI::errstr;
            my $nb = $sql->fetchrow_array;

            if ($nb == 0) {
                $req = qq(insert into applications (app_nom) values(?););
                $sql = $db->prepare($req);
                $sql->execute($app) or die $DBI::errstr;
            }

            $req = qq(select app_id from applications where app_nom=?;);
            $sql = $db->prepare($req);
            $sql->execute($app) or die $DBI::errstr;
            my $app_id = $sql->fetchrow_array;

            # Rattachement à une chaîne

            my $chn = substr($membrex{nom}, 0, 5);

            $req = qq(select count(*) from chaines where chn_nom=?;);
            $sql = $db->prepare($req);
            $sql->execute($chn) or die $DBI::errstr;
            $nb = $sql->fetchrow_array;

            if ($nb == 0) {
                $req = qq(insert into chaines (chn_nom, app_id) values(?, ?););
                $sql = $db->prepare($req);
                $sql->execute($chn, $app_id) or die $DBI::errstr;
            }

            $req = qq(select chn_id from chaines where chn_nom=?;);
            $sql = $db->prepare($req);
            $sql->execute($chn) or die $DBI::errstr;
            my $chn_id = $sql->fetchrow_array;

            # Création du membrex

            $req = qq(insert into membrex
                (mbx_nom, mbx_lib, chn_id, mbx_rupture,
                    mbx_exclus, mbx_inclus, mbx_etendue, mbx_type, mbx_mac_nom, mbx_mac_index)
                values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?););
            $sql = $db->prepare($req);
            $sql->execute($membrex{nom}, $membrex{lib}, $chn_id, $membrex{rupture},
                $membrex{exclus}, $membrex{inclus}, $membrex{etendue}, $membrex{type},
                $membrex{mac_nom}, $membrex{mac_index}) or die $DBI::errstr;
        }

        # Création du lien processus ----------

        # Lecture de l'identifiant membrex
        $req = qq(select mbx_id from membrex where mbx_nom=?;);
        $sql = $db->prepare($req);
        $sql->execute($membrex{nom}) or die $DBI::errstr;
        my $mbx_id = $sql->fetchrow_array;

        # Recherche du lien processus
        $req = qq(select count(*) from liens where pro_id=? and mbx_id=?;);
        $sql = $db->prepare($req);
        $sql->execute($pro_id, $mbx_id) or die $DBI::errstr;
        my $nb = $sql->fetchrow_array;

        $rang++;    # rangement des jobs dans le déroulement du processus

        if ($nb) {

            # Modification de la version dans le lien
            $req = qq(update liens set pro_version=?, lie_rang=? where pro_id=? and mbx_id=?;);
            $sql = $db->prepare($req);
            $sql->execute($pro_version, $rang, $pro_id, $mbx_id) or die $DBI::errstr;

        } else {

            # Création du lien processus
            $req = qq(insert into liens
                (pro_id, pro_version, mbx_id, lie_rang)
                values (?, ?, ?, ?););
            $sql = $db->prepare($req);
            $sql->execute($pro_id, $pro_version, $mbx_id, $rang) or die $DBI::errstr;
        }
    }

    # Ressort des ESI sur les processus
    $req = qq(delete from ressort where pro_id=?;);
    $sql = $db->prepare($req);
    $sql->execute($pro_id) or die $DBI::errstr;
    $tous = ($clermont and $marseille and $nantes and $reims and $nevers);
    $req = qq(insert into ressort (pro_id, esi_id) values (?, ?););
    $sql = $db->prepare($req);
    if ($tous or $clermont) {
        $sql->execute($pro_id, 1) or die $DBI::errstr;
    }
    if ($tous or $marseille) {
        $sql->execute($pro_id, 2) or die $DBI::errstr;
    }
    if ($tous or $nantes) {
        $sql->execute($pro_id, 3) or die $DBI::errstr;
    }
    if ($tous or $reims) {
        $sql->execute($pro_id, 4) or die $DBI::errstr;
    }
    if ($tous or $nevers) {
        $sql->execute($pro_id, 5) or die $DBI::errstr;
    }
}

# Traitement d'un fichier XML ----------------------------------------------------------------------
# $db = connexion à la base de données
# $ficXML = nom du fichier
# --> statut d'erreur
sub traiteXML {

    # ARGUMENTS -----------
    my ($db, $ficXML) = @_;
    # ---------------------

    my $xmlref = XMLin($ficXML, KeyAttr=>['id'], ForceArray=>1);
    my %xml = %$xmlref;

    my $erreur = (valideXML($xmlref) > 0);

    if (not $erreur) {

        creeProcessus $db, $xmlref;

        my $jobsref = $xml{jobs}[0];
        my %jobshac = %$jobsref;
        my $jobstab = $jobshac{job};

        creeJobs $db, $jobstab, $xml{index};

        complemente $db, $xmlref;
    }

    return $erreur;
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# Arguments reçus

die "ERR 01 : usage = leonard.pl db_host [répertoire]\n" if @ARGV > 2;

# Connexion à la base de données

my $dbhost = $ARGV[0];

my $driver = 'Pg'; 
my $database = 'sppe';
my $dsn = "DBI:$driver:dbname=$database;host=".$dbhost.";port=5432";
my $userid = 'dba';
my $password = 'mypg';
my $db = DBI->connect($dsn, $userid, $password, { RaiseError => 1 }) or die $DBI::errstr;

# Vérification et pose d'un verrou
my $req = qq(SELECT valeur FROM statut WHERE objet='verrou';);
my $sql = $db->prepare($req);
$sql->execute() or die $DBI::errstr;
my $verrou = $sql->fetchrow_array;

die "ERR 04 : la base SPPE est verrouillée.\n" if $verrou eq 'on';

# Répertoire de travail

my $repBase = '.';
if (@ARGV > 1) {
    $repBase = $ARGV[1];
}

die "ERR 02 : le sous-répertoire «$repBase/traites» doit exister.\n" if ! -e "$repBase/traites";
die "ERR 03 : le sous-répertoire «$repBase/rejetes» doit exister.\n" if ! -e "$repBase/rejetes";

# Récupération des fichiers XML

opendir(my $dh, $repBase) || die "ERR 02 : Impossible d'ouvrir le répertoire $repBase: $!";
my @fichiers = grep { /\.xml$/ && -f "$repBase/$_" } readdir($dh);
closedir $dh;

# Traitement des fichiers XML

my $xsd = 'sppe.xsd';

for(@fichiers) {

    my $fic = "$repBase/$_";
    my $sufx = strftime "%Y%m%d%H%M%S", localtime;

    # Test de validité sur la forme
    my @commande = ('xmllint', '--noout', '--schema', $xsd, $fic);
    system @commande;

    if ($? == 0) {

        # Traitement

        if (traiteXML($db, $fic) > 0) {

            move($fic, "$repBase/rejetes/$_".$sufx);

        } else {

            move($fic, "$repBase/traites/$_".$sufx);

        }
    } else {

        move($fic, "$repBase/rejetes/$_".$sufx);
    }
}

# Retrait du verrou
$req = qq(UPDATE statut SET valeur='off' WHERE objet='verrou';);
$sql = $db->prepare($req);
$sql->execute() or die $DBI::errstr;

$db->disconnect();
exit 0;

# FIN ----------------------------------------------------------------------------------------------
