-- Changements dans la base de données SPPE
-- dans le cadre de la version 2.00

-- ajout d'un identifiant et d'un rang aux liens processus <-> membrex
create sequence liens_lie_id_seq;

alter table liens add column lie_id serial;
update liens set lie_id=default;
alter table liens add primary key (lie_id);
alter table liens alter column lie_id set not null;

alter table liens add column lie_rang smallint;
update liens set lie_rang=lie_id;
alter table liens alter column lie_rang set not null;

create unique index ix_liens_lie_rang on liens (pro_id, pro_version, lie_rang);

comment on column liens.lie_id is 'Identifiant';
comment on column liens.lie_rang is 'Rang d''affichage du job';

-- ajout des notes privées aux mises au plan
alter table plan add column pln_prive text;
comment on column plan.pln_prive is 'Notes privées pour le CQMF';

-- ajout d'un identifiant au réalisé et de l'heure de fin (séparément de la date)
create sequence realise_rea_id_seq;

alter table realise add column rea_id serial;
update realise set rea_id=default;
alter table realise add primary key (rea_id);
alter table realise alter column rea_id set not null;

alter table realise add column rea_heure smallint default 12;
-- update realise r set rea_heure=extract(hour from (
--     select max(job_fin) from jobs j where j.pln_id=r.pln_id and j.esi_id=r.esi_id));

comment on column realise.rea_id is 'Identifiant';
comment on column realise.rea_heure is 'Heure de fin';

-- ajout d'un utilisateur pour l'automate (cron)
insert into utilisateurs
    (uti_login, uti_nom, uti_mdp, uti_ok)
    values ('automate', 'automate', '', 'f');

-- suppression d'une colonne inutilisée
alter table utilisateurs drop column uti_mois;

-- ajout préférence travaux à venir
alter table utilisateurs add column uti_sel_ave boolean not null default 'f';
comment on column utilisateurs.uti_sel_ave is 'Afficher les travaux à venir seulement';

-- processus non suivis au niveau du réalisé automatique
alter table processus add column pro_realise boolean default 't';
create index ix_processus_pro_realise on processus (pro_realise);
comment on column processus.pro_realise is 'indique si le processus est suivi au réalisé automatique';
update processus set pro_realise='t';
update processus set pro_realise='f' where pro_nom='MEDOC QUOTIDIEN';
-- delete from realise where rea_id in (
--     select distinct r.rea_id
--     from processus p
--         join plan q on q.pro_id=p.pro_id
--         join realise r on r.pln_id=q.pln_id
--     where p.pro_realise='f');

-- commentaires complémentaires
comment on column membrex.mbx_type is 'domaine cible de traitement';
comment on column membrex.mbx_etendue is 'exhaustivité';
comment on column membrex.mbx_inclus is 'entités incluses si sélection';
comment on column membrex.mbx_exclus is 'entités excluses si sélection';

-- nom machine des ESI
alter table esi add column esi_machine text unique;
alter table esi add column esi_ops text unique;
alter table esi add column esi_gcos text unique;
comment on column esi.esi_machine is 'Nom de l''ESI en machine';
comment on column esi.esi_ops is 'Nom de OPS de l''ESI';
comment on column esi.esi_gcos is 'Début fichier GCOS de l''ESI';
update esi set esi_machine='cl1x', esi_ops='o63e', esi_gcos='CLE1' where esi_nom like 'Cle%';
update esi set esi_machine='na2x', esi_ops='o44e', esi_gcos='NAN2' where esi_nom like 'Nan%';
update esi set esi_machine='ma2x', esi_ops='o13e', esi_gcos='MAR2' where esi_nom like 'Mar%';
update esi set esi_machine='re2x', esi_ops='o51e', esi_gcos='REI2' where esi_nom like 'Rei%';

-- nouvelles tables

-- nettoyage préalable
drop table if exists steps;
drop table if exists jobs;
drop table if exists groupes;
drop table if exists cibles;
drop table if exists entites;

-- entités
-- correspond aux unités de traitement
create table entites (
    ent_id          serial      not null    primary key,
    ent_lib         text,
    ent_code        char(3)     not null    unique,
    esi_id          integer                 references esi
);
create index ix_entites_ent_lib on entites (ent_lib);
create index ix_entites_esi_id on entites (esi_id);

comment on table entites is 'entités de traitement';
comment on column entites.ent_id is 'identifiant';
comment on column entites.ent_lib is 'libellé LEONARD';
comment on column entites.ent_code is 'code externe fonctionnel';
comment on column entites.esi_id is 'identifiant de l''ESI compétent';

-- cibles
-- correspond aux ensemblesd de traitement
create table cibles (
    cib_id          serial      not null    primary key,
    cib_lib         text        not null    unique,
    cib_code        text        not null    unique
);
comment on table cibles is 'grands ensembles de traitement';
comment on column cibles.cib_id is 'identifiant';
comment on column cibles.cib_lib is 'libellé';
comment on column cibles.cib_code is 'code externe fonctionnel';

-- groupes
-- constitue les ensembles cibles entités
create table groupes (
    cib_id          integer     not null    references cibles,
    ent_id          integer     not null    references entites
);
create index ix_groupes_cib_id on groupes (cib_id);
create index ix_groupes_ent_id on groupes (ent_id);

comment on table groupes is 'ensembles cibles entités';
comment on column groupes.cib_id is 'identifiant de la cible';
comment on column groupes.ent_id is 'identifiant de l''entité';

-- jobs
-- jobs machines
create table jobs (
    job_id          serial      not null    primary key,
    job_lib         text        not null,
    mbx_id          integer     not null    references membrex,
    pln_id          integer     not null    references plan,
    ent_id          integer     not null    references entites,
    esi_id          integer                 references esi,
    job_debut       timestamp,
    job_fin         timestamp,
    job_ron         smallint,
    job_etat        char                    check (job_etat in ('X','T','A')),
    job_dernier     boolean     not null    default 't'
);
create index ix_jobs_mbx_id on jobs (mbx_id);
create index ix_jobs_pln_id on jobs (pln_id);
create index ix_jobs_ent_id on jobs (ent_id);
create index ix_jobs_esi_id on jobs (esi_id);
create index ix_jobs_job_ron on jobs (job_ron);
create index ix_jobs_job_dernier on jobs (job_dernier);

comment on table jobs is 'jobs machine';
comment on column jobs.job_id is 'identifiant';
comment on column jobs.job_lib is 'libellé du job';
comment on column jobs.mbx_id is 'membrex correspondant';
comment on column jobs.pln_id is 'planification correspondante';
comment on column jobs.ent_id is 'entité concernée';
comment on column jobs.esi_id is 'ESI qui A fait le traitement (permet d''identifier les délestages)';
comment on column jobs.job_debut is 'début du traitement';
comment on column jobs.job_fin is 'fin du traitement';
comment on column jobs.job_ron is 'identifiant GCOS';
comment on column jobs.job_etat is 'X=en cours, T=terminé, A=planté (abort)';
comment on column jobs.job_dernier is 'Indique s''il s''agit du dernier passage';

-- steps
-- détail des étapes des jobs
create table steps (
    stp_id          serial      not null    primary key,
    job_id          integer     not null    references jobs,
    stp_lib         text        not null,
    stp_etat        smallint,
    stp_debut       timestamp   not null,
    stp_fin         timestamp,
    stp_elapsed     numeric(7,2),
    stp_cpu         numeric(7,2)
);
create index ix_steps_job_id on steps (job_id);
create index ix_steps_stp_etat on steps (stp_etat);

comment on table steps is 'steps (étapes) des jobs';
comment on column steps.stp_id is 'identifiant';
comment on column steps.job_id is 'job concerné';
comment on column steps.stp_lib is 'nom du step';
comment on column steps.stp_etat is 'statut : entre 0 et 3, 3=abort';
comment on column steps.stp_debut is 'début de traitement';
comment on column steps.stp_fin is 'fin de traitement';
comment on column steps.stp_elapsed is 'temps écoulé';
comment on column steps.stp_cpu is 'temps CPU consommé';

-- archivage du réalisé supprimé
-- realisé archivé
-- Table des dates du réalisé par ESI
create table realise_archive (
    rea_id          integer         not null    primary key,
    pln_id          integer         not null    references plan,
    esi_id          integer         not null    references esi,
    uti_id          integer         not null    references utilisateurs,
    rea_debut       date,
    rea_fin         date,
    rea_statut      char                        check (rea_statut in ('A','T')),
    rea_timbre      timestamp       not null    default current_timestamp,
    rea_notes       text
);
comment on table realise_archive
    is 'Réalisé par ESI';
comment on column realise_archive.pln_id
    is 'Mise au plan';
comment on column realise_archive.esi_id
    is 'ESI';
comment on column realise_archive.uti_id
    is 'Utilisateur';
comment on column realise_archive.rea_debut
    is 'Date de début réelle';
comment on column realise_archive.rea_fin
    is 'Date de fin réelle';
comment on column realise_archive.rea_statut
    is 'Statut : null = en cours, T = terminé, A = abort';
comment on column realise_archive.rea_timbre
    is 'Marqueur de mise-à-jour';
comment on column realise_archive.rea_notes
    is 'Commentaires';

create index ix_realise_archive_pln_id on realise_archive (pln_id);
create index ix_realise_archive_esi_id on realise_archive (esi_id);
create unique index ix_realise_archive_unicite on realise_archive (pln_id, esi_id);

-- jobs machines archivés
create table jobs_archive (
    job_id          integer     not null    primary key,
    job_lib         text        not null,
    mbx_id          integer     not null    references membrex,
    pln_id          integer     not null    references plan,
    ent_id          integer     not null    references entites,
    esi_id          integer                 references esi,
    job_debut       timestamp,
    job_fin         timestamp,
    job_ron         smallint,
    job_etat        char                    check (job_etat in ('X','T','A')),
    job_dernier     boolean     not null    default 't'
);
create index ix_jobs_archive_mbx_id on jobs_archive (mbx_id);
create index ix_jobs_archive_pln_id on jobs_archive (pln_id);
create index ix_jobs_archive_ent_id on jobs_archive (ent_id);
create index ix_jobs_archive_esi_id on jobs_archive (esi_id);
create index ix_jobs_archive_job_ron on jobs_archive (job_ron);
create index ix_jobs_archive_job_dernier on jobs_archive (job_dernier);

comment on table jobs_archive is 'jobs_archive machine';
comment on column jobs_archive.job_id is 'identifiant';
comment on column jobs_archive.job_lib is 'libellé du job';
comment on column jobs_archive.mbx_id is 'membrex correspondant';
comment on column jobs_archive.pln_id is 'planification correspondante';
comment on column jobs_archive.ent_id is 'entité concernée';
comment on column jobs_archive.esi_id is 'ESI qui A fait le traitement (permet d''identifier les délestages)';
comment on column jobs_archive.job_debut is 'début du traitement';
comment on column jobs_archive.job_fin is 'fin du traitement';
comment on column jobs_archive.job_ron is 'identifiant GCOS';
comment on column jobs_archive.job_etat is 'X=en cours, T=terminé, A=planté (abort)';
comment on column jobs_archive.job_dernier is 'Indique s''il s''agit du dernier passage';

-- steps archivés
-- détail des étapes des jobs archivés
create table steps_archive (
    stp_id          integer     not null    primary key,
    job_id          integer     not null,
    stp_lib         text        not null,
    stp_etat        smallint,
    stp_debut       timestamp   not null,
    stp_fin         timestamp,
    stp_elapsed     numeric(7,2),
    stp_cpu         numeric(7,2)
);
create index ix_steps_archive_job_id on steps_archive (job_id);
create index ix_steps_archive_stp_etat on steps_archive (stp_etat);

comment on table steps_archive is 'steps_archive (étapes) des jobs_archive';
comment on column steps_archive.stp_id is 'identifiant';
comment on column steps_archive.job_id is 'job concerné';
comment on column steps_archive.stp_lib is 'nom du step';
comment on column steps_archive.stp_etat is 'statut : entre 0 et 3, 3=abort';
comment on column steps_archive.stp_debut is 'début de traitement';
comment on column steps_archive.stp_fin is 'fin de traitement';
comment on column steps_archive.stp_elapsed is 'temps écoulé';
comment on column steps_archive.stp_cpu is 'temps CPU consommé';

-- nouvelles vues pour trouver facilement les mises au plan terminées par esi
create or replace view realisations as
    select p.pln_id, z.esi_id, case when
--
-- not ((not u.pro_suivi and (r.rea_fin is null or r.rea_statut is null or r.rea_statut!='T')) or
-- (u.pro_suivi and ((r.rea_debut is null and p.pln_debut>=current_date) or
-- (r.rea_fin is not null and r.rea_statut is not null and r.rea_statut!='T') or
-- (r.rea_statut is null and r.rea_debut is not null and p.pln_fin>=current_date))))
--
        not (r.rea_fin is null or r.rea_statut is null or r.rea_statut!='T')

        then 0 else 1 end as encours,
        case when r.rea_fin is null
             then case when p.pln_debut<=current_date and r.rea_debut is not null
                       then current_date
                       else p.pln_fin
                  end
             else r.rea_fin
        end as butee
    from plan p
        join ressort z on z.pro_id=p.pro_id
        join processus u on u.pro_id=p.pro_id
        left outer join realise r on r.pln_id=p.pln_id and r.esi_id=z.esi_id;

create or replace view realisations_globales as
    select pln_id, max(butee) as fin_reelle, sum(encours) as encore
    from realisations
    group by pln_id;

-- chargement des cibles de traitement

-- cibles
insert into cibles (cib_lib, cib_code) values
    ('national', 'NAT'),
    ('ESI', 'ESI'),
    ('TDS', 'TDS'),
    ('directions', 'DIR');

-- entites
insert into entites (ent_code, ent_lib, esi_id) values
    ('020', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('030', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('090', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('110', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('120', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('150', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('180', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('270', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('280', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('300', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('310', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('320', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('340', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('360', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('370', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('410', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('430', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('450', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('460', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('480', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('591', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('592', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('600', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('620', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('630', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('650', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('660', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('760', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('800', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('810', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('820', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('971', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('972', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('973', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C01', 'CLE1-M2CE', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C02', 'CLE1-M2OC', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C03', 'CLE1-M2AN', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C04', 'CLE1-M2ND', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C05', 'CLE1-M2PE', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C06', 'CLE1-M2MP', (select esi_id from esi where esi_nom like 'Cle%')),
    ('C00', '', (select esi_id from esi where esi_nom like 'Cle%')),
    ('010', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('040', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('050', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('060', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('070', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('080', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('100', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('131', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('132', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('210', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('250', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('260', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('2A0', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('2B0', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('380', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('390', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('420', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('510', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('520', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('540', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('550', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('570', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('580', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('670', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('680', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('690', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('700', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('710', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('730', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('740', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('830', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('840', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('880', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('890', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('900', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('976', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XRA', 'MAR2-M2RA', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XPA', 'MAR2-M2PA', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XRB', 'MAR2-M2RB', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XMY', 'MAR2-M2MY', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XAM', 'MAR2-M2AM', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XMH', 'MAR2-M2MH', (select esi_id from esi where esi_nom like 'Mar%')),
    ('XLF', 'MAR2-M2LF', (select esi_id from esi where esi_nom like 'Mar%')),
    ('M00', '', (select esi_id from esi where esi_nom like 'Mar%')),
    ('140', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('160', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('170', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('190', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('220', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('230', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('240', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('290', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('330', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('350', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('400', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('440', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('470', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('490', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('500', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('530', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('560', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('610', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('640', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('720', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('790', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('850', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('860', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('870', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('974', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('X33', 'NAN2-M2AQ', (select esi_id from esi where esi_nom like 'Nan%')),
    ('X35', 'NAN2-M2B', (select esi_id from esi where esi_nom like 'Nan%')),
    ('X44', 'NAN2-M2L', (select esi_id from esi where esi_nom like 'Nan%')),
    ('X86', 'NAN2-M2PC', (select esi_id from esi where esi_nom like 'Nan%')),
    ('X97', 'NAN2-M2RU', (select esi_id from esi where esi_nom like 'Nan%')),
    ('N00', '', (select esi_id from esi where esi_nom like 'Nan%')),
    ('754', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('755', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('756', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('757', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('758', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('770', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('780', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('910', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('921', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('922', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('930', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('940', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('950', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('B31', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('X00', 'REI2-M2DG', (select esi_id from esi where esi_nom like 'Rei%')),
    ('X75', 'REI2-M2PA', (select esi_id from esi where esi_nom like 'Rei%')),
    ('X77', 'REI2-M2RE', (select esi_id from esi where esi_nom like 'Rei%')),
    ('X78', 'REI2-M2', (select esi_id from esi where esi_nom like 'Rei%')),
    ('X98', 'REI2-M2DC', (select esi_id from esi where esi_nom like 'Rei%')),
    ('R00', '', (select esi_id from esi where esi_nom like 'Rei%')),
    ('Z00', '', NULL); 
update entites e
    set ent_lib=(case
        when (select f.esi_nom from esi f where f.esi_id=e.esi_id) like 'Cle%' then 'CLE1-'
        when (select f.esi_nom from esi f where f.esi_id=e.esi_id) like 'Mar%' then 'MAR2-'
        when (select f.esi_nom from esi f where f.esi_id=e.esi_id) like 'Nan%' then 'NAN2-'
        else 'REI2-' end)||ent_code
    where ent_lib='';

-- groupes

-- directions
insert into groupes (cib_id, ent_id)
    select (select cib_id from cibles where cib_code='DIR'), ent_id
    from entites
    where  ent_code  in  ('020','030','090','110','120','150','180','270','280','300','310','320',
        '340','360','370','410','430','450','460','480','591','592','600','620','630','650','660',
        '760','800','810','820','971','972','973','010','040','050','060','070','080','100','131',
        '132','210','250','260','2A0','2B0','380','390','420','510','520','540','550','570','580',
        '670','680','690','700','710','730','740','830','840','880','890','900','976','140','160',
        '170','190','220','230','240','290','330','350','400','440','470','490','500','530','560',
        '610','640','720','790','850','860','870','974','754','755','756','757','758','770','780',
        '910','921','922','930','940','950','B31');

-- TDS
insert into groupes (cib_id, ent_id)
    select (select cib_id from cibles where cib_code='TDS'), ent_id
    from entites
    where  ent_code  in  ('C01','C02','C03','C04','C05','C06','C07',
        'XRA','XPA','XRB','XMY','XAM','XMH','XLF',
        'X33','X35','X44','X86','X97',
        'X00','X75','X77','X78','X98');

-- ESI
insert into groupes (cib_id, ent_id)
    select (select cib_id from cibles where cib_code='ESI'), ent_id
    from entites
    where  ent_code  in  ('C00','M00','N00','R00');

-- NAT
insert into groupes (cib_id, ent_id) 
    select (select cib_id from cibles where cib_code='NAT'), ent_id
    from entites
    where ent_code='Z00';

-- fin
