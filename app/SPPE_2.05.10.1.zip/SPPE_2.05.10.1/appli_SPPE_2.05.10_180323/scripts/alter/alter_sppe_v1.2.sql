-- Changements dans la base de données SPPE
-- dans le cadre de la version 1.2

-- Ajout d'un champ dans la table processus
-- pour prendre en compte le fait que certains
-- processus doivent impérativement être traités
-- le premier jour de la période de planification
alter table processus
    add column pro_premier boolean not null default 'f';
comment on column processus.pro_premier is 'Traitement premier jour planification obligatoire';

-- Ajout d'un champ dans la table processus
-- pour stocker l'objet d'un processus
alter table processus
    add column pro_objet text not null default '';
comment on column processus.pro_objet is 'Objet du processus';

-- Ajout d'un champ dans la table processus
-- pour caractériser les processus dits génériques
-- initialement, les processus génériques sont MDAMN1 -> MDAMN5 (FRP) et MDACR1 -> MDACR2 (MEDOC)
alter table processus
    add column pro_generique boolean default 'f';
comment on column processus.pro_generique is 'Processus dit générique';

update processus set pro_generique='t'
    where pro_nom in ('MDAMN1','MDAMN2','MDAMN3','MDAMN4','MDAMN5',
                      'MDACR1','MDACR2','MDACR3','MDACR4','MDACR5');



-- fin
