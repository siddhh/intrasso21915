#! /usr/bin/php -q
<?php
	if(!empty( $_SERVER['HOSTNAME']) && (($_SERVER['HOSTNAME']=='spepgsa001') || ($_SERVER['HOSTNAME']=='spepgsa002'))){ // PRODUCTION
		define('HOST_BASE','spepgsd001-d');
	}elseif(!empty( $_SERVER['HOSTNAME']) && ($_SERVER['HOSTNAME']=='spedgsa001')){ // RECETTE
		define('HOST_BASE','spedgsd001-d');
	}else{ // local
		define('HOST_BASE','127.0.0.1');
	}
	
	require(__DIR__ .'/../../inc/pg_connect.php');
	require(__DIR__ .'/../../inc/constantes.php');
	require(__DIR__ .'/../../sql/sql.php');
	
	shell_exec('clear');
	$operationMAJ = TRUE;
	
	$fichier = fopen('/var/sppe/log_mep/maj_20180323.log','w');
	/*
	 * 	========================================================================================
	 * |																						|
	 * |						MISE A JOUR DE LA BASE DE DONNÉES DE SPPE						|
	 * |																						|
	 * |	Ajout de l'établissement de NEVERS													|
	 * |																						|
	 * |																						|
	 * |															willy BOUREAU	: 16/05/2017|
	 *  ========================================================================================
	 */
	
	
	/*
	 * 		CRÉATIONS
	 *  ========================================================================================
	 */
	echo " ===================================================================================== \n";
	echo "|                                                                                     |\n";
	echo "|                  MISE A JOUR DE LA BASE DE DONNÉES DE SPPE                          |\n";
	echo "|                                                                                     |\n";
	echo " ===================================================================================== \n";
	echo "\n\n";
	echo " ===> Ajout de l'établissement de Nevers\n";
	
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                          Ajout de l'établissement de Nevers                         |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	sql_gen('begin');
	
	$creationOk = true;
	$operationMAJ = true;
	$message = '';
	
	$message .= ' - Ajout de l\'établissement de Nevers : ';
	$req = "INSERT INTO esi 
				(esi_id, esi_nom, esi_ok, esi_machine, esi_ops, esi_gcos, serv_id)
			VALUES
				(nextval('esi_esi_id_seq'::regclass), 'Nevers', true, NULL, NULL, 'NEV3', NULL);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	echo "\n";
	echo " ===================================================================================== \n";
	echo "|                                                                                     |\n";
	
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	fwrite($fichier," ===================================================================================== \n");
	fwrite($fichier,"|                                                                                     |\n");
	
	if ($operationMAJ){
		echo "|                    Mise à jour de la base SPPE réalisée avec succès                 |\n";
		fwrite($fichier,"|                     Mise à jour de la base SPPE réalisée avec succès                |\n");
	}else{
		echo "|      Erreur lors de la mise à jour de la base SPPE >>> voir le fichier de log       |\n";
		fwrite($fichier,"|       Erreur lors de la mise à jour de la base SPPE >>> voir détail ci-dessus       |\n");
	}
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ===================================================================================== \n");
	
	echo "|                                                                                     |\n";
	echo " ===================================================================================== \n";
	fclose($fichier);
	?>
