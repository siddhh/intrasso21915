#! /usr/bin/php -q
<?php
	if(!empty( $_SERVER['HOSTNAME']) && (($_SERVER['HOSTNAME']=='spepgsa001') || ($_SERVER['HOSTNAME']=='spepgsa002'))){ // PRODUCTION
		define('HOST_BASE','spepgsd001-d');
	}elseif(!empty( $_SERVER['HOSTNAME']) && ($_SERVER['HOSTNAME']=='spedgsa001')){ // RECETTE
		define('HOST_BASE','spedgsd001-d');
	}else{ // local
		define('HOST_BASE','127.0.0.1');
	}
	
	require(__DIR__ .'/../../inc/pg_connect.php');
	require(__DIR__ .'/../../inc/constantes.php');
	require(__DIR__ .'/../../sql/sql.php');
	
	shell_exec('clear');
	$operationMAJ = TRUE;
	
	$fichier = fopen('/var/sppe/log_mep/maj_20170516.log','w');
	/*
	 * 	========================================================================================
	 * |																						|
	 * |						MISE A JOUR DE LA BASE DE DONNÉES DE SPPE						|
	 * |																						|
	 * |	Mise en place de l'authentification via le SSO DGFiP								|
	 * |																						|
	 * |																						|
	 * |															willy BOUREAU	: 16/05/2017|
	 *  ========================================================================================
	 */
	
	
	/*
	 * 		CRÉATIONS
	 *  ========================================================================================
	 */
	echo " ===================================================================================== \n";
	echo "|                                                                                     |\n";
	echo "|                  MISE A JOUR DE LA BASE DE DONNÉES DE SPPE                          |\n";
	echo "|                                                                                     |\n";
	echo " ===================================================================================== \n";
	echo "\n\n";
	echo " ===> Ajout des nouvelles tables\n";
	
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                          Ajout des nouvelles tables                                 |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Ajout de la table : `services`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	sql_gen('begin');
	
	$creationOk = true;
	$message = '';
	
	// sequence sur id de la table = index autoincrémenté
	$message .= ' - Création de la séquence `services_serv_id_seq` : ';
	$req = 'CREATE SEQUENCE services_serv_id_seq
			START WITH 1
			INCREMENT BY 1
			NO MINVALUE
			NO MAXVALUE
			CACHE 1;';
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}

	$message .= ' - Modification du propriétaire de la séquence `services_serv_id_seq` : ';
	$req = 'ALTER TABLE services_serv_id_seq OWNER TO dba;';
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Création de la table `services` : ';
	$req = "CREATE TABLE services (
				serv_id integer DEFAULT nextval('services_serv_id_seq'::regclass) NOT NULL,
				serv_nom text,
				serv_ok boolean DEFAULT true,
				esi_id integer DEFAULT NULL,
				eqp_id integer DEFAULT NULL
			);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$req = "COMMENT ON COLUMN services.serv_id is 'Identifiant du service';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN services.serv_nom is 'Nom du service';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN services.serv_ok is 'Vrai si service actif';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN services.esi_id is 'Identifiant de l esi de production correspondant si besoin';";
	$res = sql_gen($req);
	
	$message .= ' - Modification du propriétaire de la table `services` : ';
	$req = "ALTER TABLE services OWNER TO dba;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Attache la séquence `services_serv_id_seq` à la colonne `serv_id` : ';
	$req = 'ALTER SEQUENCE services_serv_id_seq
			OWNED BY services.serv_id;';
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé primaire sur la table `services` : ';
	$req = "ALTER TABLE ONLY services
				ADD CONSTRAINT services_pkey PRIMARY KEY (serv_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Ajout de la table : `attacher`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");

	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Création de la table `attacher` : ';
	$req = "CREATE TABLE attacher (
				serv_id integer NOT NULL,
				dom_id integer NOT NULL,
				profil smallint DEFAULT 0 NOT NULL
			);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$req = "COMMENT ON COLUMN attacher.serv_id is 'Identifiant du service';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN attacher.dom_id is 'Identifiant du domaine';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN attacher.profil is 'Valeur de l habilitation du service au domaine';";
	$res = sql_gen($req);
	
	$message .= ' - Modification du propriétaire de la table `attacher` : ';
	$req = "ALTER TABLE attacher OWNER TO dba;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé primaire sur la table `attacher` : ';
	$req = "ALTER TABLE ONLY attacher
				ADD CONSTRAINT attacher_pkey PRIMARY KEY (serv_id, dom_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `attacher_dom_id_fkey` sur la table `attacher` : ';
	$req = "ALTER TABLE ONLY attacher
				ADD CONSTRAINT attacher_dom_id_fkey FOREIGN KEY (dom_id) REFERENCES domaines(dom_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `attacher_serv_id_fkey` sur la table `attacher` : ';
	$req = "ALTER TABLE ONLY attacher
				ADD CONSTRAINT attacher_serv_id_fkey FOREIGN KEY (serv_id) REFERENCES services(serv_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Ajout de la table : `habiliter`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Création de la table `habiliter` : ';
	$req = "CREATE TABLE habiliter (
				uti_id integer NOT NULL,
				dom_id integer NOT NULL,
				habilitation smallint DEFAULT 0 NOT NULL
			);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}

	$req = "COMMENT ON COLUMN habiliter.uti_id is 'Identifiant de l utilisateur';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN habiliter.dom_id is 'Identifiant du domaine';";
	$res = sql_gen($req);
	$req = "COMMENT ON COLUMN habiliter.habilitation is 'Valeur de l habilitation de l utilisateur au domaine';";
	$res = sql_gen($req);
	
	$message .= ' - Modification du propriétaire de la table `habiliter` : ';
	$req = "ALTER TABLE habiliter OWNER TO dba;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé primaire sur la table `habiliter` : ';
	$req = "ALTER TABLE ONLY habiliter
				ADD CONSTRAINT habilitations_pkey PRIMARY KEY (uti_id, dom_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `habiliter_dom_id_fkey` sur la table `attacher` : ';
	$req = "ALTER TABLE ONLY habiliter
				ADD CONSTRAINT habiliter_dom_id_fkey FOREIGN KEY (dom_id) REFERENCES domaines(dom_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `attacher_serv_id_fkey` sur la table `attacher` : ';
	$req = "ALTER TABLE ONLY habiliter
				ADD CONSTRAINT habiliter_uti_id_fkey FOREIGN KEY (uti_id) REFERENCES utilisateurs(uti_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	
	/*
	 * 		MISES A JOUR DE LA STRUCTURE DE LA BASE
	 *  ========================================================================================
	 */
	echo "\n";
	echo " ===> Mise à jour de la structure existante\n";
	
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                          Mise à jour de la structure existante                      |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `esi`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table esi : ajout du champ serv_id (clé étrangère de la table services) */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Ajout de la colonne `serv_id` sur la table `esi` : ';
	$req = "ALTER TABLE ONLY esi
				ADD COLUMN serv_id integer;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `esi_serv_id_fkey` sur la table `esi` : ';
	$req = "ALTER TABLE ONLY esi
				ADD CONSTRAINT esi_serv_id_fkey FOREIGN KEY (serv_id) REFERENCES services(serv_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `applications`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table applications : renommage du champ eqp_id en serv_id (clé étrangère de la table services) */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Renommage de la colonne `eqp_id` en `serv_id` : ';
	$req = "ALTER TABLE applications RENAME COLUMN eqp_id TO serv_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la contrainte de clé étrangère `applications_eqp_id_fkey` : ';
	$req = "ALTER TABLE applications 
				DROP CONSTRAINT applications_eqp_id_fkey;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `utilisateurs`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table utilisateurs : ajout des champs uti_uid_fonctionnel,uti_prenom,serv_id,uti_admin */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Ajout de la colonne `serv_id` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD COLUMN serv_id integer;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la colonne `uti_uid_fonctionnel` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD COLUMN uti_uid_fonctionnel text;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la colonne `uti_prenom` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD COLUMN uti_prenom text;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la colonne `uti_admin` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD COLUMN uti_admin boolean DEFAULT false;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte d\'unicité sur la colonne `uti_uid_fonctionnel` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD CONSTRAINT utilisateurs_uti_uid_fonctionnel_key UNIQUE (uti_uid_fonctionnel);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout de la contrainte de clé étrangère `utilisateurs_serv_id_fkey` sur la table `utilisateurs` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				ADD CONSTRAINT utilisateurs_serv_id_fkey FOREIGN KEY (serv_id) REFERENCES services(serv_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/* Mise à jour de la sequence liens_lie_id_seq */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Attache la séquence `liens_lie_id_seq` à la colonne `lie_id` : ';
	$req = 'ALTER SEQUENCE liens_lie_id_seq
				OWNED BY liens.lie_id;';
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/* Mise à jour de la sequence realise_rea_id_seq */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Attache la séquence `realise_rea_id_seq` à la colonne `rea_id` : ';
	$req = 'ALTER SEQUENCE realise_rea_id_seq
				OWNED BY realise.rea_id;';
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	
	/*
	 * 		MISES A JOUR DONNÉES DES TABLES
	 *  ========================================================================================
	 */
	echo "\n";
	echo " ===> Mise à jour des données existantes\n";
	
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                          Mise à jour des données existantes                         |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `services`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table services : remplit la table des informations extraites des tables esi + equipes */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Mise à jour de la table `services` depuis la table `esi` : ';
	$req = "INSERT INTO services
				SELECT nextval('services_serv_id_seq'::regclass), 'ESI '||esi_nom, true, esi_id, NULL FROM esi ORDER BY esi_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Mise à jour de la table `services` depuis la table `equipes` : ';
	$req = "INSERT INTO services
				SELECT nextval('services_serv_id_seq'::regclass), 'Bureau d''étude : '||eqp_nom, true, NULL, eqp_id FROM equipes ORDER BY eqp_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `esi`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table esi : esi.serv_id=services.serv_id */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Mise à jour de la table `esi` depuis la table `services` : ';
	$req = "UPDATE esi e SET
			serv_id = (SELECT serv_id FROM services s WHERE s.esi_id=e.esi_id)
			FROM services s
			WHERE s.esi_id=e.esi_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}

	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `utilisateurs`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table utilisateurs : uti_uid_fonctionnel=uti_login */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Mise à jour de la table `utilisateurs` colonne `uti_uid_fonctionnel` : ';
	$req = "UPDATE utilisateurs SET
			uti_uid_fonctionnel = uti_login
			WHERE true;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	fwrite($fichier,$message);
	
	/* Mise à jour de la table utilisateurs : utilisateurs.serv_id=services.serv_id en fonction des valeurs de esi_id et eqp_id */
	$message .= ' - Mise à jour de la table `utilisateurs` colonne `serv_id` : ';
	$reqUti= 'SELECT uti_id,esi_id,eqp_id FROM utilisateurs WHERE uti_ok';
	$resUti = sql_gen($reqUti);
	while ($uti = pg_fetch_assoc($resUti)){
		if(($uti['eqp_id']==NULL) && ($uti['esi_id']==NULL)){
			$reqService='';
		}elseif ($uti['eqp_id']==NULL){
			$prm = array($uti['esi_id']);
			$reqService = 'SELECT serv_id FROM services WHERE serv_ok AND esi_id=$1';
		}else{
			$prm = array($uti['eqp_id']);
			$reqService = 'SELECT serv_id FROM services WHERE serv_ok AND eqp_id=$1';
		}
		if (empty($reqService)){
			$service['serv_id'] = NULL;
		}else{
			$resService = sql_gen($reqService,$prm);
			$service = pg_fetch_assoc($resService);
		}
		$req = "UPDATE utilisateurs SET
				serv_id = $2
				WHERE uti_id=$1;";
		$param = array($uti['uti_id'],$service['serv_id']);
		$res = sql_gen($req,$param);
		if ($res === false){
			$creationOk= false;
		}
	}
	if (!$creationOk){
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour de la table : `applications`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Mise à jour de la table applications : applications.serv_id=services.serv_id en fonction des valeurs de esi_id et eqp_id */
	$message .= ' - Mise à jour de la table `applications` colonne `serv_id` : ';
	$reqApp= 'SELECT app_id,serv_id FROM applications WHERE app_ok';
	$resApp = sql_gen($reqApp);
	while ($app = pg_fetch_assoc($resApp)){
		if ($app['serv_id']!=NULL){ // pas de maj à faire si null
			$prm = array($app['serv_id']);
			$reqService = 'SELECT serv_id FROM services WHERE serv_ok AND eqp_id=$1';
			$resService = sql_gen($reqService,$prm);
			$service = pg_fetch_assoc($resService);
			
			$req = "UPDATE applications SET
					serv_id = $2
					WHERE app_id=$1;";
			$param = array($app['app_id'],$service['serv_id']);
			$res = sql_gen($req,$param);
			if ($res === false){
				$creationOk= false;
			}
		}
	}
	if (!$creationOk){
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	
	$message .= ' - Mise en place de la contrainte de clé étrangère `applications_serv_id_fkey` : ';
	$req = "ALTER TABLE ONLY applications
				ADD CONSTRAINT applications_serv_id_fkey FOREIGN KEY (serv_id) REFERENCES services(serv_id);";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
		
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);

	
	/*
	 * 		SUPPRESSIONS
	 *  ========================================================================================
	 */
	echo "\n";
	echo " ===> Suppression des structures obsolètes\n";
	
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                          Suppression des structures obsolètes                       |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Suppression de la table : `equipes`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	/* Suppression de la table equipes */
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Suppression de la table `equipes` : ';
	$req = "DROP TABLE equipes CASCADE;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/* Table utilisateurs : suppression des champs uti_login, uti_mdp, eqp_id */
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Suppression sur la table : `utilisateurs`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
	$message .= ' - Suppression de la contrainte `utilisateurs_uti_nom_key` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP CONSTRAINT utilisateurs_uti_nom_key;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la contrainte `utilisateurs_uti_droits_check` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP CONSTRAINT utilisateurs_uti_droits_check;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la colonne `uti_login` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP COLUMN uti_login;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la colonne `uti_mdp` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP COLUMN uti_mdp;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la colonne `uti_droits` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP COLUMN uti_droits;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Suppression de la colonne `eqp_id` : ';
	$req = "ALTER TABLE ONLY utilisateurs
				DROP COLUMN eqp_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/* Table services : suppression du champ esi_id,eqp_id */
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Suppression sur la table : `services`\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	
// 	$message .= ' - Suppression de la colonne `esi_id` : ';
// 	$req = "ALTER TABLE ONLY services
// 				DROP COLUMN esi_id;";
// 	$res = sql_gen($req);
// 	if ($res === false){
// 		$creationOk= false;
// 		$message.= "Erreur\n";
// 	}else{
// 		$message.= "OK\n";
// 	}
	
	$message .= ' - Suppression de la colonne `eqp_id` : ';
	$req = "ALTER TABLE ONLY services
				DROP COLUMN eqp_id;";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/*
	 * 		MISE A JOUR DES COMPTES UTILISATEURS
	 *  ========================================================================================
	 */
	echo "\n";
	echo " ===> Mise à jour des comptes Utilisateurs\n";
	
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                        Mise à jour des comptes Utilisateurs                         |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Mise à jour des comptes existants\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	$maj = true;
	
	$message .= ' - Mise à jour existant : ';
	
	if (($fichierMaj= fopen("maj_utilisateurs_SPPE_20170516.csv", "r")) !== FALSE) {
		while (($data = fgetcsv($fichierMaj, 1000, ",")) !== FALSE) {
			if ($data[4]=='TRUE'){
				$estOk='t';
			}else{
				$estOk='f';
			}
			if ($estOk=='t'){
				$req = "UPDATE utilisateurs SET
						uti_uid_fonctionnel=$1,
						uti_nom=$2,
						uti_prenom=$3,
						uti_sel_app=NULL,
						uti_admin=$4,
						uti_ok=$5
						WHERE uti_id=$6;";
				
				if ($data[5]==0){
					$estAdmin='f';
				}else{
					$estAdmin='t';
				}
				$params = array($data[1],$data[2],$data[3],$estAdmin,$estOk,$data[0]);
				$res = sql_gen($req,$params);
			}else{
				$req = "UPDATE utilisateurs SET
						uti_ok=$1
						WHERE uti_id=$2";
				$params = array($estOk,$data[0]);
				$res = sql_gen($req,$params);
				
			}
			
			if ($res === false){
				fwrite($fichier,$data[2].' '.$data[3].' : ERREUR');
				$maj = false;
// 			}else{
// 				fwrite($fichier,$data[2].' '.$data[3].' : OK');
			}
		}
		fclose($fichierMaj);
	}else{
		$maj = false;
	}
	
	if ($maj=== false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	$maj = true;
	
	$message .= ' - Ajout nouveaux utilisateurs : ';
	
	if (($fichierMaj= fopen("ajout_utilisateurs_SPPE_20170516.csv", "r")) !== FALSE) {
		while (($data = fgetcsv($fichierMaj, 1000, ",")) !== FALSE) {
			$req = "INSERT INTO utilisateurs
						(uti_uid_fonctionnel, uti_nom, uti_prenom, esi_id, serv_id, uti_admin)
					VALUES
						($1,$2,$3,$4,$5,$6)";
			
			if ($data[3]==0){
				$estAdmin='f';
			}else{
				$estAdmin='t';
			}
			
			$params = array($data[0],$data[1],$data[2],NULL,NULL,$estAdmin);
			$res = sql_gen($req,$params);
			
			if ($res === false){
				fwrite($fichier,$data[2].' '.$data[3].' : ERREUR');
				$maj = false;
// 			}else{
// 				fwrite($fichier,$data[2].' '.$data[3].' : OK');
			}
		}
		fclose($fichierMaj);
	}else{
		$maj = false;
	}
	
	if ($maj=== false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	/*
	 * 		MISE A JOUR DES HABILITATIONS PAR SERVICE
	 *  ========================================================================================
	 */
	echo "\n";
	echo " ===> Ajout des profils Utilisateurs\n";
	
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier,"|                        Ajout des profils Utilisateurs  		                       |\n");
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"|\n");
	fwrite($fichier,"| >>> Ajout des profils\n");
	fwrite($fichier," ------------------------------------------------------------------------------------- \n");
	fwrite($fichier,"\n");
	sql_gen('begin');
	
	$creationOk = true;
	$message= '';
	$maj = true;
	
	$message .= ' - Ajout du service CQMF : ';
	$req = "INSERT INTO services (serv_id, serv_nom, serv_ok, esi_id) VALUES ('13', 'CQMF', 't', '0');";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	$message .= ' - Ajout des profils : ';
	$req = "INSERT INTO attacher (serv_id, dom_id, profil) VALUES 
				('1', '1', '64'),
				('1', '2', '64'),
				('2', '1', '64'),
				('2', '2', '64'),
				('3', '1', '64'),
				('3', '2', '64'),
				('4', '1', '64'),
				('4', '2', '64'),
				('5', '1', '0'),
				('6', '2', '0'),
				('7', '2', '0'),
				('8', '2', '0'),
				('9', '2', '0'),
				('10', '2', '0'),
				('11', '1', '0'),
				('12', '1', '0'),
				('13', '1', '20'),
				('13', '2', '20');";
	$res = sql_gen($req);
	if ($res === false){
		$creationOk= false;
		$message.= "Erreur\n";
	}else{
		$message.= "OK\n";
	}
	
	
	
	// si une erreur c'est produite => retour arrière
	if ($creationOk){
		sql_gen('commit');
	}else{
		sql_gen('rollback');
	}
	$operationMAJ = $operationMAJ && $creationOk;
	fwrite($fichier,$message);
	
	echo "\n";
	echo " ===================================================================================== \n";
	echo "|                                                                                     |\n";
	
	fwrite($fichier,"\n");
	fwrite($fichier,"\n");
	fwrite($fichier," ===================================================================================== \n");
	fwrite($fichier,"|                                                                                     |\n");
	
	if ($operationMAJ){
		echo "|                    Mise à jour de la base SPPE réalisée avec succès                 |\n";
		fwrite($fichier,"|                     Mise à jour de la base SPPE réalisée avec succès                |\n");
	}else{
		echo "|      Erreur lors de la mise à jour de la base SPPE >>> voir le fichier de log       |\n";
		fwrite($fichier,"|       Erreur lors de la mise à jour de la base SPPE >>> voir détail ci-dessus       |\n");
	}
	fwrite($fichier,"|                                                                                     |\n");
	fwrite($fichier," ===================================================================================== \n");
	
	echo "|                                                                                     |\n";
	echo " ===================================================================================== \n";
	fclose($fichier);
?>
