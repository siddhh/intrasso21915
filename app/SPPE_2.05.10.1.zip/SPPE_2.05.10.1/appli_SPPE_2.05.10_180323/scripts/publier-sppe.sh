#!/bin/bash

# il n'y a que le nom du tag à modifier
venezia_tag="sppe-2.0.13"

venezia_appli="sppef"
venezia_user="adoc"
venezia_mdp="mar1nBret0n"
DATE=`date +%d %B %Y`

ipServeurRecette="172.16.171.10"


#récupération du dernier tag sur venezia
#echo -n -e 'Récupération du dernier tag \e[31m'${venezia_appli}'\e[39m depuis Venezia : ... ';
#venezia_tag=`svn log --username ${venezia_user} --password ${venezia_mdp} -v svn://venezia.appli.dgfip/svnroot/sppef/tags/|awk '/^   A/ { print $2 }'| grep '/tags/'${venezia_appli}''|head -1|awk -F/ '{print $NF}'`
#echo -e '\e[31m'${venezia_tag}'\e[39m'
#echo ''



function deployerSurEnvironnement {
	mkdir -p /var/tmp/${venezia_tag};
	svn export --non-interactive --username ${venezia_user} --password ${venezia_mdp} --force svn://venezia.appli.dgfip/svnroot/sppef/tags/${venezia_tag}/sppe /var/tmp/${venezia_tag};
	echo "<?php \define('VERSION', 'Version ${venezia_tag}<br>du ${DATE}');?>" > /var/tmp/${venezia_tag}/inc/version.php;
	rsync -va --exclude="*/.*"  --exclude=".svn" /var/tmp/${venezia_tag}/* $1;
	rm -rf /var/tmp/${venezia_tag};
}


PS3="Votre choix : "


echo ' 1) Connexion sur le serveur de DEV/RECETTE ('${ipServeurRecette}')'

echo ' 3) Exporter le tag '${venezia_tag}' de venezia vers le serveur de recette (user=dba)'

echo ' 99) Abandon'

read opt;
case ${opt} in
	1)ssh root@${ipServeurRecette};;

	3)deployerSurEnvironnement dba@${ipServeurRecette}:/var/www/html/sppe/;;

	99) echo "Abandon";;
	*) echo "Choix invalide";;
esac

