-- ---------------------
-- Base de données SPPE
-- JMD  -  25/04/2014  -
-- ---------------------

-- Tables ==========================================================================================

-- domaines ----------------------------------------------------------------------------------------
-- Table des grands domaines FE, FP, etc.
drop table if exists domaines cascade;
drop sequence if exists domaines_dom_id_seq;
create table domaines (
    dom_id          serial          not null    primary key,
    dom_nom         text            not null    unique,
    dom_lib         text,
    dom_ok          boolean         not null    default 't'
);
comment on table domaines
    is 'Grands domaines (FE, FP, etc.)';
comment on column domaines.dom_id
    is 'Identifiant du domaine';
comment on column domaines.dom_nom
    is 'Nom du domaine';
comment on column domaines.dom_lib
    is 'Libellé détaillé';
comment on column domaines.dom_ok
    is 'Vrai si d''actualité';

-- equipes -----------------------------------------------------------------------------------------
-- Table des équipes des bureaux d'étude
drop table if exists equipes cascade;
drop sequence if exists equipes_eqp_id_seq;
create table equipes (
    eqp_id          serial          not null    primary key,
    eqp_nom         text            not null    unique,
    eqp_lib         text,
    dom_id          integer         not null    references domaines,
    eqp_ok          boolean         not null    default 't'
);
comment on table equipes
    is 'Équipes des bureaux d''étude';
comment on column equipes.eqp_id
    is 'Identifiant de l''équipe';
comment on column equipes.eqp_nom
    is 'Nom de l''équipe';
comment on column equipes.eqp_lib
    is 'Libellé détaillé de l''équipe';
comment on column equipes.dom_id
    is 'Domaine de rattachement';
comment on column equipes.eqp_ok
    is 'Vrai si d''actualité';

-- applications ------------------------------------------------------------------------------------
-- Table des applications
drop table if exists applications cascade;
drop sequence if exists applications_app_id_seq;
create table applications (
    app_id          serial          not null    primary key,
    app_nom         text            not null    unique,
    app_lib         text,
    dom_id          integer                     references domaines,
    eqp_id          integer                     references equipes,
    app_ok          boolean         not null    default 't',
    app_timbre      timestamp       not null    default current_timestamp
);
comment on table applications
    is 'Applications';
comment on column applications.app_id
    is 'Identifiant de l''application';
comment on column applications.app_nom
    is 'Nom de l''application';
comment on column applications.app_lib
    is 'Libellé détaillé';
comment on column applications.dom_id
    is 'Domaine de rattachement';
comment on column applications.eqp_id
    is 'Équipe des bureaux d''étude';
comment on column applications.app_ok
    is 'Vrai si d''actualité';
comment on column applications.app_timbre
    is 'Marqueur de mise-à-jour';

create index ix_applications_dom_id on applications (dom_id);
create index ix_applications_eqp_id on applications (eqp_id);
create index ix_applications_app_ok on applications (app_ok);
create index ix_applications_app_timbre on applications (app_timbre);

-- chaines -----------------------------------------------------------------------------------------
-- Table des chaînes de traitement
drop table if exists chaines cascade;
drop sequence if exists chaines_chn_id_seq;
create table chaines (
    chn_id          serial          not null    primary key,
    chn_nom         text            not null    unique,
    chn_lib         text,
    app_id          integer         not null    references applications,
    chn_ok          boolean         not null    default 't',
    chn_timbre      timestamp       not null    default current_timestamp
);
comment on table chaines
    is 'Chaînes de traitement';
comment on column chaines.chn_id
    is 'Identifiant de la chaîne';
comment on column chaines.chn_nom
    is 'Nom de la chaîne';
comment on column chaines.chn_lib
    is 'Libellé détaillé';
comment on column chaines.app_id
    is 'Application de rattachement';
comment on column chaines.chn_ok
    is 'Vrai si d''actualité';
comment on column chaines.chn_timbre
    is 'Marqueur de mise-à-jour';

create index ix_chaines_app_id on chaines (app_id);
create index ix_chaines_chn_ok on chaines (chn_ok);
create index ix_chaines_chn_timbre on chaines (chn_timbre);

-- esi ---------------------------------------------------------------------------------------------
-- Table des ESI
drop table if exists esi cascade;
drop sequence if exists esi_esi_id_seq;
create table esi (
    esi_id          serial          not null    primary key,
    esi_nom         text            not null    unique,
    esi_ok          boolean         not null    default 't'
);
comment on table esi
    is 'ESI des DISI';
comment on column esi.esi_id
    is 'Identifiant de l''ESI';
comment on column esi.esi_nom
    is 'Libellé de l''ESI';
comment on column esi.esi_ok
    is 'Vrai si d''actualité';

-- processus ---------------------------------------------------------------------------------------
-- Table des processus
drop table if exists processus cascade;
drop sequence if exists processus_pro_id_seq;
create table processus (
    pro_id          serial          not null    primary key,
    pro_nom         text            not null    unique,
    pro_lib         text,
    pro_regle       text            not null,
    pro_reglehtml   text,
    pro_index       integer         not null    unique,
    pro_debut       date,
    pro_fin         date,
    pro_suivi       boolean,
    pro_rupture     boolean,
    pro_vindex      integer         not null    unique,
    pro_version     text,
    pro_libelle     text,
    pro_nouveautes  text,
    pro_ajustable   boolean,
    pro_timbre      timestamp       not null    default current_timestamp
);
comment on table processus
    is 'Processus';
comment on column processus.pro_id
    is 'Identifiant du processus';
comment on column processus.pro_nom
    is 'Nom du processus';
comment on column processus.pro_lib
    is 'Libellé du processus';
comment on column processus.pro_regle
    is 'Règle de mise au plan telle que codifiée dans LEONARD';
comment on column processus.pro_reglehtml
    is 'Règle de mise au plan telle que codifiée dans LEONARD (affichable)';
comment on column processus.pro_index
    is 'Index dans LEONARD';
comment on column processus.pro_debut
    is 'Début de validité';
comment on column processus.pro_fin
    is 'Fin de validité';
comment on column processus.pro_suivi
    is 'Suivi simplifié dans SPPE';
comment on column processus.pro_rupture
    is 'Si au moins un job avec attente ou de nuit';
comment on column processus.pro_vindex
    is 'Index version pour lien LEONARD';
comment on column processus.pro_version
    is 'Version du processus';
comment on column processus.pro_libelle
    is 'Libellé de la version du processus';
comment on column processus.pro_nouveautes
    is 'Nouveautés de la version du processus';
comment on column processus.pro_ajustable
    is 'Règle de planification ajustable en gestion des dates';
comment on column processus.pro_timbre
    is 'Marqueur de mise-à-jour';

create index ix_processus_pro_timbre on processus (pro_timbre);

-- ressort -----------------------------------------------------------------------------------------
-- Ressort des ESI sur les processus
drop table if exists ressort cascade;
create table ressort (
    pro_id          integer         not null    references processus,
    esi_id          integer         not null    references esi
);
comment on table ressort
    is 'Ressort des ESI sur les processus';
comment on column ressort.pro_id
    is 'Identifiant du processus';
comment on column ressort.esi_id
    is 'Identifiant de l''ESI';
create index ix_ressort_pro_id on ressort (pro_id);
create index ix_ressort_esi_id on ressort (esi_id);
create unique index ix_ressort_unicite on ressort (pro_id, esi_id);

-- utilisateurs ------------------------------------------------------------------------------------
-- Table des comptes utilisateurs
drop table if exists utilisateurs cascade;
drop sequence if exists utilisateurs_uti_id_seq;
create table utilisateurs (
    uti_id          serial          not null    primary key,
    uti_login       text            not null    unique,
    uti_mdp         text            not null,
    uti_nom         text            not null    unique,
    uti_droits      char                        check(uti_droits in ('E','B','S','C')),
    uti_mois        boolean         not null    default 't',
    esi_id          integer                     references esi,
    eqp_id          integer                     references equipes,
    uti_sel_dom     integer                     references domaines(dom_id),
    uti_sel_app     text,
    uti_sel_chn     integer                     references chaines(chn_id),
    uti_sel_pro     integer                     references processus(pro_id),
    uti_sel_cal     boolean,
    uti_sel_sui     boolean         not null    default 't',
    uti_ok          boolean         not null    default 't',
    uti_timbre      timestamp       not null    default current_timestamp
);
comment on table utilisateurs
    is 'Utilisateurs';
comment on column utilisateurs.uti_id
    is 'Identifiant de l''utilisateur';
comment on column utilisateurs.uti_login
    is 'Nom de connexion';
comment on column utilisateurs.uti_mdp
    is 'Mot de passe';
comment on column utilisateurs.uti_nom
    is 'Nom complet de l''utilisateur';
comment on column utilisateurs.uti_droits
    is 'Droits : null=standards, E=ESI, B=Bureau d''Etude, S=SI-2A, C=CQMF';
comment on column utilisateurs.uti_mois
    is 'Préférence calendrier : true=mois, false=semaine';
comment on column utilisateurs.esi_id
    is 'Identifiant de l''ESI de rattachement, ou null';
comment on column utilisateurs.eqp_id
    is 'Équipe bureau d''étude ou null';
comment on column utilisateurs.uti_sel_dom
    is 'Domaine de rattachement par défaut ou null';
comment on column utilisateurs.uti_sel_app
    is 'Application ou équipe sélectionnée par défaut ou null';
comment on column utilisateurs.uti_sel_chn
    is 'Chaîne par défaut ou null';
comment on column utilisateurs.uti_sel_pro
    is 'Processus par défaut';
comment on column utilisateurs.uti_sel_cal
    is 'Calendrier par défaut, vrai = semaine, mois sinon';
comment on column utilisateurs.uti_sel_sui
    is 'Afficher le suivi simplifié';
comment on column utilisateurs.uti_ok
    is 'Vrai si utilisateur actif';
comment on column utilisateurs.uti_timbre
    is 'Dernière connexion de l''utilisateur';

-- plan --------------------------------------------------------------------------------------------
-- Table des mises au plan
drop table if exists plan cascade;
drop sequence if exists plan_pln_id_seq;
create table plan (
    pln_id          serial          not null    primary key,
    pro_id          integer         not null    references processus,
    pro_version     text,
    pln_debut       date,
    pln_fin         date,
    pln_debut_calc  date,
    pln_fin_calc    date,
    pln_butoir      date,
    uti_id          integer                     references utilisateurs,
    pln_timbre      timestamp       not null    default current_timestamp,
    pln_confirm     boolean         not null    default false,
    pln_suppr       boolean         not null    default false,
    pln_notes       text,
    pln_report      integer
);
comment on table plan
    is 'Mises au plan';
comment on column plan.pln_id
    is 'Identifiant de la mise au plan';
comment on column plan.pro_id
    is 'Processus concerné';
comment on column plan.pro_version
    is 'Version du processus';
comment on column plan.pln_debut
    is 'Date de début prévue';
comment on column plan.pln_fin
    is 'Date de fin prévue';
comment on column plan.pln_debut_calc
    is 'Date de début calculée';
comment on column plan.pln_fin_calc
    is 'Date de fin calculée';
comment on column plan.pln_butoir
    is 'Date butoir';
comment on column plan.uti_id
    is 'Dernier modification ou NULL si calculées';
comment on column plan.pln_timbre
    is 'Marqueur de mise-à-jour';
comment on column plan.pln_confirm
    is 'Vrai si la date de début est confirmée';
comment on column plan.pln_suppr
    is 'Vrai si l''occurrence est supprimée';
comment on column plan.pln_notes
    is 'Commentaires sur la mise au plan';
comment on column plan.pln_report
    is 'Année de mise au plan par report';

create index ix_plan_pro_id on plan (pro_id);
create index ix_plan_pln_debut on plan (pln_debut);
create index ix_plan_pln_butoir on plan (pln_butoir);
create index ix_plan_pln_fin on plan (pln_fin);
create index ix_plan_pln_timbre on plan (pln_timbre);
create index ix_plan_pln_confirm on plan (pln_confirm);
create index ix_plan_pln_suppr on plan (pln_suppr);
create index ix_plan_pln_report on plan (pln_report);

-- realise -----------------------------------------------------------------------------------------
-- Table des dates du réalisé par ESI
drop table if exists realise cascade;
create table realise (
    pln_id          integer         not null    references plan,
    esi_id          integer         not null    references esi,
    uti_id          integer         not null    references utilisateurs,
    rea_debut       date,
    rea_fin         date,
    rea_statut      char                        check (rea_statut in ('A','T')),
    rea_timbre      timestamp       not null    default current_timestamp,
    rea_notes       text
);
comment on table realise
    is 'Réalisé par ESI';
comment on column realise.pln_id
    is 'Mise au plan';
comment on column realise.esi_id
    is 'ESI';
comment on column realise.uti_id
    is 'Utilisateur';
comment on column realise.rea_debut
    is 'Date de début réelle';
comment on column realise.rea_fin
    is 'Date de fin réelle';
comment on column realise.rea_statut
    is 'Statut : null = en cours, T = terminé, A = abort';
comment on column realise.rea_timbre
    is 'Marqueur de mise-à-jour';
comment on column realise.rea_notes
    is 'Commentaires';

create index ix_realise_pln_id on realise (pln_id);
create index ix_realise_esi_id on realise (esi_id);
create unique index ix_realise_unicite on realise (pln_id, esi_id);

-- membrex -----------------------------------------------------------------------------------------
-- Table générique des jobs des processus
drop table if exists membrex cascade;
drop sequence if exists membrex_mbx_id_seq;
create table membrex (
    mbx_id          serial          not null    primary key,
    mbx_nom         text            not null    unique,
    mbx_lib         text,
    chn_id          integer         not null    references chaines,
    mbx_rupture     boolean,
    mbx_exclus      text,
    mbx_inclus      text,
    mbx_etendue     text,
    mbx_type        text,
    mbx_mac_nom     text,
    mbx_mac_index   integer
);
comment on table membrex
    is 'Description générique des jobs';
comment on column membrex.mbx_id
    is 'Identifiant du membrex';
comment on column membrex.mbx_nom
    is 'Nom du membrex';
comment on column membrex.mbx_lib
    is 'Libellé du membrex';
comment on column membrex.chn_id
    is 'Chaîne de rattachement';
comment on column membrex.mbx_rupture
    is 'Job avec attente ou de nuit';
comment on column membrex.mbx_exclus
    is '*** pour utilisation ultérieure ***';
comment on column membrex.mbx_inclus
    is '*** pour utilisation ultérieure ***';
comment on column membrex.mbx_etendue
    is '*** pour utilisation ultérieure ***';
comment on column membrex.mbx_type
    is '*** pour utilisation ultérieure ***';
comment on column membrex.mbx_mac_nom
    is '*** pour utilisation ultérieure ***';
comment on column membrex.mbx_mac_index
    is '*** pour utilisation ultérieure ***';

-- liens -------------------------------------------------------------------------------------------
-- liens membrex / processus
drop table if exists liens cascade;
create table liens (
    pro_id          integer         not null    references processus,
    pro_version     text,
    mbx_id          integer         not null    references membrex
);
comment on table liens
    is 'Liens entre les membrex et leur processus';
comment on column liens.pro_id
    is 'Identifiant du processus';
comment on column liens.pro_version
    is 'Dernière version comprenant ce processus';
comment on column liens.mbx_id
    is 'Identifiant du membrex';

create index ix_liens_pro_id on liens (pro_id);
create index ix_liens_mbx_id on liens (mbx_id);
create unique index ix_liens_unicite on liens (pro_id, mbx_id);

-- liste -------------------------------------------------------------------------------------------
-- liste des chaînes pour un processus et une version donnés
drop table if exists liste cascade;
create table liste (
    pro_id          integer         not null    references processus,
    pro_version     text,
    lst_chaines     text
);
comment on table liste
    is 'Liste statique des chaînes présentent dans un processus';
comment on column liste.pro_id
    is 'Identifiant du processus';
comment on column liste.pro_version
    is 'Version du processus';
comment on column liste.lst_chaines
    is 'Liste des chaînes';

create index ix_liste_pro_id on liste (pro_id);

-- recalcul ----------------------------------------------------------------------------------------
-- table des processus à (re)calculer
drop table if exists recalcul cascade;
create table recalcul (
    pro_id          integer         not null    primary key references processus
);
comment on table recalcul
    is 'Processus à (re)calculer';
comment on column recalcul.pro_id
    is 'Identifiant du processus';

-- statut ------------------------------------------------------------------------------------------
-- table pour gérer le statut de l'application (verrous en autres)
drop table if exists statut cascade;
create table statut (
    objet           varchar(10)     not null    primary key,
    valeur          text
);
comment on table statut
    is 'Gestion de différents statuts dans SPPE';
comment on column statut.objet
    is 'Nom, statut';
comment on column statut.valeur
    is 'Valeur associée';

-- Peuplement des bases ============================================================================

-- domaines
insert into domaines (dom_nom, dom_lib) values('FE', 'Fiscalité des Entreprises');     -- 1
insert into domaines (dom_nom, dom_lib) values('FP', 'Fiscalité des Particuliers');    -- 2

-- equipes
insert into equipes (eqp_nom, dom_id) values('MEDOC', 1);       -- 1
insert into equipes (eqp_nom, dom_id) values('FIP', 2);         -- 2
insert into equipes (eqp_nom, dom_id) values('HR-ISF-TH', 2);   -- 3
insert into equipes (eqp_nom, dom_id) values('IR-SFP', 2);      -- 4
insert into equipes (eqp_nom, dom_id) values('SIR', 2);         -- 5
insert into equipes (eqp_nom, dom_id) values('TOPAD', 2);       -- 6
insert into equipes (eqp_nom, dom_id) values('TSE', 1);         -- 7
insert into equipes (eqp_nom, dom_id) values('FE-SI1C', 1);     -- 8


-- applications
insert into applications (app_nom, eqp_id, dom_id) values('ACF', 8, 1);
insert into applications (app_nom, eqp_id, dom_id) values('BRP', 8, 1);
insert into applications (app_nom, eqp_id, dom_id) values('CEE', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('FIP', 2, 2);
insert into applications (app_nom, eqp_id, dom_id) values('HR', 3, 2);
insert into applications (app_nom, eqp_id, dom_id) values('IR', 4, 2);
insert into applications (app_nom, eqp_id, dom_id) values('ISF', 3, 2);
insert into applications (app_nom, eqp_id, dom_id) values('MDA', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MDC', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MDG', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MDI', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MDR', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MDU', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MED', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MFA', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('MTP', 8, 1);
insert into applications (app_nom, eqp_id, dom_id) values('NPC', 8, 1);
insert into applications (app_nom, eqp_id, dom_id) values('SFE', 1, 1);
insert into applications (app_nom, eqp_id, dom_id) values('SFP', 4, 2);
insert into applications (app_nom, eqp_id, dom_id) values('SIR', 5, 2);
insert into applications (app_nom, eqp_id, dom_id) values('TH', 3, 2);
insert into applications (app_nom, eqp_id, dom_id) values('TOP', 6, 2);
insert into applications (app_nom, eqp_id, dom_id) values('TSE', 7, 1);
insert into applications (app_nom, eqp_id, dom_id) values('VN', 8, 1);

-- esi
insert into esi (esi_nom) values('Clermont-Ferrand Guichard');  -- 1
insert into esi (esi_nom) values('Marseille Saint-Loup');       -- 2
insert into esi (esi_nom) values('Nantes Marsauderies');        -- 3
insert into esi (esi_nom) values('Reims');                      -- 4

-- utilisateurs
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('sppe', 'x', 'Utilisateur TEST', 'E', 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits)
    values ('cqmf', 'x', 'Utilisateur CQMF', 'C');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('ctfdfe', 'x', 'Clermont-Fd FE', 'E', 1, 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('ctfdfp', 'x', 'Clermont-Fd FP', 'E', 1, 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('marsfe', 'x', 'Marseille FE', 'E', 2, 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('marsfp', 'x', 'Marseille FP', 'E', 2, 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('nantfe', 'x', 'Nantes FE', 'E', 3, 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('nantfp', 'x', 'Nantes FP', 'E', 3, 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('reimfe', 'x', 'Reims FE', 'E', 4, 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id, uti_sel_dom)
    values ('reimfp', 'x', 'Reims FP', 'E', 4, 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits)
    values ('si2a', 'x', 'Utilisateur SI-2A', 'S');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, eqp_id, uti_sel_dom, uti_sel_app)
    values ('si2abe', 'x', 'B.E. MEDOC SI-2A', 'B', 1, 1, 'E1');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits)
    values ('si2acq', 'x', 'CQMF SI-2A', 'C');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('si2aec', 'x', 'SI-2A Clermont-Fd', 'E', 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('si2aem', 'x', 'SI-2A Marseille', 'E', 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('si2aen', 'x', 'SI-2A Nantes', 'E', 3);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('si2aer', 'x', 'SI-2A Reims', 'E', 4);
insert into utilisateurs (uti_login, uti_mdp, uti_nom)
    values ('lambda', 'x', 'Utilisateur lambda');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits)
    values ('dev', 'x', 'Utilisateur Dével.', 'S');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, eqp_id, uti_sel_dom, uti_sel_app)
    values ('devbe', 'x', 'B.E. MEDOC Dével.', 'B', 1, 1, 'E1');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits)
    values ('devcq', 'x', 'CQMF Dével.', 'C');
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('devec', 'x', 'Dével. Clermont-Fd', 'E', 1);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('devem', 'x', 'Dével. Marseille', 'E', 2);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('deven', 'x', 'Dével. Nantes', 'E', 3);
insert into utilisateurs (uti_login, uti_mdp, uti_nom, uti_droits, esi_id)
    values ('dever', 'x', 'Dével. Reims', 'E', 4);

-- statut
-- verrou de calcul ou de report en cours
--  * verrou : on / off 
insert into statut (objet, valeur)
    values ('verrou', 'off');
--  * report : on / off (affichage des boutons)
insert into statut (objet, valeur)
    values ('report', 'on');

-- --------------------
-- ------- FIN --------
-- --------------------
