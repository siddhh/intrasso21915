#!/usr/bin/perl
# cree_jobs.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Création des jobs pour les processus mis au plan à ± 8 jours.
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 11 mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use DBI;
use utf8;

use Reel_fonctions;

no utf8;

# actualise_jobs -----------------------------------------------------------------------------------
# Actualisation des jobs pour les membreX sélectionnés
#
# Règle de gestion :
# ------------------
# Règle de base : mbx abcdefgX pour domaine 000 => job abcde000fg
#
# Pour les JOBs transmis par Léonard on gère de la façon suivante :
#  - on se limite aux 8 1ers caractères, on ignore les autres;
#  - le 8ème devrait être un "X";
#
# Si le 8è caractère du JOB est un G, pas de réalisé possible,
# aucun job lancé par SPPE, on ignore ce job
# si le 8ème caractère est un blanc, on le gère comme si on avait un X,
# on recherche donc un JOB OPS de même nom(7c)
# MINIQUERY est un test, il va disparaitre
# RE-AMIA et MDAMQ83S n'ont pas de réalisé, à traiter comme les JOB 7cG
# la série MDA-MDC se terminant par C ou S, on recherche un JOB OPS de même nom
# ou avec leur nom en remplaçant le 3ème et 4ème caractère par QY
# si ces 2 caractères sont différents de QY
# on aura donc  MDAMQ15S  <--> MDAQYdom15
#               MDAQY39C       MDAQYdom39
#               MDAQY3AS       MDAQYdom3A
#               MDAQY95C       MDAQYdom95
#               MDCMQ13S       MDCQYdom13
#               MDCMQ16S       MDCQYdom16
# FIPCT correspond à FIPCT04X, job lancé sous OPS FIPCTdom04.
#
# $db : connexion à la base

	sub actualise_jobs {

	# ARGUMENTS --
	my ($db) = @_;
	# ------------

	my $mid;    # identifiant d'un membreX
	my $nom;    # nom du membreX
	my $pid;    # identifiant d'une mise au plan
	my $pre;    # processus suivi dans le réalisé
	my $typ;    # type de traitement
	my $ete;    # étendue selon LEONARD
	my $inc;    # inclus
	my $exc;    # exclus
	my $ent;    # entités traduites SPPE
	my $sql;    # ressource

    # Lecture des membreX

    my $req = qq{ select mbx_id, mbx_nom, pln_id,
            mbx_type, mbx_etendue, mbx_inclus, mbx_exclus
        from mbx };
    my $sql2 = $db->prepare($req);
    $sql2->execute() or abandon(2, $DBI::errstr);
    while (($mid, $nom, $pid, $typ, $ete, $inc, $exc) = $sql2->fetchrow_array) {

        # jobs ignorés ou sans réalisé
        my $ok = 1;
        if (length $nom > 7) {
            if (substr($nom, 7, 1) eq 'G' or $nom eq 'MINIQUERY') {
                $ok = 0;
            }
        } else {
            if ($nom eq 'RE-AMIA' or $nom eq 'MDAMQ83S') {
                $ok = 0;
            }
        }

        if ($ok) {

            # restrictions
            $typ = uc(substr($typ, 0, 3));
            $ent = '';
            if (uc(trim($ete)) eq 'TOUT') {
                $exc = trim($exc);
                if ($exc ne '') {
                    # exclus
                    $ent = " and e.ent_lib not in ('".join("','", split(/,/, $exc))."')";
                }
            } else {
                $inc = trim($inc);
                if ($inc ne '') {
                    # inclus (seulement ceux-là)
                    $ent = " and e.ent_lib in ('".join("','", split(/,/, $inc))."')";
                }
            }

            #print $mid.' '.$typ.' '.$ete.' '.$inc.' '.$exc.' '.$ent."\n";

            # insertion des jobs correspondants qui n'existent pas encore
            # avec (malheureusement) le traitement spécifique à FIPCT
            $req = qq{ insert into jobs (job_lib, mbx_id, pln_id, ent_id, esi_id)
                select case
                    when substring(m.mbx_nom from 1 for 5) in ('MDAMQ','MDCMQ') and
                         substring(m.mbx_nom from 8 for 1) in ('C','S')
                    then substring(m.mbx_nom from 1 for 3)||'QY'||e.ent_code||
                         substring(m.mbx_nom from 6 for 2)
                    else substring(m.mbx_nom from 1 for 5)||e.ent_code||case
                        when m.mbx_nom='FIPCT'
                        then '04'
                        else substring(m.mbx_nom from 6 for 2)
                        end
                    end, ?, ?, e.ent_id,
                    coalesce(e.esi_id, (select i.esi_id from esi i
                        where substring(m.mbx_mac_nom from 6 for 4)=i.esi_gcos))
                from membrex m
                    join cibles c on c.cib_code=upper(substring(m.mbx_type from 1 for 3))
                    join groupes g on g.cib_id=c.cib_id
                    join entites e on e.ent_id=g.ent_id
                where m.mbx_id=?
                    and not exists(
                        select *
                        from jobs j
                        where j.mbx_id=m.mbx_id and j.pln_id=? and j.ent_id=e.ent_id) }.$ent;
            $sql = $db->prepare($req);
            $sql->execute($mid, $pid, $mid, $pid) or abandon(2, $DBI::errstr);

            # suppression des jobs devenus sans objet
            $req = qq{ delete from jobs j
                where j.mbx_id=?
                    and j.pln_id=?
                    and j.ent_id not in (
                        select e.ent_id
                        from membrex m
                            join cibles c on c.cib_code=upper(substring(m.mbx_type from 1 for 3))
                            join groupes g on g.cib_id=c.cib_id
                            join entites e on e.ent_id=g.ent_id
                        where m.mbx_id=j.mbx_id }.$ent.')';
            $sql = $db->prepare($req);
            $sql->execute($mid, $pid) or abandon(2, $DBI::errstr);
        }
    }

    # FIXME : patch pour corriger d'éventuels jobs pour lesquels esi_id est à null
    # alors que le domaine permet de déterminer l'ESI (c'est produit une fois)
    # À déterminer pourquoi ce genre de chose peut se présenter...
    $req = qq{ update jobs j
        set esi_id=(select e.esi_id
                    from entites e
                    where e.ent_code=substring(j.job_lib from 6 for 3))
        where esi_id is null };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);
}

# ajoute_jour --------------------------------------------------------------------------------------
# Ajoute les membreX pour une journée donnée
# $db : connexion à la base
# $decale : décalage par rapport au jour courant
# $dateref : date de référence
sub ajoute_jour {

    # ARGUMENTS ---------------------
    my ($db, $decale, $dateref) = @_;
    # -------------------------------

    my $req = qq{	INSERT INTO mbx
        				(mbx_id, mbx_nom, mbx_type, mbx_etendue, mbx_inclus, mbx_exclus, pln_id)
    				SELECT m.mbx_id, m.mbx_nom, m.mbx_type, m.mbx_etendue, m.mbx_inclus, m.mbx_exclus, q.pln_id
    				FROM plan q
        			JOIN processus p ON p.pro_id=q.pro_id
        			JOIN liens l ON l.pro_id=p.pro_id AND l.pro_version=p.pro_version
        			JOIN membrex m ON m.mbx_id=l.mbx_id
    				WHERE (?::date + ?::smallint) BETWEEN q.pln_debut AND q.pln_fin
        			AND NOT EXISTS(SELECT t.* FROM mbx t WHERE t.mbx_id=m.mbx_id AND t.pln_id=q.pln_id) 
            	};
    my $sql = $db->prepare($req);
    $sql->execute($dateref, $decale) or abandon(2, $DBI::errstr);
}

# cree_table_ref -----------------------------------------------------------------------------------
# Création d'une table temporaire de référence
# $db : connexion à la base
sub cree_table_ref {

    # ARGUMENTS --
    my ($db) = @_;
    # ------------

    my $req = qq{ create temp table mbx (
            mbx_id       integer,
            mbx_nom      text,
            mbx_type     text,
            mbx_etendue  text,
            mbx_inclus   text,
            mbx_exclus   text,
            pln_id       integer
        ); };
    my $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# date de référence

my $dateref = '';
if (@ARGV > 0) {
    $dateref = $ARGV[0];
} else {
    abandon(6);
}

my $db = connexion();           # connexion à la base de données

cree_table_ref($db);            # création d'une table temporaires pour stocker les membreX

my $i = -8;                     # on prend tous les processus à ± 8 jours
while ($i < 10) {               # +1 au cas où la log change de jour en son sein

    ajoute_jour($db, $i, $dateref);
    $i++;
}

actualise_jobs($db);            # actualisation des jobs 

deconnexion($db);               # fermeture de la base
exit 0;

# FIN ----------------------------------------------------------------------------------------------
