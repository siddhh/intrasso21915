#!/usr/bin/perl
# reel_GCOS.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Réalisé automatique : traitement de la log GCOS (accounting)
# Programme appelé par realise.sh
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 20 avril 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use DBI;
use utf8;
use Storable;
use DateTime;
use Text::CSV_XS;
use Data::Dumper;
use File::Basename;

use Reel_fonctions;

no utf8;

# horodatage ---------------------------------------------------------------------------------------
# Construit un timestamp à partir de la date et de l'heure lues dans la log
# $da : date
# $he : heure
# --> retourne le timestamp
sub horodatage {

    # ARGUMENTS -------
    my ($da, $he) = @_;
    # -----------------

    return substr($da,0,4).'-'.substr($da,4,2).'-'.substr($da,6,2)
        .' '.substr($he,0,2).':'.substr($he,2,2).':'.substr($he,4,2);
}

# traite_step --------------------------------------------------------------------------------------
# Traitement d'un step lu dans la log
# $db : connexion base
# $esi : identifiant ESI
# $ligne : ligne le la log
sub traite_step {

    # ARGUMENTS ----------------
    my ($db, $esi, $ligne) = @_;
    # --------------------------

    my $job = @$ligne[10];
    my $ron = @$ligne[2];

    # recherche d'un job candidat
    my $req = qq{ select job_id
        from jobs
        where job_ron=? and substring(job_lib from 1 for 8)=? and esi_id=?
        order by job_debut desc
        limit 1 };
    my $sql = $db->prepare($req);
    $sql->execute($ron, $job, $esi) or abandon(2, $DBI::errstr);
    if (my $id = $sql->fetchrow_array) {
        $req = qq{ insert into steps
            (job_id, stp_lib, stp_etat, stp_debut, stp_fin, stp_elapsed, stp_cpu)
            values (?, ?, ?, ?, ?, ?, ?) };
        $sql = $db->prepare($req);
        $sql->execute($id, @$ligne[8], @$ligne[9],
            horodatage(@$ligne[0], @$ligne[1]), horodatage(@$ligne[4], @$ligne[5]),
            @$ligne[7], @$ligne[6]);
    }
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# fichier en argument
my $flog = '';
if (@ARGV > 0) {
    $flog = $ARGV[0];
}

my ($sec, $min, $hr, $day, $mon, $year) = localtime;
printf("%02d:%02d:%02d", $hr, $min, $sec);
print ' : log '.$flog."\n";

my $errmsg = ' dans reel_GCOS.pl';
abandon(3, $errmsg) if ($flog eq '');
abandon(4, $errmsg) if (not -f $flog);

if (not -s $flog) {
    print "Fichier vide\n";
    exit 0;
}

# ouverture du fichier log à traiter
my $log;
abandon(4, $errmsg) if (not open($log, '<', $flog));
my $jobs = retrieve('jobs.jour');   # récupération des jobs potentiels
my $db = connexion('begin');        # connexion à la base de données et ouverture de transaction
my $csv = Text::CSV_XS->new({ sep_char => ';', binary => 1 });

# identification de l'ESI dont est issu la log à partir des 4 premières lettres du nom de la log
my $esi = identifie_esi($db, substr(basename($flog), 9, 4));
if ($esi == 0) {
     $esi = identifie_esi($db, substr(basename($flog), 0, 4));
}
if ($esi == 0) {
    print "ESI non identifié !\n";
} else {
    # lecture et traitement de la log
    while (my $ligne = $csv->getline($log)) {
        # print Dumper(@$ligne)."\n";
        if (@$ligne[3] eq '02') {
            traite_step($db, $esi, $ligne);
        }
    }
}

close($log);                    # fermeture du fichier log
deconnexion($db, 'commit');     # fermeture transaction et base
exit 0;
# fin
