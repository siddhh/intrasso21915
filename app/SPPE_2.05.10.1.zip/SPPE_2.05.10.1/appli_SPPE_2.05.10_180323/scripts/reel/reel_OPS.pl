#!/usr/bin/perl
# reel_OPS.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Réalisé automatique : traitement de la log OPS
# Programme appelé par realise.sh
# En argument, le fichier log à traiter
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use DBI;
use utf8;
use Storable;
use DateTime;
use Data::Dumper;

use Reel_fonctions;

no utf8;

# partagé ------------------------------------------------------------------------------------------

my %etats = ( COMPLETED => 'T', ERROR => 'A', EXECUTION => 'X');

# applications -------------------------------------------------------------------------------------
# Dresse la liste des applications
# $db : connexion base de données
# --> retourne un tableau des applications
sub applications {

    # ARGUMENTS --
    my ($db) = @_;
    # ------------

    my %app = ();

    my $req = "select app_nom from applications";
    my $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    my $nom;
    while (($nom) = $sql->fetchrow_array) {
        $app{$nom} = 1;
    }

    return %app;
}

# debut_log ----------------------------------------------------------------------------------------
# Lecture de la première ligne du fichier pour déterminer la machine
# $log : fichier log
# --> retourne la machine
sub debut_log {

    # ARGUMENTS ---
    my ($log) = @_;
    # -------------

    my $rc = '';
    my $ligne;
    my @cols;
    my $c = 0;
    my $i = 0;
    my $l = 0;

    while ($i < 10 and ($c < 10 or $l != 4)) {
        $ligne = <$log>;
        @cols = split(/\|/, $ligne);
        $c = @cols;
        if ($c > 2) {
            $l = length trim($cols[1]);
        }
        $i++;
    }
    # repositionnement
    seek $log, 0, 0;

    while ($i>1) {
        $ligne = <$log>;
        $i--;
    }

    if ($c > 2) {
        $rc = trim($cols[1]);
    }
    return $rc;
}

# iso ----------------------------------------------------------------------------------------------
# Formate la date lue dans la log pour PostgreSQL
# $dl : date lue
# --> retourne la date au format ISO PostgreSQL
sub iso {

    # ARGUMENTS --
    my ($dl) = @_;
    # ------------

    # bug de l'an 2100...
    my $rc = '20'.substr($dl, 0, 2).'-'.substr($dl, 2, 2).'-'.
        substr($dl, 4, 5).':'.substr($dl, 9, 2).':'.substr($dl, 11, 2);

    return $rc;
}

# message ------------------------------------------------------------------------------------------
# Messages d'anomalie ou d'avertissement
# $num : numéro
# @infos : informations complémentaires
sub message {

    # ARGUMENTS -----------
    my ($num, @infos) = @_;
    # ---------------------

    my $msg = '  ['.$num.'] ';

    if ($num == 1) {
        $msg .= 'Domaine inconnu pour le JOB '.$infos[0];
    }

    elsif ($num == 2) {
        $msg .= 'MAJ du réalisé impossible pour le JOB '.$infos[0]
            .' avec le domaine '.substr($infos[0], 5, 3)
            .', n° RON '.$infos[1]." :\n      il existe plusieurs processus comportant "
            ."ce JOB définis sur la période.\n      Processus trouvés : ".$infos[2]
            .".\n      La MAJ devra être réalisée manuellement.";
    }

    elsif ($num == 3) {
        $msg .= 'Aucun rattachement possible à un processus existant pour le JOB '.$infos[0];        
    }

    elsif ($num == 4) {
        $msg .= 'AVERTISSEMENT : Le JOB '.$infos[0]
            .' pour le domaine '.substr($infos[0], 5, 3)
            .' en date du '.$infos[1].', n° RON '.$infos[2]
            ."\n      a été rattaché au processus ".$infos[3]
            .' prévu du '.$infos[4].' au '.$infos[5];
    }
    print $msg."\n";
}

# neutralise ---------------------------------------------------------------------------------------
# Vérifie si un job est neutralisé
# $job : job
# $jobsref : tableau des jobs neutralisés
# --> retourne vrai ou faux
sub neutralise {

    # ARGUMENTS -------------
    my ($job, $jobsref) = @_;
    # -----------------------

    my $rc = 0;
    my @jobs = @$jobsref;
    foreach my $neutra (@jobs) {
        my $deb = substr($neutra, 0, 5);
        my $fin = substr($neutra, 5);
        $rc = ($job =~ /${deb}...${fin}/);
        last if $rc;
    }
    return $rc;
}

# realise ------------------------------------------------------------------------------------------
# Prend en compte le réalisé pour le job fourni avec les informations qui figurent sur la ligne
# $db : base de données
# $jobsref : tableau de tableaux des jobs candidats
# $esi : identifiant de l'ESI
# $ss : 1=suivi simplifié, 0=suivi normal
# $decale : décalage par rapport au jour courant
# $job : libellé du job traité
# @cols : colonnes de la ligne lue
# --> retourne 1 sauf quand hors champ du suivi simplifié
sub realise {

    # ARGUMENTS ---------------------------------------------
    my ($db, $jobsref, $esi, $ss, $decale, $job, @cols) = @_;
    # -------------------------------------------------------

    my $ok = 1;

    # tableaux des jobs candidats
    # 0 : nombre de processus correspondants, si >1, alors impossible d'identifier l'origine
    # 1 : identifiant du job
    # 2 : à 1 si on est en suivi simplifié, à 0 sinon
    # 3 : nom du processus
    # 4 : mise au plan, date de début
    # 5 : mise au plan, date de fin

    my @jobs = @$jobsref;
    my $id = $jobs[0][1];

    my $ron = substr(trim($cols[4]), 1);

    # cas d'anomalies : plusieurs processus candidats
    if ($jobs[0][0] > 1) {
        my $proc = '';
        foreach my $jobref (@jobs) {
            my @job = @$jobref;
            $proc .= $job[3].', ';
        }
        $proc = substr($proc, 0, length($proc) - 2);
        message(2, $job, $ron, $proc);
        return 1;
    }

    # suivi simplifié
    if ($jobs[0][2] and not $ss) {
        # hors champ du suivi simplifié
        return 0;
    }

    # hors délai ou anticipé
    if ($decale) {
        message(4, $job, substr($cols[2], 0, 6), $ron, $jobs[0][3], $jobs[0][4], $jobs[0][5]);
    }

    my $etat = $etats{trim($cols[5])};
    my $deb = iso($cols[2]);

    my $req;
    my $sql;

    # traitement des cas de réfection
    my $ancdeb = substr($jobs[0][6], 0, 19);

    if ($ancdeb and $deb gt $ancdeb) {
        # print $deb.' '.$ancdeb.' '.$ron.' '.$jobs[0][3]."\n";
        # insertion d'un nouveau job
        $req = qq{ insert into jobs (job_lib, mbx_id, pln_id, ent_id)
            select job_lib, mbx_id, pln_id, ent_id
            from jobs
            where job_id=?
            returning job_id
        };
        $sql = $db->prepare($req);
        $sql->execute($id) or abandon(2, $DBI::errstr);
        my @lu = $sql->fetchrow_array;
        # marquage du précédent comme n'étant plus le dernier
        $req = qq{ update jobs set job_dernier='f' where job_id=? };
        $sql = $db->prepare($req);
        $sql->execute($id) or abandon(2, $DBI::errstr);
        # prise en compte du nouvel identifiant
        $id = $lu[0];
        # persistence PERL
        $jobs[0][1] = $id;
        $jobs[0][6] = $deb;
    }

    # actualisation du job en base (sauf si déjà marqué terminé)
    if ($etat eq 'X') {
        # pas de date de fin pour les jobs en cours d'exécution
        $req = qq{ update jobs
            set esi_id=?, job_debut=?, job_ron=?, job_etat=?
            where job_id=? and (job_etat!='T' or job_etat is null) };
        $sql = $db->prepare($req);
        $sql->execute($esi, $deb, $ron, $etat, $id) or abandon(2, $DBI::errstr);
    } else {
        # date de fin pour les autres
        my $fin = iso($cols[6]);
        $req = qq{ update jobs
            set esi_id=?, job_debut=?, job_fin=?, job_ron=?, job_etat=?
            where job_id=? and (job_etat!='T' or job_etat is null) };
        $sql = $db->prepare($req);
        $sql->execute($esi, $deb, $fin, $ron, $etat, $id) or abandon(2, $DBI::errstr);
    }
    return 1;
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# date de référence
my $dateref = '';
if (@ARGV > 0) {
    $dateref = $ARGV[0];
} else {
    abandon(6);
}

# fichier en argument
my $flog = '';
if (@ARGV > 1) {
    $flog = $ARGV[1];
}

my ($sec, $min, $hr, $day, $mon, $year) = localtime;
printf("%02d:%02d:%02d", $hr, $min, $sec);
print ' : log '.$flog."\n";

my $errmsg = ' dans reel_OPS.pl';
abandon(3, $errmsg) if ($flog eq '');
abandon(4, $errmsg) if (not -f $flog);

if (not -s $flog) {
    print "Fichier vide\n";
    exit 0;
}

# ouverture du fichier log à traiter
my $log;
abandon(4, $errmsg) if (not open($log, '<', $flog));

my $an = substr($dateref, 0, 4);
my $mois = substr($dateref, 5, 2);
my $jour = substr($dateref, 8, 2);
my $jobs = retrieve('jobs.jour');   # récupération des jobs potentiels
my $db = connexion('begin');        # connexion à la base de données et ouverture de transaction

# identification de l'ESI dont est issu la log
my $machine = debut_log($log);      # premières lignes de la log
my $esi = identifie_esi($db, $machine);
if ($esi == 0) {
    print "Log inexploitable\n";
    close($log);                    # fermeture du fichier log
    deconnexion($db, 'commit');     # fermeture transaction et base
    exit 0;
}

# ordre de consultation des journées (voir jobs_potentiels.pl)
my @ordre = (0, -1, -1, -1, -1, -1, -1, -1, -1, 9, 1, 1, 1, 1, 1, 1, 1);
my @jok = ();   # JOB trouvés
my @jko = ();   # JOB non trouvés

# traitement du fichier
while (my $ligne = <$log>) {
    chomp $ligne;
    # ne sont retenus que les lignes qui contiennent O7.EXPLIB/ sauf les simulations
    if ($ligne =~ /O7\.EXPLIB\// and not $ligne =~ /SIMU.O7\.EXPLIB\//) {
        my @cols = split(/\|/, $ligne);
        my @infos = split(/\s|\//, $cols[9]);
        my $job = $infos[1];
        # Cas particulier : -----------------------------------------------------------
        # la série MDA-MDC se terminant par C ou S, on recherche un JOB OPS de même nom
        # ou avec leur nom en remplaçant le 3ème et 4ème caractère par QY
        # si ces 2 caractères sont différents de QY
        # on aura donc  MDAMQ15S  <--> MDAQYdom15
        #               MDAQY39C       MDAQYdom39
        #               MDAQY3AS       MDAQYdom3A
        #               MDAQY95C       MDAQYdom95
        #               MDCMQ13S       MDCQYdom13
        #               MDCMQ16S       MDCQYdom16
        my $cas = ($job =~ /^MD[AC]MQ/);
        my $alt = '';
        if ($cas) {
            $alt = substr($job, 0, 3).'QY'.substr($job, 5);
        }
        # -----------------------------------------------------------------------------
        if (length $job == 10) {
            my $dref = DateTime->new(year => $an, month => $mois, day => $jour);
            my $ok = 0;
            my $j = 0;
            for my $i (@ordre) {
                my $d = $dref->add(days => $i)->strftime('%y%m%d');
                my $ss = ($j < 2 or $i == 9);   # détermine si on est dans le champ du suivi simplifié
                                                # ±1 jour seulement
                if (exists $jobs->{$d}{$job}) {
                    $ok = realise($db, $jobs->{$d}{$job}, $esi, $ss, $i, $job, @cols);
                    last if $ok;
                } else {
                    # Cas particulier : --------------------------------------------------
                    if ($cas and exists $jobs->{$d}{$alt}) {
                        $ok = realise($db, $jobs->{$d}{$alt}, $esi, $ss, $i, $alt, @cols);
                        last if $ok;
                    }
                    # --------------------------------------------------------------------
                }
                $j++;
            }
            if ($ok) {
                push(@jok, $job);
            } else {
                push(@jko, $job);
            }
        }
    }
}

# journalisation des occurrences non trouvées
my @jobs_neutralises = ('MDRAR96', 'MDUTF01', 'MDUPF01', 'ACFAA16',
    'MDUCG01', 'MDUCG02', 'MDGST01', 'MDGSV01', 'MDGSV02', 'MDGSV06',
    # JOBs du BATCH MEDOC QUOTIDIEN
    'MDGAV50X','MDATI05X','MDGAV60X','MDCHJ55X','MDAMM05X','MDIRJ60X',
    'MDIRJ70X','MDIRJ80X','MDIRJ30X','MDIRJ10X','MDIRJ20X','MDIIJ10X',
    'MDIIJ20X','MDIIJ25X','MDIEJ40X','MDIEJ50X','MDIEJ55X','MDGST05X',
    'MDGRC85X','MDGRC8AX','MDGRC90X','MDGRC05X','MDGRB6TX','MDGRB4TX',
    'MDGRB3TX','MDGRB38X','MDGRB2TX','MDGRB1VX','MDGRB20X','MDGRB28X',
    'MDGRB25X','MDGRB06X','MDGRB04X','MDGRB5GX','MDGRB5FX','MDGRB5EX',
    'MDGRB74X','MDGRB5DX','MDGRB5CX','MDGRB72X','MDGRB81X','MDGRB5BX',
    'MDGRB5AX','MDGRB82X','MDGRB09X','MDGRB70X','MDGRB91X','MDGRB35X',
    'MDGAV05X','MDGAV04X','MDGAV03X','MDGAV02X','MDGAV06X','MDAMM2TX',
    'MDAMM1TX','MDAMM10X','MDAAD99X','MDAAD7TX','MDAAD6TX','MDAAD5TX',
    'MDAAD33X','MDAAD32X','MDAAD31X','MDAAD30X','MDAAD04X','MDCHJ98X',
    'MDCHJ3FX','MDCBC7TX','MDCBC4TX','MDCBC2TX','MDCBC21X','MEDRFRPX',
    'MDUTF01X','MDUPF1TX','MDUPF0TX','SFEIS50X','SFEDT10X','MDIOJ10X',
    'MDIJJ30X','MDCHJ3TX','MDIJJ10X','MDUPF01X','MDAEV10X','MDAAD08X',
    'MDAAD07X','MDAAD06X','MDAAD05X','MDGTRT0X','MDGRJ10X','MDGRB36X',
    'MDGRB31X','MDGRB12X','MDGRB13X','MDGRB11X','MDGAV31X','MDGAV30X',
    'MDIRJ34X','MDIRJ45X','MDATI02X','MDATI01X','MDUCG02X','MDUCG01X',
    'MDCHJ70X','MDCBCE1X','MDCBC75X','MDCBC70X','MDCBC50X','MDCHJ08X',
    'MDCBC25X','MDCHJ06X','MDCHJ09X','MDCBC24X');

my %app = applications($db);

foreach my $job (@jko) {
    my $pat = substr($job, 0, 5).'...'.substr($job, 8, 2);
    my $rex = qr/$pat/;
    if (grep($_ =~ $rex, @jok)) {
        message(1, $job);
    } else {
        # Exclusion des process de service pour alléger la log :
        # présence d'un caractère alphabétique en position 9 ou 10
        if (($job =~ /.{8}\d\d/) and
            (exists($app{substr($job, 0, 3)})) and
            (not neutralise($job, \@jobs_neutralises))) {
            message(3, $job);
        }
    }
}
store \%$jobs, 'jobs.jour';     # persitence dans un fichier pour les autres scripts PERL
close($log);                    # fermeture du fichier log
deconnexion($db, 'commit');     # fermeture transaction et base
exit 0;
# fin
