#!/bin/bash
# reel.sh
#
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Remontée automatique du réalisé par l'analyse des logs GCOS (accounting) et OPS
# CRON exécuté sous le compte dba toutes les 1/2 heures (voir crontab -l sous ce compte)
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

# Répertoire de réception
RR="/var/sppe/"
TRAIT=${RR}"traites/"
VERROU="VERROU_REEL"

# sortie -------------------------------------------------------------------------------------------
# Vérification du code retour précédent et abandon éventuel
function sortie {

    # ARGUMENTS ---------------
    RC=$1       # code retour
    FORCE=0     # arrêt demandé
    if test $# -eq 2
    then
        FORCE=$2
    fi
    # -------------------------

    if test $RC -gt 0 -o $FORCE -ne 0
    then
        # Levée du verrou
        rm $VERROU
        date
        echo "------------------------------------------------------------------------"
        exit $RC
    fi
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# Pour le journal
echo
echo "--------------- DEBUT --------------------------------------------------"
date

# Environnement
if test ! -d $TRAIT
then
    echo "RC=98 Environnement absent ($TRAIT)"
    exit 98
fi

# Verrou pour s'assurer d'un seul traitement à la fois
if test -f $VERROU
then
    echo "RC=99 Un traitement du réalisé est déjà en cours"
    exit 99
else
    touch $VERROU
fi

# ----- Traitement des logs -----

# Liste des logs OPS qui ont plus de deux minutes
LOPS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logOPS*')

# Liste des logs GCOS qui ont plus de trois minutes
# Note : les logs GCOS contiennent les steps ; les jobs sont identifiés par leur n° de RON ;
#        il faut donc que le job soit traité au préalable
#        dans la log OPS pour être reconnu dans la log GCOS.
LGCOS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logGCOS*')

# Détermine le jour de référence à partir d'une log
if test ${#LOPS} -gt 0
then
    set -- $LOPS
    PLOG=$1
    DREF=$(cat $PLOG | cut -d'|' -f3 | cut -d' ' -f1 | uniq -c | sort -n | tail -n1 | cut -c9-)
    DATEREF='20'${DREF:0:2}'-'${DREF:2:2}'-'${DREF:4:2}
else
    if test ${#LGCOS} -gt 0
    then
        set -- $LGCOS
        PLOG=$1
        DREF=$(cat $PLOG | cut -d'"' -f2 | uniq -c | sort -n | tail -n1 | cut -d' ' -f4)
        DATEREF=${DREF:0:4}'-'${DREF:4:2}'-'${DREF:6:2}
    else
        echo "RC=97 Aucune log à traiter"
        sortie 97 1
    fi
fi
echo 'Date de référence : '$DATEREF

# Peuplement de la table des jobs attendus dans la base de données
perl cree_jobs.pl $DATEREF
sortie $?

# Création de la liste des jobs potentiels à rechercher dans les logs
perl jobs_potentiels.pl $DATEREF
sortie $?

# Log OPS pour les jobs
if test ${#LOPS} -gt 0
then
    for FIC in $LOPS
    do
        perl reel_OPS.pl $DATEREF $FIC
        sortie $?
        mv $FIC $TRAIT
    done
fi

# Log GCOS pour les steps
if test ${#LGCOS} -gt 0
then
    for FIC in $LGCOS
    do
        perl reel_GCOS.pl $FIC
        sortie $?
        mv $FIC $TRAIT
    done
fi

# Exhaustivité des traitements
perl exhaustif.pl $DATEREF
sortie $?

# Suppression des fichiers traités qui ont plus de deux journées
find $TRAIT -mmin +7200 -exec rm {} \;

echo "RC 00 : Fin normale"
sortie 0 1
# fin
