#!/usr/bin/perl
# jobs_potentiels.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Dresse la liste des jobs potentiels pour la journée
# et ±8 jours (ou ±1 jour pour le suivi simplifié).
# Le résultat est stocké dans un fichier pour être réutilisé par les scripts PERL suivants.
# Pas d'arguments attendus.
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use DBI;
use utf8;
use Storable;
use DateTime;
use Data::Dumper;

use Reel_fonctions;

no utf8;

# ajoute_jour --------------------------------------------------------------------------------------
# Ajoute les jobs pour une journée donnée
# $db : connexion à la base
# $dref : date de référence au format aammjj
# $dateref : date de référence de la log
# $delta : delta par rapport à ld date de référence
sub ajoute_jour {

    # ARGUMENTS ---------------------------
    my ($db, $dref, $dateref, $delta) = @_;
    # -------------------------------------

    my $req = qq{ insert into jobref
        (jour, job_id, job_lib, job_debut, pro_nom, pro_suivi, pln_debut, pln_fin)
        select ?, j.job_id, j.job_lib, job_debut,
            o.pro_nom, o.pro_suivi, p.pln_debut, p.pln_fin
        from jobs j
            join plan p on p.pln_id=j.pln_id
            join processus o on o.pro_id=p.pro_id
        where j.job_dernier and (?::date + ?::integer) between p.pln_debut and p.pln_fin };
    my $sql = $db->prepare($req);
    $sql->execute($dref, $dateref, $delta) or abandon(2, $DBI::errstr);
}

# cree_table_ref -----------------------------------------------------------------------------------
# Création d'une table temporaire de référence
# $db : connexion à la base
sub cree_table_ref {

    # ARGUMENTS --
    my ($db) = @_;
    # ------------

    my $req = qq{
        create temp table jobref (
            jour        integer,
            job_id      integer,
            job_lib     text,
            job_debut   timestamp,
            pro_nom     text,
            pro_suivi   boolean,
            pln_debut   date,
            pln_fin     date,
            nb          smallint
        ); };
    my $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);
}

# fabrique_ref -------------------------------------------------------------------------------------
# Fabrique le tableau de tables de hashage de référence des jobs potentiels
# $db : connexion à la base
sub fabrique_ref {

    # ARGUMENTS -------------
    my ($db, $jobs_ref) = @_;
    # -----------------------

    my $req = qq{ select jour, job_id, job_lib, pro_nom,
            pro_suivi, pln_debut, pln_fin, nb, job_debut
        from jobref };
    my $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    my $jour;       # 1er niveau d'accès
    my $job_lib;    # 2e niveau d'accès

    my $nb;         #0
    my $job_id;     #1
    my $pro_suivi;  #2
    my $pro_nom;    #3
    my $pln_debut;  #4
    my $pln_fin;    #5
    my $job_debut;  #6

    while (($jour, $job_id, $job_lib, $pro_nom, $pro_suivi,
            $pln_debut, $pln_fin, $nb, $job_debut) = $sql->fetchrow_array) {
        if (not exists($jobs_ref->{$jour}{$job_lib})) {
            $jobs_ref->{$jour}{$job_lib} = ();
        }
        push(@{ $jobs_ref->{$jour}{$job_lib} },
            [($nb, $job_id, $pro_suivi, $pro_nom, $pln_debut, $pln_fin, $job_debut)]);
    }
}

# comptage -----------------------------------------------------------------------------------------
# Compte le nombre de job avec le même libellé pour la même journée
# $db : connexion à la base
sub comptage {

    # ARGUMENTS --
    my ($db) = @_;
    # ------------

    my $req = qq{ create index ix_jobref_jour on jobref (jour) };
    my $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    $req = qq{ create index ix_jobref_job_lib on jobref (job_lib) };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    $req = qq{ create temp table jobref2 (jour, job_lib, nb) as
        select jour, job_lib, count(*) from jobref group by 1,2 };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    $req = qq{ create index ix_jobref2_jour on jobref2 (jour) };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    $req = qq{ create index ix_jobref2_job_lib on jobref2 (job_lib) };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);

    $req = qq{ update jobref j
        set nb=(select x.nb from jobref2 x where x.job_lib=j.job_lib and x.jour=j.jour) };
    $sql = $db->prepare($req);
    $sql->execute() or abandon(2, $DBI::errstr);
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# date de référence
my $dateref = '';
if (@ARGV > 0) {
    $dateref = $ARGV[0];
} else {
    abandon(6);
}

my $db = connexion();           # connexion à la base de données

cree_table_ref($db);            # création d'une table temporaires pour stocker les jobs

my %jobs = ();                  # jobs attendu par jour

# on prend les processus du jour
# puis tous ceux jusqu'à huit jours avant (specs) *
# puis tous ceux jusqu'à huit jours après (+1 au cas où la log change de jour en son sein)
my @ordre = (0, -1, -1, -1, -1, -1, -1, -1, -1, 9, 1, 1, 1, 1, 1, 1, 1, 1);
my $an = substr($dateref, 0, 4);
my $mois = substr($dateref, 5, 2);
my $jour = substr($dateref, 8, 2);
my $datt = DateTime->new(year => $an, month => $mois, day => $jour);   # jour de référence
my $delta = 0;  # delta en jour par rapport au jour de référence
for my $i (@ordre) {
    $delta += $i;
    my $dref = $datt->add(days => $i)->strftime('%y%m%d');
    ajoute_jour($db, $dref, $dateref, $delta);
    $jobs{$dref} = ();
}

comptage($db);                  # comptage des jobs 

fabrique_ref($db, \%jobs);      # on place le tout dans un tableau de tables de hashage

store \%jobs, 'jobs.jour';      # persitence dans un fichier pour les autres scripts PERL
#print Dumper(%jobs);

$db->disconnect();
exit 0;

# FIN ----------------------------------------------------------------------------------------------
