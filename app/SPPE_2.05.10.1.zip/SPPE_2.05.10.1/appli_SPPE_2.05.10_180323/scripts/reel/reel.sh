#!/bin/bash
# reel.sh
#
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Remontée automatique du réalisé par l'analyse des logs GCOS (accounting) et OPS
# CRON exécuté sous le compte dba toutes les 1/2 heures (voir crontab -l sous ce compte)
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

# Répertoire de réception

RR="/var/sppe/"
DECOUP=${RR}"decoupage/"
IGNORE=${RR}"ignore/"
TRAIT=${RR}"traites/"
DLOGS=${RR}"logs/"
ELOGS=${RR}"logs/esi/"
VERROU="VERROU_REEL"

# sortie -------------------------------------------------------------------------------------------
# Vérification du code retour précédent et abandon éventuel
function sortie {

    # ARGUMENTS ---------------
    RC=$1       # code retour
    FORCE=0     # arrêt demandé
    if test $# -eq 2
    then
        FORCE=$2
    fi
    # -------------------------

    if test $RC -gt 0 -o $FORCE -ne 0
    then
        # Levée du verrou
        rm $VERROU
        date
        echo "------------------------------------------------------------------------"
        exit $RC
    fi
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# Pour le journal
echo
echo "--------------- DEBUT --------------------------------------------------"
date

# Environnement
if test ! -d $TRAIT || test ! -d $IGNORE || test ! -d $DECOUP || test ! -d $DLOGS || test ! -d $ELOGS
then
    echo "RC=98 Environnement absent ou incomplet"
    exit 98
fi

# Verrou pour s'assurer d'un seul traitement à la fois
if test -f $VERROU
then
    echo "RC=99 Un traitement du réalisé est déjà en cours"
    exit 99
else
    touch $VERROU
fi

# Log par ESI et par jour
declare JOUR=$(date +'%Y-%m-%d')
declare FIC=$(ls ${DLOGS}passage* -prt | tail -n3 | head -n1)

perl log_par_esi.pl $FIC cl1x o63e >> ${ELOGS}"/SPPE_CLE1_"${JOUR}".log"
perl log_par_esi.pl $FIC mar2 o13e >> ${ELOGS}"/SPPE_MAR2_"${JOUR}".log"
perl log_par_esi.pl $FIC nan2 o44e >> ${ELOGS}"/SPPE_NAN2_"${JOUR}".log"
perl log_par_esi.pl $FIC rei2 o51e >> ${ELOGS}"/SPPE_REI2_"${JOUR}".log"

# ----- Traitement des logs -----

# Liste des logs OPS qui ont plus de deux minutes
LOPS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logOPS*')

# Découpage OPS
if test ${#LOPS} -gt 0
then
    for FIC in $LOPS
    do
        perl decoupe_OPS.pl $FIC
        if test $? -eq 0
        then
            mv $FIC $TRAIT
        else
            mv $FIC $IGNORE
        fi
    done
fi

# Liste des logs GCOS qui ont plus de trois minutes
# Note : les logs GCOS contiennent les steps ; les jobs sont identifiés par leur n° de RON ;
#        il faut donc que le job soit traité au préalable
#        dans la log OPS pour être reconnu dans la log GCOS.
LGCOS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logGCOS*')

# Découpage GCOS
if test ${#LGCOS} -gt 0
then
    for FIC in $LGCOS
    do
        perl decoupe_GCOS.pl $FIC
        if test $? -eq 0
        then
            mv $FIC $TRAIT
        else
            mv $FIC $IGNORE
        fi
    done
fi

# Détermine le jour de référence à partir d'une log
LOGS=$(find ${DECOUP} -maxdepth 1 -iname '*log*'|sort|cut -d'/' -f5|head -n1|cut -c-8)

if test ${#LOGS} -gt 0
then
    DREF=${LOGS:0:8}
else
    echo "RC=97 Aucune log à traiter"
    sortie 97 1
fi

# Sélection des logs pour la même date de référence
LOPS=$(find ${DECOUP} -maxdepth 1 -iname "${DREF}*logOPS*"|sort)
LGCOS=$(find ${DECOUP} -maxdepth 1 -iname "${DREF}*logGCOS*"|sort)
DATEREF=${DREF:0:4}'-'${DREF:4:2}'-'${DREF:6:2}
echo 'Date de référence : '$DATEREF

# Peuplement de la table des jobs attendus dans la base de données
perl cree_jobs.pl $DATEREF
sortie $?

# Création de la liste des jobs potentiels à rechercher dans les logs
perl jobs_potentiels.pl $DATEREF
sortie $?

# Log OPS pour les jobs
if test ${#LOPS} -gt 0
then
    for FIC in $LOPS
    do
        perl reel_OPS.pl $DATEREF $FIC
        sortie $?
        rm $FIC
    done
fi

# Log GCOS pour les steps
if test ${#LGCOS} -gt 0
then
    for FIC in $LGCOS
    do
        dos2unix $FIC
        perl reel_GCOS.pl $FIC
        sortie $?
        rm $FIC
    done
fi

# Exhaustivité des traitements
perl exhaustif.pl $DATEREF
sortie $?


# Suppression des fichiers traités et des logs qui ont plus de dix jours
find $TRAIT -mtime +10 -exec rm {} \;
find $DLOGS -mtime +10 -exec rm {} \;
find $ELOGS -mtime +10 -exec rm {} \;

echo "RC 00 : Fin normale"
sortie 0 1
# fin
