#!/bin/bash

DOSSIER_SOURCE='/home/dba/recette/logs'
DOSSIER_COPIE_SAUVEGARDE="${DOSSIER_SOURCE}/save/"
DOSSIER_SPPE='/var/sppe/'

#
# récupère la date et l'heure de traitement les plus anciens
#
ls "$DOSSIER_SOURCE" > tmp_file
i=0
while read line
do
	DATE_LOG=${line:12:8}
	if [ "$i" -eq 0 ]
	then
		DATE_TRAITEMENT="$DATE_LOG"
	fi
	
	(( i+=1 ))
done < tmp_file

#
# deplace les fichiers dans le repertoire de sppe apres une copie de sauvegarde
#
cd "$DOSSIER_SOURCE"
cp *$DATE_TRAITEMENT* $DOSSIER_COPIE_SAUVEGARDE
mv *$DATE_TRAITEMENT* $DOSSIER_SPPE

#
# suppression du fichier temporaire
#
rm -f tmp_file

#
# Lancement du traitement d'integration des logs
#
export SPPE_DB=spedgsd001-d
cd /var/www/html/sppe/scripts/reel/
bash reel_SPPE.sh > /var/sppe/logs/passage_`date "+\%s"`.log 2>&1