#!/bin/bash
# reel_SPPE.sh
#
# Automate de récupération et de traitement du réalisé
# par cron toutes les 15 minutes
#
# Tant que des fichiers existent dans /var/sppe ou /var/sppe/decoupage
# JMD - 29/06/2016 ---------------------------------------------------------------------------------

function presence_logs {

    # Liste des logs qui ont plus de deux minutes
    LOPS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logOPS*')
    LGCOS=$(find ${RR} -maxdepth 1 -mmin +2 -iname '*logGCOS*')
    LOGS=$(find ${DECOUP} -maxdepth 1 -iname '*log*')
    RC=$(( ${#LGCOS} + ${#LOPS} + ${#LOGS} ))
}

# Répertoire de réception
RR="/var/sppe/"
DECOUP=${RR}"decoupage/"
ARCHIVES=${RR}"archives/"

# Verrou pour s'assurer d'un seul traitement à la fois
VERROU="VERROU_REEL"
if test -f $VERROU
then
    exit
fi

# Récupération des logs sur sppe@10.153.113.73:/adonis/test en RECETTE seulement
# if test $( grep -c RECETTE /var/www/html/sppe/type_serveur.php ) -gt 0
# then
#    ssh sppe@10.153.113.73 "cd /adonis/test && if test ! -d travail ; then mkdir travail ; fi && cd travail && find .. -maxdepth 1 -mmin +2 -iname '*log*S*' -exec mv {} . \; "
#    scp sppe@10.153.113.73:/adonis/test/travail/* $RR
#    if test $? -eq 0
#    then
#        tar cz ${RR}*log* > ${ARCHIVES}log$(date +'%s').tar.gz
#        if test $? -eq 0
#        then
#            ssh sppe@10.153.113.73 "cd /adonis/test/travail && rm *log* && cd .. && rmdir travail"
#        fi
#    fi
#fi

presence_logs
while test $RC -gt 0
do
    bash reel.sh
    presence_logs
done

# fin
