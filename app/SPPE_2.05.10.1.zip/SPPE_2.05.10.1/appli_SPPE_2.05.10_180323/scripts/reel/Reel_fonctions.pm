#!/usr/bin/perl
# reel_fonctions.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Fonctions partagées
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

package Reel_fonctions;
use strict;
use warnings;
use Exporter;
use DBI;
use utf8;

no utf8;

our @ISA= qw( Exporter );

# these CAN be exported.
our @EXPORT_OK = qw( &abandon &connexion &deconnexion &identifie_esi &trim );

# these are exported by default.
our @EXPORT = qw( &abandon &connexion &deconnexion &identifie_esi &trim );

# abandon ------------------------------------------------------------------------------------------
# Sorties en échec du programme
# $rc : code retour
# $comp : message complémentaire
sub abandon {

    # ARGUMENTS -----------
    my ( $rc, $comp ) = @_;
    # ---------------------

    $comp = '' if not defined $comp;

    my %msg = (
        1 => "Variable d'environnement SPPE_DB absente",
        2 => "Erreur base de données = ",
        3 => "Paramètre absent",
        4 => "Erreur à l'ouverture du fichier",
        5 => "ESI non identifié (log OPS) :",
        6 => "Date de référence absente"
    );

    print "ERR ".$rc." : ".$msg{$rc}.$comp."\n";

    exit $rc;
}

# connexion ----------------------------------------------------------------------------------------
# Connexion à la base de données
# --> retourne l'identifiant de connexion
sub connexion {

    # ARGUMENTS -----
    my ( $req ) = @_;
    # ---------------

    # Lecture de l'environnement : serveur hébergeant la base de données
    my $dbhost = $ENV{'SPPE_DB'} or abandon(1);
    # Connexion à la base de données
    my $driver = 'Pg'; 
    my $database = 'sppe';
    my $dsn = "DBI:$driver:dbname=$database;host=".$dbhost.";port=5432";
    my $userid = 'dba';
    my $password = 'mypg';
    my $db = DBI->connect($dsn, $userid, $password, { RaiseError => 1 })
        or abandon(2, $DBI::errstr);

    if ($req) {
        my $sql = $db->prepare($req);
        $sql->execute() or abandon(2, $DBI::errstr);
    }

    return $db;
}

# deconnexion --------------------------------------------------------------------------------------
# Déconnexion de la base de données
# $db : identifiant de connexion
# $req : requête facultative avant déconnexion
sub deconnexion {

    # ARGUMENTS ----------
    my ( $db, $req ) = @_;
    # --------------------

    if ($req) {
        my $sql = $db->prepare($req);
        $sql->execute() or abandon(2, $DBI::errstr);
    }
    $db->disconnect(); 
}

# identifie_esi ------------------------------------------------------------------------------------
# Identifie l'ESI à partir d'une ligne de la log
# $db : base de données
# $esi : codification de l'ESI dans la 2e colonne de la log GCOS
# --> retourne l'identifiant de l'ESI ou 0
sub identifie_esi {

    # ARGUMENTS --------
    my ($db, $esi) = @_;
    # ------------------

    my $rc = 0;

    my $req = qq{ select esi_id from esi where esi_machine ilike ? or esi_ops ilike ? or esi_gcos ilike ? };
    my $sql = $db->prepare($req);
    $sql->execute($esi, $esi, $esi) or abandon(2, $DBI::errstr);
    if (my $id = $sql->fetchrow_array) {
        $rc = $id;
    }

    return $rc;
}

# trim ---------------------------------------------------------------------------------------------
# Supprime les espaces au début et à la fin de la chaîne
# $ch : chaîne
# --> retourne la chaîne nettoyée
sub trim {

    # ARGUMENTS ----
    my ( $rc ) = @_;
    # --------------

    $rc =~ s/^\s+//;
    $rc =~ s/\s+$//;

    return $rc;
}

1;
