#!/usr/bin/perl
# exhaustif.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Détermine l'exhaustivité d'un traitement pour un processus
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 1er mars 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use DBI;
use utf8;
use Storable;
use DateTime;
use Data::Dumper;

use Reel_fonctions;

no utf8;

# exhaustivite -------------------------------------------------------------------------------------
# Exhaustivité des traitements pour un ESI donné à ± 9 jours de la date de référence en paramètre
# $db : connexion à la base
# $esi : identifiant de l'ESI
# $dateref : date de référence
sub exhaustivite {

    # ARGUMENTS ------------------
    my ($db, $esi, $dateref) = @_;
    # ----------------------------

    # Sélection des mises au plan sur la période non marquées terminées
    
    my $req = qq{ 
    	SELECT p.pln_id, r.rea_id
		FROM plan p
    	JOIN processus z ON z.pro_id=p.pro_id AND z.pro_realise
    	LEFT OUTER JOIN realise r ON r.pln_id=p.pln_id AND r.esi_id=?
    	LEFT OUTER JOIN utilisateurs u ON u.uti_id=r.rea_id
		WHERE NOT(
			r.rea_debut IS NOT NULL
			AND r.rea_fin IS NOT NULL
			AND r.rea_statut='T'
		)
		AND
    	(
    		(
    			p.pln_debut<=(?::date+'9 day'::interval)
    			AND
    			p.pln_fin>=(?::date-'9 day'::interval)
    		)
    		OR
    		(
    			p.pln_debut>=(?::date-'9 day'::interval)
    			AND
    			p.pln_debut<=(?::date+'9 day'::interval)
    		)
    	)
    	AND
    	(
    		uti_uid_fonctionnel='automate'
    		OR
    		uti_uid_fonctionnel is null
    	)
    };
    my $sql = $db->prepare($req);
    $sql->execute($esi, $dateref, $dateref, $dateref, $dateref) or abandon(2, $DBI::errstr);
    while (my @lu = $sql->fetchrow_array) {
        # détermination du statut actuel
        my %statut = ('0' => 0, 'A' => 0, 'X' => 0, 'T' => 0);
        my $req2 = qq{ SELECT DISTINCT COALESCE(job_etat, '0')
            			FROM jobs
            			WHERE pln_id=?
            			AND esi_id=?
            			AND job_dernier };
        my $sql2 = $db->prepare($req2);
        $sql2->execute($lu[0], $esi) or abandon(2, $DBI::errstr);
        while (my @lu2 = $sql2->fetchrow_array) {
            $statut{$lu2[0]} = 1;
        }
        my $etat = undef; # en cours
        if ($statut{'A'}) {
            $etat = 'A';    # en abort
        } else {
            if ($statut{'T'} and not $statut{'X'} and not $statut{'0'}) {
                $etat = 'T';    # terminé
            } else {
                if ($statut{'0'} and not $statut{'X'} and not $statut{'T'}) {
                    $etat = '0';    # en attente
                }
            }
        }
        # information du réalisé
        if ($etat ne '0') {
            if ($lu[1]) {
                # du réalisé existe déjà
                
                $req2 = qq{ 
                	UPDATE realise SET
            		rea_debut=(SEELCT MIN(job_debut) FROM jobs WHERE pln_id=? AND esi_id=?),
                	rea_fin=(CASE WHEN ?::char='T'
                    			THEN (SELECT MAX(job_fin) FROM jobs WHERE pln_id=? AND esi_id=?)
                    			ELSE NULL
                    		END),
                	rea_statut=?,
                	rea_timbre=now()
            		WHERE rea_id=?
                };
                $sql2 = $db->prepare($req2);
                $sql2->execute($lu[0], $esi, $etat, $lu[0], $esi, $etat, $lu[1]) or abandon(2, $DBI::errstr);
            } else {
                # le réalisé n'existe pas encore
                
                $req2 = qq{ 
                	INSERT INTO realise SET
                    	pln_id=?,
                    	esi_id=?,
                    	uti_id=(SELECT uti_id FROM utilisateurs WHERE uti_uid_fonctionnel='automate'),
                    	rea_debut=(SELECT MIN(job_debut) FROM jobs WHERE pln_id=? AND esi_id=?),
                    	rea_fin=(CASE WHEN ?::char='T'
                            		THEN (SELECT MAX(job_fin) FROM jobs WHERE pln_id=? AND esi_id=?)
                            		ELSE NULL END),
                    	rea_statut=?)
                };
                $sql2 = $db->prepare($req2);
                $sql2->execute($lu[0], $esi, $lu[0], $esi, $etat, $lu[0], $esi, $etat) or abandon(2, $DBI::errstr);
            }
            # prise en compte de l'heure de fin
            $req2 = qq{ 
            	UPDATE realise SET
            	rea_heure=EXTRACT(HOUR FROM (
                    		SELECT MAX(job_fin) FROM jobs WHERE pln_id=? AND esi_id=?))
                WHERE pln_id=? AND esi_id=?
            };
            $sql2 = $db->prepare($req2);
            $sql2->execute($lu[0], $esi, $lu[0], $esi) or abandon(2, $DBI::errstr);
        }
    }
}

# PRINCIPAL ----------------------------------------------------------------------------------------

# date de référence
my $dateref = '';
if (@ARGV > 0) {
    $dateref = $ARGV[0];
} else {
    abandon(6);
}

my $db = connexion();    # connexion à la base de données

# Sélection des ESI
my $req = qq{ SELECT esi_id FROM esi };
my $sql = $db->prepare($req);
$sql->execute() or abandon(2, $DBI::errstr);

# Traitement pour chaque ESI
while (my @lu = $sql->fetchrow_array) {
    exhaustivite($db, $lu[0], $dateref);
}

deconnexion($db);     # fermeture base
exit 0;
# fin
