#!/usr/bin/perl
# decoupe_GCOS.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Réalisé automatique : découpe une log GCOS en fonction des différentes dates qu'elle contient
# Programme appelé par realise.sh
# En argument, le fichier log à traiter
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 20 juin 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
#use DBI;
use utf8;
#use Storable;
#use DateTime;
#use Data::Dumper;
use File::Basename;

use Reel_fonctions;

no utf8;

# PRINCIPAL ----------------------------------------------------------------------------------------

# date de référence
my $flog = '';
if (@ARGV > 0) {
    $flog = $ARGV[0];
} else {
    abandon(4);
}

# ouverture du fichier log à traiter
my $log;
my $errmsg = ' dans decoupe_GCOS.pl';
abandon(4, $errmsg) if (not open($log, '<', $flog));

my $fd;
my $fnom = '';
my $cour = '';
my $prec = '';

# traitement du fichier
while (my $ligne = <$log>) {
    chomp $ligne;
    if ($ligne =~ /^"?\d{8}/) {
        if ($ligne =~ /^"/) {
            $cour = substr($ligne, 1, 8);
        } else {
            $cour = substr($ligne, 0, 8);
        }
        if ($cour != $prec) {
            $prec = $cour;
            # fermeture fichier précédent
            if ($fnom) {
                close($fd);
            }
            # ouverture du fichier
            $fnom = dirname($flog).'/decoupage/'.$cour.'_'.basename($flog);
            print $fnom."\n";
            if (!open($fd,'>>',$fnom)) {
                abandon(4, $errmsg);
            }
        }
        print ($fd $ligne."\n");
    }
}
# fermeture fichier précédent
if ($fnom) {
    close($fd);
}
close($log);
exit 0;
# fin
