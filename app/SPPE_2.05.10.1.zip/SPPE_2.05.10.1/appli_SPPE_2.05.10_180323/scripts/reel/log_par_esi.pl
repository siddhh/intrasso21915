#!/usr/bin/perl
# log_par_esi.pl
# 
# Application SPPE : Suivi du Plan de Production des Exploitations
# --------------------------------------------------------------------------------------------------
# Dispatching des logs par ESI
# --------------------------------------------------------------------------------------------------
# JMD - v1.0 - 11 août 2016
# - version initiale
# --------------------------------------------------------------------------------------------------

use strict;
use utf8;
use Data::Dumper;

no utf8;

# PRINCIPAL ----------------------------------------------------------------------------------------

my $fic = $ARGV[0];
my $esi1 = $ARGV[1];
my $esi2 = $ARGV[2];

# ouverture du fichier log à traiter
my $log;
open($log, '<', $fic);

# lecture et traitement de la log
my $ok = 0;
my $lv = 0;
while (my $ligne = <$log>) {
    chomp $ligne;
    if ($ok and $ligne =~ /^\s.*/) {
        $ligne =~ s/^\s+//;
        $ligne =~ s/\s+$//;
        if ($ligne) {
            print $ligne."\n";
            $lv = 0;
        } else {
            if ($lv == 0) {
                print "\n";
            }
            $lv = 1;
        }
    } else {
        if ($ligne =~ /.*logGCOS.*/ or $ligne =~ /.*logOPS.*/) {
            $ok = ($ligne =~ /.*\Q$esi1\E.*/ or $ligne =~ /.*\Q$esi2\E.*/);
        }
    }
}

close($log);    # fermeture du fichier log
exit 0;
# fin
