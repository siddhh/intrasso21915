#!/bin/sh
# sauvegarde.sh
#
# Sauvegarde de la base de données SPPE et nettoyage.
# À lancer avec le compte postgres.
# 0 13,21 * * 1-5 bash /usr/local/bin/sauvegarde.sh > /var/sauvegardes/log/postgres 2>&1 
# ----------------------------------------------------
# v1.00 du 27/08/2014    Dev	Initial
# v1.01 du 14/01/2016	 Dev	Fréquence vacuum
# ----------------------------------------------------

# mise en place de l'environnement SPPE
source /u01/pgsql/pgbase/9.1/pgbase SPPE

SVGDIR="/var/sauvegardes/sppe"
NUMARC=$(date +'%d'|cut -c1)

cd $SVGDIR

# Conservation de l'ancienne sauvegarde
cp sppe_dump.sql.bz2 sppe_dump${NUMARC}.sql.bz2
rm sppe_dump.sql.bz2

# Nettoyage de la base tous les soirs de la semaine
declare -i HEURE=$(date +'%H')
if [ $HEURE -gt 18 ] ; then
    # Nettoyage
    psql $BASE -c 'vacuum analyze'
fi

# Sauvegarde
pg_dump sppe > "sppe_dump.sql"

# Compression
bzip2 sppe_dump.sql
md5sum sppe_dump.sql.bz2 > sppe_dump.sql.bz2.md5

# Purge des archives log ayant plus de 10 jours
find /u02/pgsql/admin/9.1/SPPE/xlog_archives -mtime +10 -exec rm {} \;

exit 0

