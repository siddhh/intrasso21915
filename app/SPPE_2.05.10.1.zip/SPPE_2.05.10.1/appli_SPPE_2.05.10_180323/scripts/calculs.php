<?php

    /* Calcul des mises au plan pour les derniers processus reçus */

    /* jma -----------------------------------------------------------------------------------------
     * Transforme une date PostgreSQL (ISO) au format JJ/MM/AAAA pour affichage "human friendly"
     * $pgdate : date à transformer
     * --> retourne la date au format JJ/MM/AAAA */

    function jma($pgdate) {

        $rc = '-';

        if ($pgdate == null) {
            $rc = '-';
        } else {
            if (strlen($pgdate) > 9) {
                $rc = substr($pgdate, 8, 2).'/'.substr($pgdate, 5, 2).'/'.substr($pgdate, 0, 4);
            }
        }

        return $rc;
    }

    require '../inc/calcul.php';

    /* Connexion à la base de données SPPE */
    define("HOST_BASE","localhost");
    
    require '../inc/pg_connect.php';
    if ($db === false) exit;

    if (pose_verrou()) {

        $req = "UPDATE statut SET valeur='on' WHERE objet='verrou'";
        pg_query($db, $req);

        /* Lecture des processus à calculer */

        $req = 'SELECT p.* FROM recalcul r JOIN processus p ON p.pro_id=r.pro_id';
        $res = pg_query($db, $req);

        while ($lu = pg_fetch_assoc($res)) {
            $rapport = calcul($lu);
            echo $rapport;
        }

        retire_verrou();

    } else {

        echo " *** La base SPPE est verrouillée. *** \n";

    }
?>
