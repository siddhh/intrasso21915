#!/bin/sh
# Automate lancé par cron pour la réception des processus LEONARD
# crontab :
# 1,16,31,46 8-18 * * 1-5 /bin/bash /var/www/html/sppe/scripts/automate.sh
# v1.00 - 01/08/2014 -------------------------------------------------------------------------------

SERVEUR="localhost"

if test "$HOSTNAME" == "spedgsa001" ; then
    SERVEUR="192.175.171.11"
fi

LOG1="/var/www/html/sppe/service/leonard.pl.log"
LOG2="/var/www/html/sppe/service/calculs.php.log"

HISTO1="/var/www/html/sppe/service/leonard.pl.histo"
HISTO2="/var/www/html/sppe/service/calculs.php.histo"

cat $LOG1 >> $HISTO1
cat $LOG2 >> $HISTO2

cd /var/www/html/sppe/scripts

perl -w leonard.pl $SERVEUR /var/www/html/sppe/leonard > $LOG1 2>&1

php calculs.php > $LOG2 2>&1

# FIN
