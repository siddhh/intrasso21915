<?php

session_start();

require __DIR__ .'/inc/commun.php';

$recherche_seulement = true;
$cmdb = 'cmd_rch';
$action = 'action="recherche.php"';

if (isset($_SESSION) && array_key_exists('uti_droits', $_SESSION) && estHabil(HABIL_GESTION_DATE)) {

    $recherche_seulement = false;
    $cmdb = 'cmd_ges';
    $action = 'action="dates.php"';
}

$page = 'gesdates';

require 'inc/page.php';

?>
