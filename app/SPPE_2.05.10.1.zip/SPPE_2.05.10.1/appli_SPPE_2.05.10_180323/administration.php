<?php

session_start();

$page = 'accueil';
$cmdb = '';

if (isset($_SESSION) && array_key_exists('uti_id', $_SESSION) && intval($_SESSION['uti_id']) > 0){
    $page = 'admin';
}

require 'inc/page.php';

?>
