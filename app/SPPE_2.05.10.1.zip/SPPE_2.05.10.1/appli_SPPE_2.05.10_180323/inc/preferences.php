<?php

    /* Préférences des utilisateurs */

    require 'DEF_COULEURS.php';
    
    /* Valeurs par défaut ----------------------------------------------------------------------- */

    /* Répétition des titres toutes les n lignes */
    $_SESSION['prf_repete_titre'] = 25;

    /* Couleurs par défaut */
    $_SESSION['prf_coul_calcule']    = SPPE_DEF_CALCULE;
    $_SESSION['prf_coul_manuel']     = SPPE_DEF_MANUEL;
    $_SESSION['prf_coul_termine']    = SPPE_DEF_TERMINE;
    $_SESSION['prf_coul_en_cours']   = SPPE_DEF_EN_COURS;
    $_SESSION['prf_coul_en_abort']   = SPPE_DEF_EN_ABORT;
    $_SESSION['prf_coul_hors_delai_apres'] = SPPE_DEF_HORS_DELAI_APRES;
    $_SESSION['prf_coul_hors_delai_avant'] = SPPE_DEF_HORS_DELAI_AVANT;
    $_SESSION['prf_coul_ferie']      = SPPE_DEF_FERIE;

    /* ------------------------------------------------------------------------------------------ */

    if ($_SESSION['uti_id'] != 0) {
    
        /* Sauvegarde du niveau actuel du rapport d'erreurs et inhibition */
        $erreur_reporting = error_reporting();
        error_reporting(0);
        
        $req = 'select prf_objet, prf_valeur from preferences where uti_id=$1';
        $res = pg_query_params($db, $req, array($_SESSION['uti_id']));

        if ($res === false) {

            /* Création de la table des préférences si elle n'existe pas */

            pg_query($db, 'begin');
            pg_query($db, 'create table preferences (
                    uti_id      integer     not null    references utilisateurs,
                    prf_objet   text        not null,
                    prf_valeur  text
                )');
            pg_query($db, 'create index ix_preferences_uti_id on preferences (uti_id)');
            pg_query($db, 'commit');

        } else {

            /* Lecture des préférences */

            while ($lu = pg_fetch_row($res)) {
                $_SESSION[$lu[0]] = $lu[1];
            }
        }

        /* Rétablissement de la gestion des erreurs à son état originel */
        error_reporting($erreur_reporting);
    }
?>
