<?php

	/* Calcul du plan d'un processus */

	require_once 'ferie.php';

	/* Pose verrou ---------------------------------------------------------------------------------
	 * Vérifie l'état du verrou et le pose s'il ne l'est pas déjà
	 * --> retourne vrai si le verrou est posé, faux sinon
	 * */

	function pose_verrou() {

		global $db;

		$req = 'begin';
		pg_query($db, $req);

		$req = "SELECT valeur FROM statut WHERE objet='verrou'";
		$res = pg_query($db, $req);
		$lu = pg_fetch_row($res);
		$rc = ($lu[0] == 'off');

		if ($rc) {
			$req = "UPDATE statut SET valeur='on' WHERE objet='verrou'";
			$res = pg_query($db, $req);
			$rc = ($res !== false);
		}

		$req = 'commit';
		pg_query($db, $req);

		return $rc;
	}

	/* Retire verrou -------------------------------------------------------------------------------
	 * Retire un verrou inconditionnellement
	 * */

	function retire_verrou() {

		global $db;

		$req = "UPDATE statut SET valeur='off' WHERE objet='verrou'";
		pg_query($db, $req);
	}

	/* Décalages jour ouvré ------------------------------------------------------------------------
	 *	$d : date examinée (objet DateTime)
	 *	$dec : décalage +1 ou -1
	 *	$un : date intervalle d'un jour
	 *		--> retourne le jour ouvré au format ISO
	 * */

	function decale($d, $dec, $un_jour) {

		$cd = clone $d;

		while (ferie($cd)) {
			if ($dec > 0) {
				$cd->add($un_jour);
			} else {
				$cd->sub($un_jour);
			}
		}

		return $cd->format('Y-m-d');
	}

	/* Date fixée par la règle ---------------------------------------------------------------------
	 *	$dates : tableau destinataire des dates (en référence)
	 *	$regle : règle LEONARD
	 *	$debut : début de validité, date au format ISO
	 *	$fin : fin de validité, idem
	 *	$an : année en cours
	 *		--> le retour des dates se fait dans $dates
	 * */

	function dateFixe(&$dates, $regle, $debut, $fin, $an) {

		/* Découpage de la règle */

		$un_jour = new DateInterval('P1D');
		$une_sem = new DateInterval('P7D');
		$un_mois = new DateInterval('P1M');
		$jours = array('DI','LU','MA','ME','JE','VE','SA');

		$reg = explode('|', $regle);

		switch ($reg[0]) {

			case 'J' :
				array_push($dates, null);   /* date à null => à saisir dans l'interface */
				break;

			case 'M' : /* Traitement au mois */

				$liste_mois = $reg[1];      /* Liste des mois au format MM[MM]... */
				$position = $reg[2];        /* Position 1 à 31, PR (premier) ou DE (dernier) */
				$jour = $reg[3];            /* LU, MA, ME, JE, VE, SA, DI ou JO pour le nième */
				$ouvre = ($reg[4] == 'O');  /* nième ouvré si O */
				$decalage = $reg[5];        /* Décalage si non ouvré -1, 0 ou +1 */

				$jsem = array_search($jour, $jours);
				$deci = intval($decalage, 10);
				$d = new DateTime();

				/* Pour chaque mois */

				$nm = 0;
				$lm = strlen($liste_mois);

				while ($nm < $lm) {

					$candidat = null;   /* Date candidate */

					$mois = substr($liste_mois, $nm, 2);
					$nm += 2;

					/* Position initiale au début du mois */

					$d->setDate($an, intval($mois, 10), 1);

					if ($jsem === false) {

						/* JO : un jour donné dans le mois*/
						switch ($position) {

							case 'PR' : /* Premier */
								if ($ouvre && ferie($d)) {
									$dec = ($deci == 0) ? 1 : $deci;
									$candidat = decale($d, $dec, $un_jour);
								} else {
									$candidat = $d->format('Y-m-d');
								}
								break;

							case 'DE' : /* Dernier */
								$d->add($un_mois);
								$d->sub($un_jour);
								if ($ouvre && ferie($d)) {
									$dec = ($deci == 0) ? -1 : $deci;
									$candidat = decale($d, $dec, $un_jour);
								} else {
									$candidat = $d->format('Y-m-d');
								}
								break;

							default :
								$j = intval($position, 10);
								if ($ouvre) {
									do {
										if (ferie($d) == false){
											$j--;
										}
										if ($j){
											$d->add($un_jour);
										}
									} while ($j > 0);
									/* on vérifie qu'on est pas sorti du mois en cours */
									if (intval($mois, 10) == intval($d->format('m'))) {
										$candidat = $d->format('Y-m-d');
									}
								} else {
									$d->setDate($an, intval($mois, 10), $j);
									if ($deci) {
										$candidat = decale($d, $deci, $un_jour);
									} else {
										$candidat = $d->format('Y-m-d');
									}
								}
								break;
						}
					} else {

						/* LU --> DI */
						if ($position == 'DE') {
							/* Dernier du mois */
							$d->add($un_mois);
							$d->sub($un_jour);
							if ($ouvre) {
								while (($d->format('w') != $jsem) or (ferie($d))) {
									$d->sub($un_jour);
								}
								$candidat = $d->format('Y-m-d');
							} else {
								while ($d->format('w') != $jsem) {
									$d->sub($un_jour);
								}
								if ($deci) {
									$candidat = decale($d, $deci, $un_jour);
								} else {
									$candidat = $d->format('Y-m-d');
								}
							}
						} else {
							/* nième du mois */
							if ($position == 'PR') {
								$p = 1;
							} else {
								$p = intval($position, 10);
							}
							if ($ouvre) {
								while ($p) {
									if (($d->format('w') == $jsem) and (ferie($d) == false)) {
										$p--;
									}
									if ($p) $d->add($un_jour);
								}
								/* on vérifie qu'on est pas sorti du mois en cours */
								if (intval($mois, 10) == intval($d->format('m'))) {
									$candidat = $d->format('Y-m-d');
								}
							} else {
								while ($p) {
									if ($d->format('w') == $jsem) {
										$p--;
									}
									if ($p) $d->add($un_jour);
								}
								/* on vérifie qu'on est pas sorti du mois en cours */
								if (intval($mois, 10) == intval($d->format('m'))) {
									if ($deci) {
										$candidat = decale($d, $deci, $un_jour);
									} else {
										$candidat = $d->format('Y-m-d');
									}
								}
							}
						}
					}

					if (($candidat != null) and ($candidat >= $debut) and ($candidat <= $fin)) {
						array_push($dates, $candidat);
					}
				}

				break;

			case 'S' : /* Traitement à la semaine */

				$jour = $reg[1];        /* LU, MA, ME, JE, VE, SA, DI */
				$decalage = $reg[2];    /* Décalage si non ouvré -1, 0 ou +1 */

				$jsem = array_search($jour, $jours);
				$deci = intval($decalage, 10);

				/* Positionnement sur la première date */

				$d = new DateTime($debut);
				while ($d->format('w') != $jsem) {
					$d->add($un_jour);
				}

				/* Traitement de toutes les dates */

				while ($d->format('Y-m-d') <= $fin) {
					if ($deci) {
						array_push($dates, decale($d, $deci, $un_jour));
					} else {
						array_push($dates, $d->format('Y-m-d'));
					}
					/* semaine suivante */
					$d->add($une_sem);
				}
				break;
		}
	}

	/* Date de fin calculée par glissement ---------------------------------------------------------
	 *	$fins : tableau destinataire des dates de fin (en référence)
	 *	$debuts : dates de début
	 *	$regle : règle LEONARD
	 *		--> le retour se fait dans $fins
	 * */

	function glissement(&$fins, $debuts, $regle) {

		$un_jour = new DateInterval('P1D');

		$reg = explode('|', $regle);

		if ($reg[0] == 'J') {

			array_push($fins, null);

		} else {

			$interval = 0;
			if (count($reg) > 0){
				$interval = (string)(abs(intval($reg[1], 10)));
			}

			/* $decalage = $reg[2];
			 * $deci = intval($decalage, 10);
			 * le décalage éventuellement indiqué dans la formule n'a pas de sens
			 * puisque le calcul se fait toujours en jours ouvrés
			 * */

			$d = new DateTime();

			$nbdeb = count($debuts);
			$debec = 0;

			while ($debec < $nbdeb) {

				$deb = $debuts[$debec];
				$debec++;

				if ($deb == null) {

					/* Pas de date de début => pas de date de fin */

					array_push($fins, null);

				} else {

					/* Date de début */
					$d->setDate(intval(substr($deb, 0, 4)),intval(substr($deb, 5, 2), 10), intval(substr($deb, 8, 2)));

					/* Glissement sur le nième jour ouvré */

					$nb = 0;
					while ($nb < $interval) {
						$d->add($un_jour);
						if (ferie($d) === false){
							$nb++;
						}
					}


					/* Application du décalage éventuelle sur jour non ouvré 
					sans objet, même en présence d'un décalage indiqué
					if ($deci) {
						array_push($fins, decale($d, $deci, $un_jour));
					} else {
						array_push($fins, $d->format('Y-m-d'));
					}
					*/
					array_push($fins, $d->format('Y-m-d'));
				}
			}
		}
	}

	/* Calcul du plan d'un processus ---------------------------------------------------------------
	 *	$pro : données du processus
	 *	$anref : année de référence (null => année courante)
	 *	$batch : vrai si traitement par batch (défaut)
	 *	$report : indication de l'année en cas de report
	 *	$suppr : supprime y compris les occurrences manuelles si vrai
	 *		--> retourne le rapport */

	function calcul($pro, $anref=null, $batch=true, $report=null, $suppr=false) {

		global $db;

		/* Fin de ligne */
		$fdl = ($batch ? "\n" : '<br>');

		$rapport = str_repeat('-', 80).$fdl.$pro['pro_index'].'-'.$pro['pro_nom'].$fdl.$pro['pro_regle'].$fdl;

		/* Année de référence */
		$an = ($anref === null ? $an = date('Y') : $an = "$anref");

		/* Aujourd'hui */
		$jour = date('Y-m-d');

		/* Calcul des dates */

		$planDebut = array();
		$planFin = array();
		$planButoir = array();

		/* En 2014, comportement spécial, on peut partir du 1er janvier ;
		* à partir de 2015, on part de la date du jour */

		$debut = $an.'-01-01';
		if (($an > '2014') && ($debut < $jour)){
			$debut = $jour;
		}
		$fin = $an.'-12-31';

		/* Suppression des anciennes occurrences dans la période de validité
		* seulement quand on se situe dans l'année en cours
		* et qu'il n'existe pas de réalisé pour la mise au plan */

		$sup_deb = ($debut > $pro['pro_debut'] ? $debut : $pro['pro_debut']);
		$sup_fin = ($fin < $pro['pro_fin'] ? $fin : $pro['pro_fin']);
		$req = 'DELETE FROM plan
				WHERE pro_id=$1 
				AND (
					(pln_debut IS NULL)
					OR 
					(
						pln_debut BETWEEN $2 AND $3
						AND pln_fin BETWEEN $2 AND $3 '
						.($suppr ? '' : ' AND pln_fin_calc IS NOT NULL').'
					)
					OR (pln_debut > $3)
				)
				AND NOT EXISTS (SELECT * FROM realise WHERE realise.pln_id=plan.pln_id)';
		$prm = array($pro['pro_id'], $sup_deb, $sup_fin);
		pg_query_params($db, $req, $prm);

		/* Déterminer si le processus est ajustable ==> présence de A=1 dans la règle, 
		* Traitement premier jour obligatoire ==> présence de O=1 dans la règle*/

		$ajustable = 'f';
		$obligatoire = 'f';
		$regle = array();
		preg_match('/A=([^,]*)/', $pro['pro_regle'], $regle);
		if (count($regle) > 1) {
			if ($regle[1] == '1'){
				$ajustable = 't';
			}
		}
		preg_match('/O=([^,]*)/', $pro['pro_regle'], $regle);
		if (count($regle) > 1) {
			if ($regle[1] == '1'){
				$obligatoire = 't';
			}
		}
		$req = 'UPDATE processus SET pro_ajustable=$1, pro_premier=$2 WHERE pro_id=$3';
		$prm = array($ajustable, $obligatoire, $pro['pro_id']);
		pg_query_params($db, $req, $prm);

		/* Bornage à l'année */

		if ($pro['pro_debut'] > $debut){
			$debut = $pro['pro_debut'];
		}
		if ($pro['pro_fin'] < $fin){
			$fin = $pro['pro_fin'];
		}

		if ($fin < $debut) {
			$rapport .= ' --> ATTENTION : pas de mise au plan sur '.$an.$fdl;
		} else {

			$regle = array();
			preg_match('/D=([^,]*)/', $pro['pro_regle'], $regle);

			if (count($regle) == 0) {
				$rapport .= ' --> ATTENTION : pas de règle pour la date de début.'.$fdl;
			} else {

				/* Règle de début */
				dateFixe($planDebut, $regle[1], $debut, $fin, $an);

				/* Règle de fin */
				$regle = array();
				preg_match('/F=([^,]*)/', $pro['pro_regle'], $regle);

				if (count($regle) == 0) {
					$rapport .=' --> ATTENTION : pas de règle pour la date de fin.'.$fdl;
				} else {

					glissement($planFin, $planDebut, $regle[1]);

					/* Règle de butoir */
					$regle = array();
					preg_match('/B=([^,]*)/', $pro['pro_regle'], $regle);

					if (count($regle) != 0) {
						dateFixe($planButoir, $regle[1], $debut, $fin, $an);
					}
				}
			}
		}

		if ((count($planDebut) > 0) and (count($planFin) > 0) and (count($planDebut) == count($planFin))) {

			/* Période de dates sûres */
			$debutSur = '3333-01-01';
			$finSure = '1900-01-01';

			$regle = array();
			preg_match('/P=(\d{8})/', $pro['pro_regle'], $regle);

			if (count($regle) > 1) {
				$r = $regle[1];

				$debutSur = $an.'-'.substr($r, 2, 2).'-'.substr($r, 0, 2);
				$finSure = $an.'-'.substr($r, 6, 2).'-'.substr($r, 4, 2);

				if ($debutSur > $finSure) {
					$rapport .=' --> ATTENTION : période de dates sûres incohérente.'.$fdl;

					$debutSur = $finSure;
				}
			}

			/* Écriture des nouvelles occurrences */
			$nbocc = count($planDebut);
			$occec = 0;

			while ($occec < $nbocc) {

				$occdeb = $planDebut[$occec];
				$occfin = $planFin[$occec];

				if ($occdeb != null and $occfin != null) {

					/* Vérification de la présence d'une ancienne occurrence semblable */
					$req = 'SELECT COUNT(*)
							FROM plan
							WHERE pro_id=$1
							AND pln_debut=$2
							AND pln_fin=$3';
					$prm = array($pro['pro_id'], $occdeb, $occfin);
					$res = pg_query_params($db, $req, $prm);
					$lu = pg_fetch_row($res);

					if ($lu[0] == 0) {

						$conf = ((($occdeb >= $debutSur) && ($occfin <= $finSure)) ? 't' : 'f');

						if (count($planDebut) == count($planButoir)) {

							$req = 'INSERT INTO plan
										(pro_id, pro_version, pln_debut, pln_fin, pln_debut_calc,pln_fin_calc, pln_butoir, pln_confirm, pln_report)
									VALUES
										($1, $2, $3, $4, $3, $4, $5, $6)';
							$prm = array($pro['pro_id'], $pro['pro_version'],$occdeb, $occfin, $planButoir[$occec], $conf, $report);

						} else {

							$req = 'INSERT INTO plan
										(pro_id, pro_version, pln_debut, pln_fin, pln_debut_calc, pln_fin_calc, pln_confirm, pln_report)
									VALUES
										($1, $2, $3, $4, $3, $4, $5, $6)';
							$prm = array($pro['pro_id'], $pro['pro_version'],$occdeb, $occfin, $conf, $report);

							if (($occec == 0) and (count($planButoir) > 0)) {
								$rapport .= ' --> ATTENTION : règle butoir ignorée pour incohérence.'.$fdl;
							}
						}
						pg_query_params($db, $req, $prm);

					} else {

						$rapport .= ' --> ATTENTION : occurrence du '.jma($occdeb).' ignorée pour redondance.'.$fdl;
					}
				}
				$occec++;
			}
		} else {

			$rapport .= ' --> ATTENTION : règle(s) incohérente(s).'.$fdl;
		}

		/* Suppression du recalcul en batch */

		if ($batch) {
			$req = 'DELETE FROM recalcul WHERE pro_id=$1';
			pg_query_params($db, $req, array($pro['pro_id']));
		}

		return $rapport;
	}

	/* projette ----------------------------------------------------------------------------------------
	 *	$debini = début initial
	 *	$finini = fin initiale
	 *	$pro_regle = règle de calcul
	 *	$newdeb = (par référence, pour retour) début calculé en N+1
	 *	$newfin = (par référence, pour retour) fin calculée en N+1
	 **/
	function projette($debini, $finini, $pro_regle, &$newdeb, &$newfin) {
	
		$un_jour = new DateInterval('P1D');
		$un_an = new DateInterval('P1Y');
	
		/* Décalage début */
	
		$deci = 0;
		$regle = array();
		preg_match('/D=([^,]*)/', $pro_regle, $regle);
		if (count($regle)) {
			$reg = explode('|', $regle[1]);
			$deci = intval($reg[(count($reg)-1)], 10);
		}
	
		/* Nouvelle période */
	
		$j = 0;
		$nwd = new DateTime($debini);
		$nwd->add($un_an);
		if ($deci){
			while (ferie($nwd)){
				if ($deci > 0){
					$nwd->add($un_jour);
				}else{
					$nwd->sub($un_jour);
				}
			}
		}
		$newdeb = $nwd->format('Y-m-d');
	
		/* Glissement en fonction de la règle */
	
		$fin = array();
		$regle = array();
		preg_match('/F=([^,]*)/', $pro_regle, $regle);
		$newfin = null;
		if (count($regle) > 0) {
			glissement($fin, array($newdeb), $regle[1]);
			$newfin = $fin[0];
		}
	
		/* Nombre de jours initiaux quand règle comporte F=J ou échoue */
	
		if ($newfin == null) {
	
			/* Décalage fin */
	
			$deci = 0;
			if (count($regle)) {
				$reg = explode('|', $regle[1]);
				$deci = intval($reg[(count($reg)-1)], 10);
			}
	
			/* Calcul du nombre de jours */
	
			$j = 0;
			$nbj = 0;
			$nwd = new DateTime($debini);
			$periode = feries($nwd, 101);
			while (($nwd->format('Y-m-d') <= $finini) && ($j < 100)) {
				$nwd->add($un_jour);
				if ($periode{$j} == '1'){
					
					$nbj++;
				}
				$j++;
			}
			if ($nbj == 0){
				$nbj = 1;
			}
	
			/* Application du nombre de jours */
	
			$nwd = new DateTime($newdeb);
			$periode = feries($nwd, 111);
			while (($nbj > 0) && ($j < 110)) {
				if ($periode{$j} == '1'){
					$nbj--;
				}
				if ($nbj > 0){
					$nwd->add($un_jour);
				}
				$j++;
			}
	
			if ($deci){
				$newfin = decale($nwd, $deci, $un_jour);
			}else{
				$newfin = $nwd->format('Y-m-d');
			}
	    }
	}

	/* purge_report ------------------------------------------------------------------------------------
	 * Purge le report N+1
	 * 	--> retourne un rapport
	 * */
	function purge_report() {
	
		global $db;
	
		$rapport = '';
	
		if (pose_verrou()) {
	
			/* Année N+1 */
	
			$np1 = intval(date('Y')) + 1;
	
			/* Suppression des occurrence sur N+1 issu d'un précédent passage du report */
	
			$req = 'DELETE FROM plan WHERE pln_report=$1';
			$res = pg_query_params($db, $req, array($np1));
	
			$rapport = ($res === false ?'<span class="erreur">La suppression a échoué.</span>' : '<span class="info">Suppression réalisée.</span>');
	
			retire_verrou();
		} else{
			$rapport = '<span class="erreur">La base SPPE est verrouillée.</span>';
		}
		return $rapport;
	}

	/* report ------------------------------------------------------------------------------------------
	 * La fonction report prépare les mises au plan pour l'année N+1.
	 * Elle est lancée manuellement par les membres du CQ.
	 * Elle applique la règle de calcul pour l'ensemble des processus.
	 * Elle reporte toutes les mises au plan manuelles de l'année N en N+1 en "à confirmer".
	 * --> retourne un rapport */
	function report() {
	
		global $db;
	
		if (pose_verrou()) {
	
			/* Année N+1 */
	
			$np1 = intval(date('Y')) + 1;
	
			/* Suppression des occurrence sur N+1 issu d'un précédent passage du report */
	
			$req = 'DELETE FROM plan WHERE pln_report=$1';
			$res = pg_query_params($db, $req, array($np1));
	
			/* Passage à l'état "à confirmer" des mises au plan déjà présente sur la période */
	
			$req = "UPDATE plan SET
					pln_confirm='f'
					WHERE EXTRACT(YEAR FROM pln_debut)=$1 OR EXTRACT(YEAR FROM pln_fin)=$1";
			$res = pg_query_params($db, $req, array($np1));
	
			/* Applique la règle de calcul pour l'ensemble des processus */
	
			$rapport = '';
			$req = 'SELECT * FROM processus WHERE NOT pro_generique';
			$res = pg_query($db, $req);
			while ($pro = pg_fetch_assoc($res)) {
				$rapport .= calcul($pro, "$np1", false, $np1);
			}
	
			/* Report des mises au plan manuelles de N sur N+1 en "à confirmer" */
	
			$req = 'SELECT q.pro_id, p.pro_regle, p.pro_debut, p.pro_fin, q.pln_debut, q.pln_fin
					FROM plan q
					JOIN processus p ON p.pro_id=q.pro_id
					WHERE q.pln_debut_calc IS NULL
					AND NOT p.pro_generique
					AND EXTRACT(YEAR FROM q.pln_debut)=$1
					AND EXTRACT(YEAR FROM p.pro_debut)<=$2
					AND EXTRACT(YEAR FROM p.pro_fin)>=$2';
			$res = pg_query_params($db, $req, array($np1-1, $np1));
	
			$debut = '';
			$fin = '';
			$ok = true;
			while (($lu = pg_fetch_assoc($res)) && ($ok !== false)) {
				/* Calcul des nouvelles dates de début et de fin pour chaque mise au plan */
				projette($lu['pln_debut'], $lu['pln_fin'], $lu['pro_regle'], $debut, $fin);
				/* Si dans la période de validité, création de la nouvelle mise au plan */
				if (($debut >= $lu['pro_debut']) && ($debut <= $lu['pro_fin'])) {
					$req = 'INSERT INTO plan
								(pro_id, pln_debut, pln_fin, uti_id, pln_report)
							VALUES
								($1, $2, $3, $4, $5)';
					$prm = array($lu['pro_id'], $debut, $fin, $_SESSION['uti_id'], $np1);
					$ok = pg_query_params($db, $req, $prm);
				}
			}
			retire_verrou();
			$rapport = '<p class="info">Report réalisé.</p>'
					.'<p class="notes">Suit la liste de tous les processus traités. '
					.'Y figurent les éventuelles anomalies rencontrées.<br>'
					.'Les règles sont systématiquement appliquées sur N+1 '
					.'en respect de la période de validité.<br>'
					.'Les mises au plan manuelles sont reportées en respectant la logique suivante :<br>'
					.' - même date de début, avec application éventuelle d\'un décalage '
					.'jour non ouvré si la règle de début (D=) comporte +1 ou -1 en fin ;<br>'
					.' - date de fin calculée par glissement quand la règle de fin vaut F=D... ;<br>'
					.' - date de fin calculée en fonction du nombre de jours ouvrés de l\'année N'
					.' quand la règle de fin vaut F=J ;<br>dans ce cas, application éventuelle'
					.' d\'un décalage jour non ouvré si la règle de fin comporte +1 ou -1 en fin.</p>'
					.$rapport;
		} else {
			$rapport = '<span class="erreur"> *** La base SPPE est verrouillée *** </span>';
		}
	
		return $rapport;
	}
?>
