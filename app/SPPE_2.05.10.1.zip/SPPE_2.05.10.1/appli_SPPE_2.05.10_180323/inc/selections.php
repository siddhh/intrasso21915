<?php

    /* Sélections ------------------------------------------------------------------------------- */

    /* Filtres en SQL ------------------------------------------------------------------------------
     * $i : indice de départ pour les variables PostgreSQL
     * $prm : tableau des paramètres à compléter (passage par référence)
     * --> retourne la séquence SQL */

    function filtresSQL($i, &$prm) {

        /* Domaine */

        $sql = '(a.dom_id=$'.$i.' or $'.$i.'::int4=0)';
        array_push($prm, $_SESSION['sel_dom']);
        $i++;

        /* Application ou équipe */

        $s = $_SESSION['sel_app'];
        if ($s != '0') {
            if ($s{0} == 'E') {
                $sql .= ' and a.serv_id=$'.$i;
            } else {
                $sql .= ' and a.app_id=$'.$i;
            }
            array_push($prm, substr($s, 1));
            $i++;
        }

        /* Chaîne */

        $s = $_SESSION['sel_chn'];
        if ($s != '0') {
            $sql .= ' and c.chn_id=$'.$i;
            array_push($prm, $s);
            $i++;
        }

        /* Processus */

        $s = $_SESSION['sel_pro'];
        if ($s != '0') {
            $sql .= ' and p.pro_id=$'.$i;
            array_push($prm, $s);
            $i++;
        }

        /* Suivi simplifié */

        if ($_SESSION['sel_sui'] != 'on') {
            $sql .= ' and p.pro_suivi=$'.$i;
            array_push($prm, 'f');
            $i++;
        }

        /* Travaux à venir seulement */

        if ($_SESSION['sel_ave'] == 'on') {
            $sql .= ($_SESSION['sel_esi'] != 0 ? ' and y.encours>0 ' : ' and z.encore>0 ')
                .' and not q.pln_suppr ';
        }

        /* Sélection spécifique d'une occurrence du plan */

        if (array_key_exists('pln_id', $_REQUEST)) {
            $pln_id = $_REQUEST['pln_id'];
            if (strpos($pln_id, 'd') > 0) {
                $elements = explode('d', $pln_id);
                $e = $elements[0];
                if ($e{0} == 'p') {
                    $sql .= ' and p.pro_id=$'.$i;
                    array_push($prm, substr($e, 1));
                } else {
                    $sql .= ' and q.pln_id=$'.$i;
                    array_push($prm, $e);
                }
                $i++;
            } else {
                if ((strlen($pln_id) > 0) and ctype_digit($pln_id)) {
                    $sql .= ' and q.pln_id=$'.$i;
                    array_push($prm, $pln_id);
                    $i++;
                }
            }
        }

        return $sql;
    }

    /* ------------------------------------------------------------------------------------------ */

    /* Domaines */

    $req = 'select dom_id, dom_nom from domaines where dom_ok order by dom_nom';
    $res = pg_query($db, $req);
    $sdom = options($res, $_SESSION['sel_dom'], 'Tous');

    /* ESI */

    $req = 'select esi_id, esi_nom from esi where esi_ok order by esi_nom';
    $res = pg_query($db, $req);
    if (isset($realise) and $realise) {
        if ($_SESSION['sel_esi'] == '0' and
            $_SESSION['esi_id'] != '0' and
            $_SESSION['esi_id'] != null) {
            $_SESSION['sel_esi'] = $_SESSION['esi_id'];
        }
        $sesi = options($res, $_SESSION['sel_esi']);
    } else {
        $sesi = option('~ Vue nationale ~', '0', $_SESSION['sel_esi']);
        $sesi .= options($res, $_SESSION['sel_esi']);
    }

    /* Équipes & Applications */

    $eqp_app = '';
    $eqp_app_id = '0';

    $req = 'SELECT $2||s.serv_id, s.serv_nom
    		FROM services s
    		LEFT JOIN attacher a ON s.serv_id=a.serv_id
    		WHERE s.serv_ok 
    		AND (a.dom_id=$1 OR a.dom_id IS NULL OR $1::int4=0)
    		AND s.esi_id IS NULL
    		GROUP BY s.serv_id, s.serv_nom
    		ORDER BY s.serv_nom';
    $res = pg_query_params($db, $req, array($_SESSION['sel_dom'],'E'));
    $sapp = options($res, $_SESSION['sel_app'], 'Toutes', 'Équipes');

    if ($Selected != '0') {
        $eqp_app = 'E';
        $eqp_app_id = substr($Selected, 1);
        $_SESSION['sel_app'] = $Selected;
    }

    $req = 'select $2||app_id, app_nom
    		from applications
    		where app_ok and (dom_id=$1 or dom_id is null or $1::int4=0)
    		order by app_nom';
    $res = pg_query_params($db, $req, array($_SESSION['sel_dom'],'A'));
    $sapp .= options($res, $_SESSION['sel_app'], '', 'Applications');

    if ($Selected != '0') {
        $eqp_app = 'A';
        $eqp_app_id = substr($Selected, 1);
        $_SESSION['sel_app'] = $Selected;
    }
    if ($eqp_app == ''){
    	$_SESSION['sel_app'] = '0';
    }

    /* Chaines */

    $cond = '';
    $parm = array($_SESSION['sel_dom']);
    switch ($eqp_app) {
        case 'E' : $cond = ' and a.serv_id=$2 ';
            array_push($parm, $eqp_app_id);
            break;
        case 'A' : $cond = ' and a.app_id=$2 ';
            array_push($parm, $eqp_app_id);
            break;
    }

    $req = 'select c.chn_id, c.chn_nom
            from chaines c
                join applications a on a.app_id=c.app_id
            where c.chn_ok and a.app_ok '.$cond
                .' and (a.dom_id=$1 or a.dom_id is null or $1::int4=0)
            order by c.chn_nom';
    $res = pg_query_params($db, $req, $parm);
    $schn = options($res, $_SESSION['sel_chn'], 'Toutes');
    if ($Selected == '0') $_SESSION['sel_chn'] = 0;

    /* Processus */

    if ($Selected != '0') {
        $cond .= ' and c.chn_id=$'.(count($parm) + 1).' ';
        array_push($parm, $Selected);
    }

    $req = 'select distinct p.pro_id, p.pro_nom
        from processus p
            join liens l on l.pro_id=p.pro_id
            join membrex m on m.mbx_id=l.mbx_id
            join chaines c on c.chn_id=m.chn_id
            join applications a on a.app_id=c.app_id
        where c.chn_ok and a.app_ok '.$cond
            .' and (a.dom_id=$1 or a.dom_id is null or $1::int4=0)
        order by p.pro_nom';
    $res = pg_query_params($db, $req, $parm);
    $spro = options($res, $_SESSION['sel_pro'], 'Tous');
    if ($Selected == '0') $_SESSION['sel_pro'] = 0;

    /* Suivi simplifié et travaux à venir */

    $ssui = (isset($_SESSION['sel_sui']) && $_SESSION['sel_sui'] == 'on' ? 'checked' : '');
    $save = (isset($_SESSION['sel_ave']) && $_SESSION['sel_ave'] == 'on' ? 'checked' : '');
?>
