<?php

	/* Saisie manuelle des dates */

	if ((strlen($pln_id_suivant) > 0) && (strpos($pln_id_suivant, 'd') > 0)) {

		$elements = explode('d', $pln_id_suivant);
		$nb_elmts = count($elements);

		if ($nb_elmts == 2) {

			$modif = false;
			$nouvelle_date = '-';
// 			$action = 'dates.php';
			$redirection = '<input type="hidden" name="page" value="dates" />';
			$processus = '0';
			$pln_id = '0';
			$suivant = "<input type=\"submit\" name=\"cmd_sais_suiv\" id=\"cmd_sais_suiv\" value=\"Enregistrer\npuis suivant\">";

			if ((ctype_digit($elements[0])) && ($elements[0] != '0') && (strlen($elements[1]) == 8)) {

				/* Gestion des dates et on dispose d'un identifiant de mise au plan */

				$processus = $_SESSION['gd_res'];
				$pln_id = $elements[0];

			} else {

				if ($elements[0] == '0') {

					/* Gestion des dates, ajout */

					$processus = $_SESSION['gd_res'];
					if (strlen($elements[1]) == 8) {
						$nouvelle_date = substr($elements[1], 0, 4).'-'.substr($elements[1], 4, 2).'-'.substr($elements[1], 6, 2);
					}

				} else {

					if ($pln_id_suivant{0} == 'p') {

						/* Réception des données depuis prévisions,
						* le premier élément contient l'identifiant processus */

						$processus = substr($elements[0], 1);

					} else {

						/* Prévisions et on dispose d'un identifiant de mise au plan */

						$pln_id = $elements[0];
					}

					/* Détermination de la date en cours */

					if (isset($deb)){
						$d = new DateTime($deb);
					}else{
						$d = new DateTime();
					}
					$j = intval($elements[1], 10);
					if ($j > 1) {
						$i = new DateInterval('P'.($j-1).'D');
						$d->add($i);
					}
					$nouvelle_date = $d->format('Y-m-d');
// 					$action = 'prevision.php';
					$redirection = '<input type="hidden" name="page" value="prevision" />';
					$suivant = '';
				}
			}

			if ($pln_id != '0') {

				$req = 'SELECT p.pro_nom, p.pro_lib, p.pro_regle, p.pro_reglehtml, q.*, u.uti_nom, u.uti_prenom, (q.pln_debut_calc is null) as manuel, p.pro_ajustable, (SELECT COUNT(*) FROM realise r WHERE r.pln_id=q.pln_id) as reel
						FROM plan q
						JOIN processus p ON p.pro_id=q.pro_id
						LEFT OUTER JOIN utilisateurs u ON u.uti_id=q.uti_id
						WHERE q.pln_id=$1';
				$res = pg_query_params($db, $req, array($pln_id));
				$modif = (pg_num_rows($res) > 0);

			}

			$supprimer = '';
			$supprimee = '';
			if ($modif) {
				$titre = 'Modifier';
				$lu = pg_fetch_assoc($res);
				if ($lu['pln_suppr'] == 'f') {
					$dis = '';
					if ($lu['reel'] > 0 ) {
						$dis = ' disabled';
						$supprimee = '<p> &bull; <span class="rouge gras">La suppression est désactivée pour cette occurrence car du réalisé existe</span></p>';
					}
					$supprimer = '<input type="button" id="cmd_sais_suppr" value="Supprimer" '.$dis.'>';
				} else {
					$supprimer = '<input type="submit" name="cmd_sais_rest" id="cmd_sais_rest" value="Restaurer">';
					$supprimee = '<p> &bull; <span class="rouge gras">OCCURRENCE SUPPRIMÉE</span></p>';
				}
			} else {

				$req = 'SELECT pro_regle, p.pro_reglehtml FROM processus p WHERE pro_id=$1';
				$res = pg_query_params($db, $req, array($processus));
				if (pg_num_rows($res)){
					$lu = pg_fetch_assoc($res);
				}else {
					$lu['pro_regle'] = '???';
					$lu['pro_reglehtml'] = '???';
				}
				$titre = 'Ajouter';
				$lu['pln_debut'] = $nouvelle_date;
				$lu['pln_fin'] = $nouvelle_date;
				$lu['pln_notes'] = '';
				$lu['pln_prive'] = '';
				$lu['pln_confirm'] = 't';
				$lu['manuel'] = 't';
				$lu['pro_ajustable'] = 't';
			}
			$confirm = ($lu['pln_confirm'] == 't' ? ' checked' : '');
			$saisie_dates = '
				<div id="saisie_dates">
					<form action="index.php" name="frm_sais_dates" id="frm_sais_dates" method="POST">'
						.$redirection.'
						<input type="hidden" id="hsais_pln_id" name="hsais_pln_id" value="'.$pln_id.'">
						<input type="hidden" id="hsais_pro_id" name="hsais_pro_id" value="'.$processus.'">
						<input type="hidden" id="hsais_debut" name="hsais_debut" value="'.$lu['pln_debut'].'">
						<input type="hidden" id="hsais_fin" name="hsais_fin" value="'.$lu['pln_fin'].'">
						<input type="hidden" id="hsais_manuel" name="hsais_manuel" value="'.$lu['manuel'].'">
						<input type="hidden" id="hsais_ajustable" name="hsais_ajustable" value="'.$lu['pro_ajustable'].'">
						<input type="hidden" id="hsais_supdef" name="hsais_supdef" value="-">
						<fieldset><legend>'.$titre.' une occurrence</legend>'
							.dates_previsionnelles($lu).'
							<p id="regle"> &bull; Règle : <span class="bleu">'.$lu['pro_regle'].'</span></p>'
							.$lu['pro_reglehtml']
							.$supprimee.'
							<div id="saisie">
								<div id="saisie_notes">
									<div><label for="sais_notes">Observations BE</label></div>
									<div><textarea rows="3" cols="30" name="sais_notes" id="sais_notes">'.$lu['pln_notes'].'</textarea></div>
								</div>
								<div>
									<p>
										<span>
											<label for="sais_debut">Début</label>
											<img src="img/calendar.gif" id="sais_debut_cal">
											<input type="text" name="sais_debut" id="sais_debut" value="'.jma($lu['pln_debut']).'" size="10" maxlength="10">
											<img src="img/efface.gif" id="sais_debut_eff">
										</span>
										&bull;
										<span>
											<label for="sais_fin">Fin</label>
											<img src="img/calendar.gif" id="sais_fin_cal">
											<input type="text" name="sais_fin" id="sais_fin" value="'.jma($lu['pln_fin']).'" size="10" maxlength="10">
											<img src="img/efface.gif" id="sais_fin_eff">
										</span>
										&bull;
										<span>
											<input type="checkbox" name="sais_confirm" id="sais_confirm"'.$confirm.'>
											<label for="sais_confirm">Confirmé</label>
										</span>
									</p>
									<p>
										<input type="submit" name="cmd_sais_enrgt" id="cmd_sais_enrgt" value="Enregistrer">'
										.$suivant.$supprimer.'
										<input type="submit" name="cmd_sais_annul" value="Annuler">
									</p>
								</div>
							</div>
							<div id="notes_privees">
								<div id="prive_notes">
									<div><label for="prive_notes">Notes</label></div>
									<div><textarea rows="2" cols="90" name="prive_notes" id="prive_notes">'.$lu['pln_prive'].'</textarea></div>
								</div>
							</div>
						</fieldset>
						<div id="dialogue">
							<div id="dialogue_coeur">
								<p>L'."'".'occurrence est <span id="dialogue_texte"></span>,
								<br>quel type de visualisation souhaité ?
								<hr>
								<p><input type="submit" name="dialogue_aff" value="Afficher la suppression"></p>
								<p><input type="submit" name="dialogue_sup" value="Suppression de l'."'".'affichage"></p>
							</div>
						</div>
					</form>
				</div>';
		}
	}
?>
