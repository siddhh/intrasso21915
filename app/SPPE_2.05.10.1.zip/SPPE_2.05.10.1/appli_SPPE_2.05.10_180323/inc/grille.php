<?php

	require __DIR__ .'/Cellule.php';
	require __DIR__ .'/../sql/sql_realise.php';
	require __DIR__ .'/jobs.php';

	/* Enregistrement de la saisie manuelle du réalisé */

	require __DIR__ .'/enregistre.php';
	require __DIR__ .'/enregistre_realise.php';

	/* liste_chaines -------------------------------------------------------------------------------
	 * Affiche les chaînes du processus
	 * $liste : liste des chaines
	 * --> retourne la liste adaptée en HTML */

	function liste_chaines($liste) {

		$rc = '<td class="chaines"';
		$x = explode(' ', $liste);
		$n = count($x);
		if($n > 2){
			$rc .= ' style="font-style:italic" title="'.$liste.'">'.$n.'&nbsp;chaînes';
		}else{
			if($n > 1){
				$rc .= '>'.$x[0].'&nbsp;'.$x[1];
			}else{
				$rc .= '>'.$liste;
			}
		}
		$rc .= '</td>';
		return $rc;
	}

	/* bulle ---------------------------------------------------------------------------------------
	 * Construit la bulle d'information quand nécessaire
	 * $cell : objet cellule en cours
	 * $obsv : observations
	 * $note : notes de réalisé
	 * --> retourne true quand une bulle est réellement ajoutée */
	function bulle($cell, $obsv, $note) {

		$texte = '';
		$rc = ($obsv or $note);

		if($rc){
			if ($obsv) {
				$texte = $obsv;
				if($note){
					$texte .= " / \n";
				}
			}

			if($note){
				$texte .= $note;
			}

			$cell->title($texte);
		}

		return $rc;
	}

	/* plus_moins ----------------------------------------------------------------------------------
	 * Bouton plus ou moins
	 * $lu : enregistrement courant
	 * $detail : identifiant du réalisé à détailler
	 * --> retourne le code HTML du bouton ±
	 */
	function plus_moins(&$lu, $detail) {
		if ($lu['pro_realise'] == 't') {
			$signe = ($detail == $lu['pln_id'] ? 'moins' : 'plus');
			$rc = '<td>';
			$rc .= '	<a id="pln'.$lu['pln_id'].'" href="index.php?page=realise&'.$signe.'='.$lu['pln_id'].'#pln'.$lu['pln_id'].'">';
			$rc .= '		<img src="img/'.$signe.'.png" alt="'.$signe.'" id="'.$signe.$lu['pln_id'].'" class="plus_moins">';
			$rc .='		</a>';
			$rc .= '</td>';
		} else {
			$rc = '<td title="Pas de suivi du réalisé automatique pour ce processus">'.'<img src="img/interdit.png" alt="interdit"></td>';
		}
		return $rc;
	}

	/* ------------------------------------------------------------------------------------------ */

	/* Grille des processus -- prévisionnel et réalisé */

	/* Paramètres sortie PDF */

	$export = '<input type="hidden" name="etat" value="grille_pdf">'
			.'<input type="hidden" name="sens" value="L">'
			.'<input type="hidden" name="realise" value="'.($realise ? 1 : 0).'">'
			.'<input type="hidden" name="titre_tableau" value="'.$titre_tableau.'">';
		$exportBis = '&etat=grille_pdf&sens=L&realise='.($realise ? 1 : 0).'&titre_tableau='.$titre_tableau;
	$grille = '<table>';

	$aujourdhui = new DateTime();
	$jour_iso = $aujourdhui->format('Y-m-d');

	$jours = '';

	$vue_semaine = (strlen($_SESSION['sel_cal']) > 7);

	$col_sup = ($realise ? 1 : 0); // une colonne supplémentaire pour ± en réalisé

	if ($vue_semaine) {
		require 'vue_semaine.php';
	} else {
		require 'vue_mois.php';
	}

	$fin = $cell->iso();    /* Fin non incluse */

	/* Sélection des processus */
	require __DIR__ .'/grille_selection.php';

	/* Détail des jobs demandé ? */
	$detail = 0;        // détail des jobs d'un processus
	$job_detail = 0;    // identifiant du job

	$suivi_simplif = false;

	if (pg_num_rows($res)) {
		if ($realise) {
			/* détail des jobs d'un processus ? */
			$detail = filter_input(INPUT_GET, 'plus', FILTER_VALIDATE_INT,array('options' => array('default' => 0)));
			/* détail d'un job spécifique ? */
			$job_detail = filter_input(INPUT_GET, 'job', FILTER_VALIDATE_INT,array('options' => array('default' => 0)));
		}

		/* Préparation du suivi simplifié et des processus présentant plusieurs occurrences */
		$processus = array();
		prepare_processus($processus, $res);

		/* Affichage des lignes du calendrier */
		$un_mois = 30;

		$ligne_actuelle = 0;
		$repetition_titre = (int) $_SESSION['prf_repete_titre'];

		$manuel = array('t' => '_manuel', 'f' => '');
		foreach($processus as $proc) {

			/* bouton + ou - en début de ligne et détail du réalisé */
			$plusmoins = '';
			$tableau_jobs = '';
			if ($realise) {
				$plusmoins = plus_moins($proc[0], $detail);
				if ($detail == $proc[0]['pln_id']) {
					$tableau_jobs = jobs($proc, $nb_jours + $col_sup + 1);
				}
			}

			$lu = array_shift($proc);
			$prev_suivante = occurrence_suivante($proc, $realise, $deb);

			$timbre1 = new DateTime($lu['pro_timbre']);

			/* Notes du CQMF */
			$observation = trim($lu['pln_notes']).((estHabil(HABIL_GESTION_DATE,$lu['dom_id']) && trim($lu['pln_prive']))?(trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
			$observations = $observation;

			/* Notes du réalisé */
			$annotation = '';
			if (array_key_exists('rea_notes', $lu)) {
				$annotation = trim($lu['rea_notes']);
			}

			/* nom du processus en rouge si modifié depuis moins d'un mois */
			$age = intval($aujourdhui->diff($timbre1)->format('%a'), 10);
			$pro_classe = ($age < $un_mois ? ' class="rouge"' : '');

			/* les processus modifiés depuis moins de 24h et concernant
			 * un processus qui doit passer dans les 7 jours sont indiqués
			 * par un panneau d'avertissement.
			 */
			$du_jour = (processus_recent($aujourdhui, $jour_iso, $lu, $proc, $age) ? '<img src="img/du_jour.png" alt="processus modifié ce jour" title="processus modifié ce jour" />' : '');

			/* nom du processus en italique s'il comporte une rupture */
			$rupture = '';
			if ($lu['pro_rupture'] == 't') {
				$pro_classe = ($pro_classe ? ' class="rouge italique"' : ' class="italique"');
				$rupture = ' (processus avec rupture)';
			}

			/* observations et commentaires */
			$l1 = trim($lu['pro_lib']);
			$libelle = $l1;
			$l2 = trim($lu['pro_libelle']);
			$l3 = trim($lu['pro_nouveautes']);
			if ($l1 != $l2){
				$libelle .= ' - '.$l2;
			}
			if ($l3 != $l1 and $l3 != $l2){
				$libelle .= ' - '.$l3;
			}
			$libelle .= $rupture;
			$libelle = ($libelle == '' ? '-' : $libelle);
			$libelle = str_replace('"', "'", $libelle);

			/* mise en évidence du passage aux processus en suivi simplifié */
			$separation = '';
			if ($lu['tri1'] == 2 and !$suivi_simplif) {
				$suivi_simplif = true;
				$separation = '<tr><td class="ferie" colspan="'.($nb_jours + $col_sup + 1).'">&nbsp;</td></tr>'; 
			}

			/* nom du processus et liste des chaînes */
			$ligne = $separation.'<tr>'.$plusmoins
				.'<td title="'.$libelle.'" style="border-right:0px none;"><a href="'
				.LEONARD.$lu['pro_vindex'].'" target="_blank"'.$pro_classe.'>'
				.$lu['pro_nom'].'</a></td><td style="border-left:0px none;">'
				.$du_jour.'</td>'.liste_chaines(trim($lu['lst_chaines']));
			if ($vue_semaine) {
				$borne = ($lu['pln_debut'] < $deb ? jma($lu['pln_debut']) : '&nbsp;');
				$ligne .= '<td class="dates">'.$borne.'</td>';
			}

			$recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);

			$j = 0;
			$cell->raz();

			while ($cell->ok()) {

				$j++;
				$raz = false;
				$courant = $cell->iso();

				/* Lecture de l'occurrence suivante pour les processus en suivi simplifié
				 * quand la date courante atteint le début de l'occurrence suivante */

				if ($courant >= $prev_suivante) {
					$lu = array_shift($proc);
					$prev_suivante = occurrence_suivante($proc, $realise, $courant);
					$observation = trim($lu['pln_notes']).((estHabil(HABIL_GESTION_DATE,$lu['dom_id'])&& trim($lu['pln_prive']))?(trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
					if ($observation) {
						if ($observations){
							$observations .= ' / '.$observation;
						}else{
							$observations = $observation;
						}
					}
					/* Notes du réalisé */
					$annotation = '';
					if (array_key_exists('rea_notes', $lu)) {
						$annotation = trim($lu['rea_notes']);
					}
					$recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);
				}

				/* contenu par défaut */
				$premier = (($lu['pro_premier'] == 't') && ($lu['pln_debut'] == $courant) && ($lu['pln_debut'] != $lu['pln_fin']));
				$contenu = ($premier ? '<span style="color:black;">!</span>' : '&nbsp;');

				if ($realise and ($lu['rea_debut'] != null)) {

					/* Définition hors prévisionnel */
					$hors_previsionnel = (
						/* commence avant */
						(
							($courant < $lu['pln_debut']) && ($courant >= $lu['rea_debut'])
						)
						or
						/* fini trop tard */
						(
							($courant > $lu['pln_fin']) && ($courant <= $jour_iso) && (($courant <= $lu['fin_retenue']) || ($lu['rea_fin'] == null))
						)
					);

					/* Présentation du réalisé en priorité */
					if ($lu['rea_fin'] == null) {

						/* Pas encore de date de fin */
						if ($courant >= $lu['rea_debut'] and $courant <= $jour_iso){
							$cell->classe(($lu['rea_statut'] == 'A' ? 'abort' : 'encours'));
						}

						/* pastille noir, processus hors prévisionnel */
						if ($hors_previsionnel){
							$cell->pastille(SPPE_ETAT_TERMINE);
						}

					} else {

						/* Présence d'une date de fin */
						if ($hors_previsionnel) {

							/* Hors période */
							if (($courant < $lu['pln_debut']) && ($courant >= $lu['rea_debut'])){
								$cell->classe('hors_delai_avant');
							}else{
								$cell->classe('hors_delai_apres');
							}

						} else {

							/* Dans les délais */
							if ($courant <= $lu['rea_fin'] && $courant >= $lu['rea_debut']) {
								$cell->classe(($lu['rea_statut'] == 'A' ? 'abort' :'termine'));
							} else {
								$raz = (($courant > $lu['rea_fin']) && ($lu['rea_statut'] == 'T'));
							}
						}
						/* pastille rouge, processus terminés ayant connu un abort */
						if ($courant == $lu['rea_fin'] && in_array($lu['pln_id'], $liste_abort))
							$cell->pastille(SPPE_ETAT_ABORT);
					}
				}

				/* Mise en évidence d'une information éventuelles */

				$prevision = (($courant >= $lu['pln_debut']) && ($courant <= $lu['pln_fin']));
				$reel = ($cell->etat() != '');

				/* Domaine */
				$cell->domaine($lu['dom_id']);

				if (($prevision || $reel) && ($raz == false)) {

					/* Cellule en évidence */

					/* Identification de la mise au plan */
					if (($_SESSION['esi_id'] != null) && ($_SESSION['esi_id'] != '0') && ($_SESSION['esi_id'] == $_SESSION['sel_esi'])) {
						/* Pour la saisie du réalisé */
						$cell->id('j'.str_pad($j, 2, '0', STR_PAD_LEFT).'i'.$lu['pln_id']);
					} else {
						if (!$realise && estHabil(HABIL_GESTION_DATE,$lu['dom_id'])) {
							/* Pour la gestion des dates réservée CQ */
							$cell->id($lu['pln_id'].'d'.$j);
						}
					}

					/* Souligner en rouge les modifications récentes */
					$cell->classe($recent);

					/* Réalisé seulement */
					if ($reel) {
						if (bulle($cell, $observation, $annotation)) {
							$contenu = ($premier ? $contenu : '').'(i)';
							$cell->classe('cell_info');
						}
						$ligne .= $cell->fabrique($contenu, 'td', false);
					} else {
						/* Prévisions seulement (y compris dans le réalisé) */
						if ($prevision) {
							bulle($cell, $observation, $annotation);
							if ($lu['pln_suppr'] == 't') {
								$cell->classe('supprime');
								$ligne .= $cell->fabrique('X', 'td', false);
							} else {
								if ($lu['pln_confirm'] == 't') {
									if ($realise and $lu['pro_realise'] == 'f' and $lu['pln_fin'] < $jour_iso and $lu['rea_debut'] == null ) {
										$cell->classe('termine');
									} else {
										$cell->classe('sure'.$manuel[$lu['manuel']]);
									}
									if ($observation or $annotation) {
										$contenu = ($premier ? $contenu : '').'(i)';
										$cell->classe('cell_info');
									}
									$ligne .= $cell->fabrique($contenu, 'td', false);
								} else {
									$cell->classe('pas_sure'.$manuel[$lu['manuel']]);
									$ligne .= $cell->fabrique(($premier ? $contenu : '?').'??','td', false);
								}
							}
						}
					}
				}else{

					/* Processus pas au plan ou remis à blanc */
					if (!$realise && estHabil(HABIL_GESTION_DATE,$lu['dom_id'])) {
						/* Pour la gestion des dates réservée CQ */
						$cell->id('p'.$lu['pro_id'].'d'.$j);
					}
					$ligne .= $cell->fabrique($contenu, 'td');
				}

				$cell->suivant();
			}

			if ($vue_semaine) {
				$borne = ($lu['pln_fin'] >= $fin ? jma($lu['pln_fin']) : '&nbsp;');
				$ligne .= '<td class="dates">'.$borne.'</td><td class="obs">'.$observations.'</td></tr>';
			} else {
				$ligne .= '</tr>';
			}

			if ($ligne_actuelle % $repetition_titre == 0) {
				$grille .= $entete;
			}
			$grille .= $ligne;

			/* Affichage du détail des jobs */
			$grille .= $tableau_jobs;

			$ligne_actuelle++;
		}
	} else {
		$grille .= '<tr><td class="neant" colspan="'.($nb_jours + $col_sup).'">Aucune occurrence pour la période et les critères sélectionnés.</td></tr>';
	}

	$grille .= '</table>';

	/* Saisies éventuelles ---------------------------------------------------------------------- */

	$saisie_dates = '';
	$saisie_realise = '';

	if ($realise) {
		/* Réalisé éventuel */
		if ($realise && (getPost('pln_id')!='') && estHabil(HABIL_REALISE_MANUEL,$lu['dom_id']) && ($_SESSION['sel_esi'] == $_SESSION['esi_id']) && ($_SESSION['esi_id'] != null)) {
			require 'reel.php';
		}
	} else {
		/* Saisie de dates éventuelle */
		$pln_id_suivant = '';
		if ((getPost('pln_id')!='') && estHabil(HABIL_GESTION_DATE,$lu['dom_id'])){
			$pln_id_suivant = getPost('pln_id');
			require 'saisie_dates.php';
		}
	}
?>
<?php echo $messages;?>
<div id="grille">
	<input type="hidden" id="plus" value="<?php echo $detail;?>">
	<input type="hidden" id="job_detail" value="<?php echo $job_detail;?>">
	<input type="hidden" id="idencours" value="<?php echo $pln_id_suivant;?>">
	<?php echo $grille;?>
</div>
<?php echo $saisie_realise;?>
<?php echo $saisie_dates;?>
<script>
	$(document).ready( function () {
		$("#grille table tbody tr td").hover(function(){
			var numjour = $(this).data('jour');
			$("th[data-jour='"+numjour+"']").addClass("surlignage");
			$("td[data-jour='"+numjour+"']").addClass("surlignage");
		},function(){
			var numjour = $(this).data('jour');
			$("th[data-jour='"+numjour+"']").removeClass("surlignage");
			$("td[data-jour='"+numjour+"']").removeClass("surlignage");
		});
	});
</script>