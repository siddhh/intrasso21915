<?php
    /* Préférences de l'utilisateur */

    require_once 'DEF_COULEURS.php';
    
    /* sel_couleur ---------------------------------------------------------------------------------
     * Sélecteur de couleur
     * $lib = libellé
     * $ses = variable de session
     * --> retourne le code HTML */
    function sel_couleur($lib, $ses) {
        $rc = '<p>';
        $rc .= '	<label for id="'.$ses.'" style="width:30em">'.$lib.'</label>';
        $rc .= '	<input class="color" value="'.substr($_SESSION[$ses], 1).'" name="'.$ses.'" id="'.$ses.'" size="10" maxlength="6" style="font-size:0.8em;">';
        $rc .= '</p>';
        return $rc;
    }

    $uti_id = $_SESSION['uti_id'];
    $msg = '';
    /* ------------------------------------------------------------------------------------------ */

    /* Répétition des entêtes dans le calendrier */

    $prf_repete_titre = $_SESSION['prf_repete_titre'];

    if (array_key_exists('prf_repete_titre_ok', $_POST)) {
        $nombre = intval($_POST['prf_repete_titre'], 10);
        if (($nombre < 2) || ($nombre > 99)) {
            $msg = '<p class="erreur">Le nombre doit être compris entre 2 et 99</p>';
        } else {
            $prf_repete_titre = $nombre;
            if ($uti_id > 0) {
                $ok = false;
                pg_query($db, 'begin');
                $req = "DELETE FROM preferences WHERE uti_id=$1 AND prf_objet='prf_repete_titre'";
                if (pg_query_params($db, $req, array($uti_id))) {
                    $req = "INSERT INTO preferences
                    			(uti_id, prf_objet, prf_valeur)
                    		VALUES
                    			($1, 'prf_repete_titre', $2)";
                    if (pg_query_params($db, $req, array($uti_id, $nombre))) {
                        $ok = pg_query($db, 'commit');
                    }
                    if ($ok) {
                    	$msg = '<p class="info">Préférence prise en compte</p>';
                        $_SESSION['prf_repete_titre'] = $nombre;
                    } else {
                    	$msg = '<p class="erreur">L\'enregistrement de la préférence a échoué</p>';
                        pg_query($db, 'rollback');
                    }
                }
            }
        }
    }

    /* Choix des couleurs */

    if ($uti_id > 0) {
        if (array_key_exists('prf_rtblr_coul', $_POST)) {
            $req = "DELETE FROM preferences WHERE uti_id=$1 AND prf_objet LIKE 'prf_coul_%'";
            $ok = pg_query_params($db, $req, array($uti_id));
            if ($ok) {
            	$msg = '<p class="info">Couleurs rétablies</p>';
                $_SESSION['prf_coul_calcule']    = SPPE_DEF_CALCULE;
                $_SESSION['prf_coul_manuel']     = SPPE_DEF_MANUEL;
                $_SESSION['prf_coul_termine']    = SPPE_DEF_TERMINE;
                $_SESSION['prf_coul_en_cours']   = SPPE_DEF_EN_COURS;
                $_SESSION['prf_coul_en_abort']   = SPPE_DEF_EN_ABORT;
                $_SESSION['prf_coul_hors_delai_apres'] = SPPE_DEF_HORS_DELAI_APRES;
                $_SESSION['prf_coul_hors_delai_avant'] = SPPE_DEF_HORS_DELAI_AVANT;
                $_SESSION['prf_coul_ferie']      = SPPE_DEF_FERIE;
            } else {
            	$msg = '<p class="erreur">Couleurs non rétablies</p>';
            }
        } else {
            if (array_key_exists('prf_enrgt_coul', $_POST)) {
                $ok = false;
                pg_query($db, 'begin');
                $req = "DELETE FROM preferences WHERE uti_id=$1 AND prf_objet LIKE 'prf_coul_%'";
                if (pg_query_params($db, $req, array($uti_id))) {
                    $req = "INSERT INTO preferences 
                    			(uti_id, prf_objet, prf_valeur)
                    		VALUES
                    			($1, $2, $3)";

                    $a = 'prf_coul_calcule';
                    $b = array($uti_id, $a, '#'.$_POST[$a]);
                    if (pg_query_params($db, $req, $b)) {
                        
                        $a = 'prf_coul_manuel';
                        $b = array($uti_id, $a, '#'.$_POST[$a]);
                        if (pg_query_params($db, $req, $b)) {
                            
                            $a = 'prf_coul_termine';
                            $b = array($uti_id, $a, '#'.$_POST[$a]);
                            if (pg_query_params($db, $req, $b)) {
                                
                                $a = 'prf_coul_en_cours';
                                $b = array($uti_id, $a, '#'.$_POST[$a]);
                                if (pg_query_params($db, $req, $b)) {
                                    
                                    $a = 'prf_coul_en_abort';
                                    $b = array($uti_id, $a, '#'.$_POST[$a]);
                                    if (pg_query_params($db, $req, $b)) {
                                        
                                        $a = 'prf_coul_hors_delai_apres';
                                        $b = array($uti_id, $a, '#'.$_POST[$a]);
                                        if (pg_query_params($db, $req, $b)) {
                                            
                                        	$a = 'prf_coul_hors_delai_avant';
                                        	$b = array($uti_id, $a, '#'.$_POST[$a]);
                                        	if (pg_query_params($db, $req, $b)) {
                                        		
	                                            $a = 'prf_coul_ferie';
	                                            $b = array($uti_id, $a, '#'.$_POST[$a]);
	                                            if (pg_query_params($db, $req, $b)) {
	                                
	                                                $ok = pg_query($db, 'commit');
	                                            }
                                        	}
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if ($ok) {
                    	$msg = '<p class="info">Couleurs enregistrées</p>';
                        $_SESSION['prf_coul_calcule']    = '#'.$_POST['prf_coul_calcule'];
                        $_SESSION['prf_coul_manuel']     = '#'.$_POST['prf_coul_manuel'];
                        $_SESSION['prf_coul_termine']    = '#'.$_POST['prf_coul_termine'];
                        $_SESSION['prf_coul_en_cours']   = '#'.$_POST['prf_coul_en_cours'];
                        $_SESSION['prf_coul_en_abort']   = '#'.$_POST['prf_coul_en_abort'];
                        $_SESSION['prf_coul_hors_delai_apres'] = '#'.$_POST['prf_coul_hors_delai_apres'];
                        $_SESSION['prf_coul_hors_delai_avant'] = '#'.$_POST['prf_coul_hors_delai_avant'];
                        $_SESSION['prf_coul_ferie']      = '#'.$_POST['prf_coul_ferie'];
                    } else {
                    	$msg = '<p class="erreur">Couleurs mal enregistrées</p>';
                        pg_query($db, 'rollback');
                    }
                }
            }
        }
    }
    
?>
<h6 id="h6_admin_prefs">Vos préférences utilisateur</h6>
<div id="admin_prefs">
	<div style="padding:0.3em;">
		<?php echo $msg;?>
		<form action="" method="POST">
			<input type="hidden" name="module" value="admin_prefs" />
			<p class="notes">Fréquence de répétition des entêtes de colonnes dans le calendrier (en nombre de lignes)</p>
        	<p>
        		<input type="text" name="prf_repete_titre" id="prf_repete_titre" value="<?php echo $prf_repete_titre;?>" size="3" maxlength="2">
        		&nbsp;
        		<input type="submit" name="prf_repete_titre_ok" id="prf_repete_titre_ok" value="Enregistrer" style="width:8em">
        	</p>

    		<hr>	
			
			<p class="notes">Couleurs du calendrier (cliquez sur une couleur pour la modifier)</p>
		<?php
			echo sel_couleur('Prévisionnel : Processus calculé automatiquement', 'prf_coul_calcule');
			echo sel_couleur('Prévisionnel : Processus remplis manuellement par le CQMF','prf_coul_manuel');
			echo sel_couleur('Réalisé : Terminé', 'prf_coul_termine');
			echo sel_couleur('Réalisé : En cours', 'prf_coul_en_cours');
			echo sel_couleur('Réalisé : En abort', 'prf_coul_en_abort');
			echo sel_couleur('Réalisé : Avant prévisionnel', 'prf_coul_hors_delai_avant');
			echo sel_couleur('Réalisé : Après le prévisionnel', 'prf_coul_hors_delai_apres');
			echo sel_couleur('Jours non ouvrés', 'prf_coul_ferie');
		?>
    		<p>
    			&nbsp;
    			<input type="submit" name="prf_enrgt_coul" id="prf_enrgt_coul" value="Enregistrer" style="width:8em">
    			&nbsp;
    			<input type="submit" name="prf_rtblr_coul" id="prf_rtblr_coul" value="Rétablir les couleurs par défaut" style="width:18em">
    		</p>
		</form>
	</div>
</div>