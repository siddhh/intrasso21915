<style type="text/css">
	/* date à confirmer */
	.pas_sure {
		background-color:<?php echo $_SESSION['prf_coul_calcule'];?> !important;
		text-align:center;
	}

	/* date à confirmer (manuel) */
	.pas_sure_manuel {
		background-color:<?php echo $_SESSION['prf_coul_manuel'];?> !important;
		text-align:center;
	}

	/* date sûre */
	.sure {
		background-color:<?php echo $_SESSION['prf_coul_calcule'];?> !important;
	}

	/* date sûre (manuel) */
	.sure_manuel {
		background-color:<?php echo $_SESSION['prf_coul_manuel'];?> !important;
	}

	/* terminé */
	.termine {
		background-color:<?php echo $_SESSION['prf_coul_termine'];?> !important;
	}

	/* en cours */
	.encours {
		background-color:<?php echo $_SESSION['prf_coul_en_cours'];?>!important;
	}

	/* abort */
	.abort {
		background-color:<?php echo $_SESSION['prf_coul_en_abort'];?> !important;
	}

	/* hors délai apres */
	.hors_delai_apres {
		background-color:<?php echo $_SESSION['prf_coul_hors_delai_apres'];?> !important;
	}
	
	/* hors délai avant*/
	.hors_delai_avant {
		background-color:<?php echo $_SESSION['prf_coul_hors_delai_avant'];?> !important;
	}

	/* jours fériés */
	.ferie {
		background-color:<?php echo $_SESSION['prf_coul_ferie'];?>;
	}
</style>
