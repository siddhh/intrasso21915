<?php

/* SPPE
 * Outils d'administration réservé à SI
 *
 * JMD - 11/02/2016
 */

require __DIR__ .'/../sql/sql_adminsi.php';

/* admin_applis ------------------------------------------------------------------------------------
 * Administration des applications
 */
function admin_applis() {

    /* Enregistrement des modifications */

    if (array_key_exists('siga_enrgt', $_POST)) {

        /* Réception des variables postées */
        $app = filter_input(INPUT_POST, 'siga_app');
        $lib = filter_input(INPUT_POST, 'siga_lib',
            FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES );
        $dom = filter_input(INPUT_POST, 'siga_dom');
        $eqp = filter_input(INPUT_POST, 'siga_eqp');
        $act = (array_key_exists('siga_act', $_POST) ? 't' : 'f');

        /* Mise-à-jour de l'application */
        sql_maj_appli($app, $lib, $dom, $eqp, $act);
    }

    /* Lecture des applications, des domaines et des équipes */

    $applis = sql_lis_applis();
    $js_app = array();
    while ($lu = pg_fetch_assoc($applis))
        $js_app[$lu['app_id']] = $lu;
    pg_result_seek($applis, 0);

    $equipes = sql_lis_equipes();
    $js_eqp = array();
    while ($lu = pg_fetch_assoc($equipes))
        $js_eqp[$lu['eqp_id']] = $lu;
    pg_result_seek($equipes, 0);

    $domaines = sql_lis_domaines();
    $js_dom = array();
    while ($lu = pg_fetch_assoc($domaines))
        $js_dom[$lu['dom_id']] = $lu;
    pg_result_seek($domaines, 0);

    /* IHM */

    $rc = '<h6 id="h6_adm_app">Administration : Gestion des applications</h6>'
        .'<div id="adm_app">'
        .'<form action="" method="POST">'
        .'<input type="hidden" name="activ_adm_app">'
        .'<p><label for="siga_app">Application</label>'
        .'<select name="siga_app" id="siga_app">'
            .options($applis, '', '---')
        .'</select></p>'
        .'<p><label for="siga_lib">Libellé</label>'
        .'<input type="text" name="siga_lib" id="siga_lib" size="40" maxlength="1000"></p>'
        .'<p><label for="siga_dom">Domaine</label>'
        .'<select name="siga_dom" id="siga_dom">'
            .options($domaines, '', '---')
        .'</select></p>'
        .'<p><label for="siga_eqp">Équipes</label>'
        .'<select name="siga_eqp" id="siga_eqp">'
            .options($equipes, '', '---')
        .'</select></p>'
        .'<p><label for="siga_act">Actuelle</label>'
        .'<input type="checkbox" name="siga_act" id="siga_act"></p>'
        .'<p>&nbsp;<input type="submit" name="siga_enrgt" id="siga_enrgt"'
        .   ' value="Enregistrer" disabled>'
            .'&nbsp;<input type="reset" value="Annuler"></p>'
        .'</form></div>'
        .'<script type="text/javascript" src="js/adminsi.js?timestamp='.time().'"></script>'
        .'<script type="text/javascript">'
            .'var siga_applis = '.json_encode($js_app).';'
            .'var siga_equipes = '.json_encode($js_eqp).';'
            .'var siga_domaines = '.json_encode($js_dom).';'
        .'</script>';
    return $rc;
}

/* admin_equipes -----------------------------------------------------------------------------------
 * Administration des équipes
 */
function admin_equipes() {

    $etat_liste = 'disabled';
    $etat_creer = 'disabled';
    $etat_modifier = '';
    $etat_supprimer = 'disabled';
    $etat_saisie = false;

    $eq = array();  // Équipe
    $msg = '';      // Message

    /* Lecture des données reçues --------------------------------------------------------------- */

    $listesel = 0;
    if (array_key_exists('sige_liste', $_POST))
        $listesel = intval($_POST['sige_liste']);

    $selid = -1;
    $titre = 'Nouvelle équipe';
    if (array_key_exists('sige_selid', $_POST))
        $selid = intval($_POST['sige_selid']);

    $equipe = '';
    if (array_key_exists('sige_equipe', $_POST))
        $equipe = $_POST['sige_equipe'];

    $nom = '';
    if (array_key_exists('sige_nom', $_POST))
        $nom = trim($_POST['sige_nom']);

    $domaine = '';
    if (array_key_exists('sige_domaine', $_POST))
        $domaine = $_POST['sige_domaine'];

    $act = 't';
    if (!array_key_exists('sige_act', $_POST))
        $act = 'f';

    $creer = (array_key_exists('sige_creer', $_POST));
    $modifier = (array_key_exists('sige_modifier', $_POST));
    $supprimer = (array_key_exists('sige_supprimer', $_POST));
    $enregistrer = (array_key_exists('sige_enregistrer', $_POST));

    /* Interprétation ------------------------------------------------------- */

    if ($creer or $modifier) {

        /* Clic sur les boutons Créer ou Modifier */

        $etat_modifier = 'disabled';
        $etat_saisie = true;
        if ($modifier) {
            /* Prêt à modifier */
            if ($listesel < 0) $listesel = 0;
            $selid = $listesel;
            $res = sql_lis_equipes(false, $selid);
            $eq = pg_fetch_assoc($res);
            $titre = "Équipe : Bureau d'étude ".$eq['eqp_nom'];
        } else {
            /* Prêt à créer */
            $selid = -1;
            $eq['eqp_nom'] = '';
            $eq['dom_id'] = '';
            $eq['eqp_ok'] = 't';
            $log_note = '';
        }

        /* domaines */

        $domaines = '<p><label for="sige_domaine">Domaine</label>'
            .'<select name="sige_domaine" size="1">'
            .options(sql_lis_domaines(true), $eq['dom_id'], '--')
            .'</select></p>';

    } else {

        if ($supprimer) {

            /* Suppression (inactivation) d'une équipe */

            $rc = sql_supprime_equipe($listesel);
            if ($rc === false)
                $msg = erreur('La suppression a échoué !');
            else
                $msg = info('Équipe '.($rc == 'I' ? 'inactivée.' : 'supprimée.'));
        }

        $etat_liste = '';
        $etat_creer = '';
        $etat_supprimer = '';

        if ($enregistrer) {

        /* Enregistrement */

            if (strlen($nom) < 2)
                $msg = erreur("Le nom de l'équipe est trop court.");
            elseif ($domaine == '0')
                $msg = erreur("Vous devez attribuer un domaine.");
            elseif (sql_existe_equipe($nom, $selid))
                $msg = erreur("Cette équipe existe déjà.");
            elseif ($selid < 0) {
                /* Création */
                $msg = (sql_ajoute_equipe($nom, '', $domaine, $act) === false ?
                    erreur('Échec de la création !') :
                    info('Équipe '.$nom.' créée.'));
            } else {
                /* Modification */
                $msg = (sql_maj_equipe($selid, $nom, '', $domaine, $act) === false ?
                    erreur('Échec de la modification !') :
                    info("Bureau d'étude : ".$equipe.' modifié.'));
            }
        }
    }

    /* Préparation des champs ------------------------------------------------------------------- */

    /* Liste des équipes */

    $liste = '<select id="sige_liste" name="sige_liste" size="15" '.$etat_liste.'>';
    $res = sql_lis_equipes();
    while ($lu = pg_fetch_assoc($res)) {
        $liste .= option("Bureau d'étude : ".$lu['eqp_nom'],
            $lu['eqp_id'], $listesel, ($lu['eqp_ok'] == 't' ? null : 'color:gray'));
    }
    $liste .= '</select>';

    /* Boutons */

    $boutons = '<p><input type="submit" name="sige_creer" '.$etat_creer.' value="Créer"></p>'
        .'<p><input type="submit" name="sige_modifier" id="sige_modifier" '
            .$etat_modifier.' value="Modifier"></p>'
        .'<p><input type="submit" name="sige_supprimer" id="sige_supprimer" '
            .$etat_supprimer.' value="Supprimer"></p>';

    /* IHM */
    $rc = '<h6 id="h6_adm_eqp">Administration : Gestion des équipes</h6>'
        .$msg
        .'<div id="adm_eqp">'
        .'<form action="" method="POST">'
        .'<input type="hidden" name="activ_adm_eqp">'
        .'<div id="sige_liste_eqp">'.$liste.'</div>'
        .'<div id="sige_boutons">'.$boutons.'</div>';

    if ($etat_saisie) {
        $rc .= '<div id="sige_equipe">'
            .'<fieldset id="sige_saisie">'
            .'<p><span style="font-weight:bold" id="sige_id">'.$titre.'</span>'
            .'<input type="hidden" name="sige_selid" value="'.$selid.'"></p><hr>'
            .($selid == -1 ? '' : '<p><label for="sige_equipe">Nom</label>'
            .'<input type="text" name="sige_equipe" id="sige_equipe" value="'
                .$eq['eqp_nom'].'" readonly maxlength="10"></p>')
            .'<p><label for="sige_nom">Nom</label>'
            .'<input type="text" name="sige_nom" id="sige_nom" value="'.$eq['eqp_nom'].'"></p>'
            .$domaines
            .'<p><label for="sige_act">Actuelle</label>'
            .'<input type="checkbox" name="sige_act" id="sige_act"'
                .($eq['eqp_ok'] == 't' ? ' checked' : '').'><p>'
            .'<hr>'
            .'<p><input type="submit" name="sige_enregistrer" value="Enregistrer">'
            .'<input type="submit" name="sige_annuler" value="Annuler"></p>'
            .'</fieldset>'
            .'</div>';
    }
    $rc .= '</form></div>';

    return $rc;
}

/* ---------------------------------------------------------------------------------------------- */

$admin_si = '<div id="adminsi">'
    .admin_applis()
    .admin_equipes()
    .'</div>';

// fin
