<?php

/* admin_equipes -----------------------------------------------------------------------------------
 * Administration des équipes
 */

	$etat_liste = '';
	$etat_creer = 'disabled';
	$etat_modifier = 'disabled';
	$etat_supprimer = 'disabled';
	$etat_profiler = 'disabled';
	$etat_saisie = false;
	$etat_saisie_profil = false;

	$eq = array();  // Équipe
	$msg = '';      // Message

	/* Lecture des données reçues --------------------------------------------------------------- */

	$listesel = 0;
	if (!empty($_POST['serv_liste'])){
		$listesel = intval($_POST['serv_liste']);
	}

	$selid = 0;
	$titre = 'Nouveau Service';
	if (!empty($_POST['serv_selid'])){
		$selid = intval($_POST['serv_selid']);
	}

	$utid = -1;
	if (!empty($_POST['serv_utilisateur'])){
		$utid= intval($_POST['serv_utilisateur']);
	}
	
	$nom = '';
	if (!empty($_POST['serv_nom'])){
		$nom = trim($_POST['serv_nom']);
	}

	$listeDomaine = array();
	if (!empty($_POST['serv_domaine'])){
		$listeDomaine = $_POST['serv_domaine'];
	}
	
	$esiId = 0;
	if (!empty($_POST['serv_esi'])){
		$esiId= $_POST['serv_esi'];
	}

	/* defini l'action que veut faire l'utilisateur */
	$actionARealiser = '';
	if(array_key_exists('serv_annuler', $_POST)){
		$actionARealiser = 'annuler';
	}elseif(array_key_exists('serv_enregistrer', $_POST)){
		$actionARealiser = 'enregistrer';
	}elseif(array_key_exists('serv_sauvegarder', $_POST)){
		$actionARealiser = 'sauvegarder';
	}elseif (array_key_exists('serv_creer', $_POST)){
		$actionARealiser = 'creer';
	}elseif(array_key_exists('serv_modifier', $_POST)){
		$actionARealiser = 'modifier';
	}elseif(array_key_exists('serv_supprimer', $_POST)){
		$actionARealiser = 'supprimer';
	}elseif(array_key_exists('serv_profiler', $_POST) || array_key_exists('profil', $_POST)){
		$actionARealiser = 'profiler';
	}
	
	/* Interprétation ------------------------------------------------------- */
	switch ($actionARealiser){
		case 'creer':
			/* Prêt à créer */
			$selid = 0;
			$serv['serv_nom'] = '';
			$serv['dom_id'] = '';
			$serv['serv_ok'] = 't';
			$serv['esi_id'] = '';
			$log_note = '';
			$etat_saisie = true;
			$etat_liste = 'disabled';
			break;
		case 'modifier':
			$etat_saisie = true;
			$etat_liste = 'disabled';
			
			/* Prêt à modifier */
			if ($listesel < 0){
				$listesel = 0;
			}
			$selid = $listesel;
			$res = sql_lis_services(false, $selid);
			$serv = pg_fetch_assoc($res);
			$titre = "Service : ".$serv['serv_nom'];
			
			$listeDomaineEnregistrer = array();
			$req = 'SELECT dom_id 
					FROM attacher
					WHERE serv_id=$1'; 
			$param = array($serv['serv_id']);
			$res = pg_query_params($db, $req, $param);
			while ($dom = pg_fetch_assoc($res)){
				$listeDomaineEnregistrer[] = $dom['dom_id'];
			}
			break;
		case 'supprimer':
			$etat_creer = '';
			$etat_modifier = '';
			$etat_supprimer = '';
			$etat_profiler = '';
			
			/* Suppression (inactivation) d'une équipe */
			
			$rc = sql_supprime_service($listesel);
			if ($rc === false){
				$msg = erreur('La suppression a échoué !');
			}else{
				$msg = info('Service '.($rc == 'I' ? 'inactivé.' : 'supprimé.'));
			}
			break;
		case 'profiler':
			$etat_saisie_profil = true;
			
			/* recupère les informations du service dont on veut définir le profil */
			$res = sql_lis_services(false, (empty($selid)?$listesel:$selid));
			$serv = pg_fetch_assoc($res);
			$titre = "Service : ".$serv['serv_nom'];
			
			$listeDomaineAttacher = array();
			$res = sql_lis_domainesService((empty($selid)?$listesel:$selid));
			while ($dom = pg_fetch_assoc($res)){
				$listeDomaineAttacher[$dom['dom_id']]['nom'] = $dom['dom_nom'];
				$listeDomaineAttacher[$dom['dom_id']]['profil'] = $dom['profil'];
			}
			if (!empty($_POST['serv_utilisateur'])){
				$req = 'SELECT uti_nom, uti_prenom
						FROM utilisateurs
						WHERE uti_id=$1';
				$res = pg_query_params($db, $req, array($utid));
				$ut = pg_fetch_assoc($res);
				$titre = "Utilisateur : ".$ut['uti_nom'].' '.$ut['uti_prenom'];
				$res = sql_lis_habilitationUtilisateur($utid);
				while ($habil = pg_fetch_assoc($res)){
					$listeDomaineAttacher[$habil['dom_id']]['profil'] = $habil['habilitation'];
				}
			}
			break;
		case 'enregistrer':
			/* Enregistrement */
			if (strlen($nom) < 2){
				$msg = erreur("Le nom du service est trop court.");
			}elseif (count($listeDomaine) == 0){
				$msg = erreur("Vous devez attribuer au moins un domaine.");
			}elseif (sql_existe_service($nom, $selid)){
				$msg = erreur("Ce service existe déjà.");
			}elseif ($selid == 0) {
				/* Création */
				$insert = TRUE;
				// ajout du service
				$req = 'INSERT INTO services 
							(serv_nom, esi_id)
						VALUES
							($1,$2)';
				$param = array($nom,$esiId);
				$res = pg_query_params($db, $req, $param);
				if ($res === false){
					$insert = false;
				}
				// recupère l'id du service ajouté
				$req = "SELECT currval('services_serv_id_seq') AS lastinsertid;";
				$res = pg_query($db,$req);
				$lu = pg_fetch_assoc($res);
				$idService = $lu['lastinsertid'];
				// ajout du rattachement du service aux domaines
				foreach ($listeDomaine as $idDomaine){
					$req = 'INSERT INTO attacher
								(serv_id, dom_id)
							VALUES
								($1,$2)';
					$param = array($idService,$idDomaine);
					$res = pg_query_params($db, $req, $param);
					if ($res === false){
						$insert = false;
						break;
					}
				}
				$msg = ($insert?info('Service : '.$nom.' créé.'):erreur('Échec de la création !'));
			} else {
				/* Modification */
				$maj = TRUE;
				// ajout du service
				$req = 'UPDATE services SET
						serv_nom=$2,
						esi_id=$3
						WHERE serv_id=$1';
				$param = array($selid,$nom,$esiId);
				$res = pg_query_params($db, $req, $param);
				if ($res === false){
					$maj= false;
				}
				// recupère la liste des domaines déjà rattacher
				$listeDomaineEnregistrer = array();
				$req = 'SELECT dom_id
						FROM attacher
						WHERE serv_id=$1';
				$param = array($selid);
				$res = pg_query_params($db, $req, $param);
				while ($dom = pg_fetch_assoc($res)){
					$listeDomaineEnregistrer[] = $dom['dom_id'];
				}
				// ajout du rattachement du service aux domaines
				$listeDesNouveauxDomaines = array();
				foreach ($listeDomaine as $idDomaine){
					if (!in_array($idDomaine, $listeDomaineEnregistrer)){
						$listeDesNouveauxDomaines[] = $idDomaine;
						$req = 'INSERT INTO attacher
									(serv_id, dom_id)
								VALUES
									($1,$2)';
						$param = array($selid,$idDomaine);
						$res = pg_query_params($db, $req, $param);
						if ($res === false){
							$maj= false;
							break;
						}
					}
				}
				// calcul des domaines à détacher
				$listeDomaineASupprimer = array_diff($listeDomaineEnregistrer,$listeDomaine);
				// supprime l'attchement service<->domaine
				foreach ($listeDomaineASupprimer as $idDomaine){
					$req = 'DELETE FROM attacher
							WHERE dom_id=$2
							AND serv_id=$1';
					$param = array($selid,$idDomaine);
					$res = pg_query_params($db, $req, $param);
					if ($res === false){
						$maj= false;
						break;
					}
				}
				
				$msg = ($maj?info('Service : '.$nom.' modifié.'):erreur('Échec de la modification !'));
			}
			$etat_creer = '';
			$etat_modifier = '';
			$etat_supprimer = '';
			$etat_profiler = '';
			
			break;
		case 'sauvegarder':
			/* enregistre le profil d'un service ou les habilitations particulières d'un utilisateur */
			$valeurProfil = array();
			foreach($_POST as $inputName => $value){
				if (preg_match('/^profil_(?P<domaine>\w+)_(?P<habil>\w+)$/',$inputName,$matches)){
					if (empty($valeurProfil[$matches['domaine']])){
						$valeurProfil[$matches['domaine']] = 0;
					}
					switch ($matches['habil']){
						case 'gestionDate':
							$valeurProfil[$matches['domaine']] = $valeurProfil[$matches['domaine']] + HABIL_GESTION_DATE;
							break;
						case 'referentiel':
							$valeurProfil[$matches['domaine']] = $valeurProfil[$matches['domaine']] + HABIL_REFERENTIEL_BE;
							break;
						case 'realiseManuel':
							$valeurProfil[$matches['domaine']] = $valeurProfil[$matches['domaine']] + HABIL_REALISE_MANUEL;
							break;
					}
				}
			}
			$maj = TRUE;
			if ($utid <= 0){
				sql_delete_profil($selid);
			}else{
				sql_delete_habilitation($utid);
			}
			foreach ($valeurProfil as $idDomaine => $valeur){
				if ($utid <= 0){
					$maj = (sql_maj_profil($selid, $idDomaine, $valeur) === false ?FALSE:TRUE);
				}else{
					$maj = (sql_maj_habilitation($utid, $idDomaine, $valeur) === false ?FALSE:TRUE);
				}
			}
			if ($maj){
				$msg = info('Profil mis à jour avec succès.');
				
				$etat_saisie = false;
				$etat_modifier = 'disabled';
				$etat_saisie_profil = true;
				
				$res = sql_lis_services(false, (empty($selid)?$listesel:$selid));
				$serv = pg_fetch_assoc($res);
				$titre = "Service : ".$serv['serv_nom'];
				
				$listeDomaineAttacher = array();
				$res = sql_lis_domainesService((empty($selid)?$listesel:$selid));
				while ($dom = pg_fetch_assoc($res)){
					$listeDomaineAttacher[$dom['dom_id']]['nom'] = $dom['dom_nom'];
					$listeDomaineAttacher[$dom['dom_id']]['profil'] = $dom['profil'];
				}
				$utid = -1;
			}else{
				$msg = erreur('Échec de la modification !');
			}
			break;
		case 'annuler':
			$etat_saisie = false;
			$etat_saisie_profil = false;
		default:
			$etat_liste = '';
			$etat_creer = '';
			$etat_modifier = '';
			$etat_supprimer = '';
			$etat_profiler = '';
			break;
	}
?>
<h6 id="h6_admin_service">Administration : Gestion des services</h6>
<?php echo $msg;?>
<div id="admin_service" class="moduleAdmin">
	<form id="form_service" action="" method="POST" onSubmit="return verifConfirmationService();">
		<input type="hidden" name="module" value="admin_service" />
		<div id="serv_liste_service">
			<select id="serv_liste" name="serv_liste" size="15" <?php echo $etat_liste;?>>
			<?php
				$req = 'SELECT serv_id, serv_nom, serv_ok
						FROM services
						ORDER BY serv_nom';
				$res = pg_query($db, $req);
				while ($lu = pg_fetch_assoc($res)){
					echo option($lu['serv_nom'],$lu['serv_id'], (empty($selid)?$listesel:$selid), ($lu['serv_ok'] == 't' ? null : 'color:gray'));
				}
			?>
			</select>
		</div>
		<div id="sige_boutons">
			<p><input type="submit" id="serv_creer" name="serv_creer" <?php echo $etat_creer;?> value="Créer"></p>
			<p><input type="submit" id="serv_modifier" name="serv_modifier" <?php echo $etat_modifier;?> value="Modifier"></p>
			<p><input type="submit" id="serv_supprimer" name="serv_supprimer" <?php echo $etat_supprimer;?> value="Supprimer" onClick="confirmationService()"></p>
			<p><input type="submit" id="serv_profiler" name="serv_profiler" <?php echo $etat_profiler;?> value="Profil"></p>
		</div>
<?php
	if ($etat_saisie) {
?>
		<div id="serv_equipe">
			<fieldset id="serv_saisie">
				<span style="font-weight:bold" id="serv_id"><?php echo $titre;?></span>
				<input type="hidden" name="serv_selid" value="<?php echo $selid;?>">
				<hr/>
				<p>
					<label for="serv_nom">Nom</label>
					<input type="text" name="serv_nom" id="serv_nom" value="<?php echo $serv['serv_nom'];?>">
				</p>
				<p>
					<label for="serv_domaine">Domaine</label>
					<select name="serv_domaine[]" id="serv_domaine" multiple>
					<?php
						$req = 'SELECT dom_id, dom_nom
								FROM domaines
								WHERE dom_ok
								ORDER BY dom_nom';
						$res = pg_query($db,$req);
						while ($lu = pg_fetch_assoc($res)) {
							$selected='';
							if (in_array($lu['dom_id'],$listeDomaineEnregistrer)){
								$selected='selected';
							}
							echo '<option value="'.$lu['dom_id'].'" '.$selected.'>'.$lu['dom_nom'].'</option>';
						}
					?>
					</select>
				<p>
				<p>
					<label for="serv_esi">Exploitant</label>
					<select name="serv_esi" id="serv_esi">
						<option value="0">-----</option>
					<?php
						$req = 'SELECT esi_id, esi_nom
								FROM esi
								WHERE esi_ok
								ORDER BY esi_nom';
						$res = pg_query($db,$req);
						while ($lu = pg_fetch_assoc($res)) {
							$selected='';
							if ($lu['esi_id']==$serv['esi_id']){
								$selected='selected';
							}
							echo '<option value="'.$lu['esi_id'].'" '.$selected.'>'.$lu['esi_nom'].'</option>';
						}
					?>
					</select>
				<p>
				<hr />
				<p>
					<input type="submit" name="serv_enregistrer" value="Enregistrer">
					<input type="submit" name="serv_annuler" value="Annuler">
				</p>
			</fieldset>
		</div>
<?php
	}
	if ($etat_saisie_profil){
?>
		<input type="hidden" name="profil" value="1" />
		<input type="hidden" name="serv_selid" value="<?php echo (empty($selid)?$listesel:$selid);?>">
		<div id="serv_profil">
			<h4><?php echo $titre;?></h4><hr/>
			<div id="block_utilisateur">
				<select id="serv_utilisateur" name="serv_utilisateur" size="20" onChange="profilUtilisateur()">
				<?php
				$req = 'SELECT uti_id, uti_nom, uti_prenom, uti_ok
						FROM utilisateurs
						WHERE serv_id=$1';
				$param = array((empty($selid)?$listesel:$selid));
				$res = pg_query_params($db, $req, $param);
					while ($lu = pg_fetch_assoc($res)){
						echo option($lu['uti_nom'].' '.$lu['uti_prenom'],$lu['uti_id'], $utid, ($lu['uti_ok'] == 't' ? null : 'color:grey;'));
					}
				?>
				</select>
			</div>
			<div id="block_profil">
				<h5>Habilitations par domaine</h5>
				<fieldset>
					<h3>Générique</h3>
					<table>
						<tr>
							<td>Visualisation</td>
							<td class="validProfil"><input type="checkbox" checked disabled/></td>
						</tr>
						<tr>
							<td>Personnalisation</td>
							<td class="validProfil"><input type="checkbox" checked disabled/></td>
						</tr>
					</table>
	<?php
				foreach ($listeDomaineAttacher as $idDomaine => $domaine){
	?>			
					<h3><?php echo $domaine['nom'];?></h3>
					<hr />
					<table>
						<tr>
							<th colspan="2">Prévisionnel</th>
						</tr>
						<tr>
							<td>Gestion des dates</td>
							<td class="validProfil"><input type="checkbox" name="profil_<?php echo $idDomaine;?>_gestionDate" <?php echo (((HABIL_GESTION_DATE & $domaine['profil'])==HABIL_GESTION_DATE)?'checked':'');?>/></td>
						</tr>
						<tr>
							<td>Référentiel BE</td>
							<td class="validProfil"><input type="checkbox" name="profil_<?php echo $idDomaine;?>_referentiel" <?php echo (((HABIL_REFERENTIEL_BE & $domaine['profil'])==HABIL_REFERENTIEL_BE)?'checked':'');?>/></td>
						</tr>
						<tr>
							<th colspan="2">Réalisé</th>
						</tr>
						<tr>
							<td>Réalisé Manuel</td>
							<td class="validProfil"><input type="checkbox" name="profil_<?php echo $idDomaine;?>_realiseManuel" <?php echo (((HABIL_REALISE_MANUEL & $domaine['profil'])==HABIL_REALISE_MANUEL)?'checked':'');?>/></td>
						</tr>
					</table>
	<?php			
				}
	?>
					<hr />
					<p>
						<input type="submit" name="serv_sauvegarder" value="Enregistrer">
						<input type="submit" name="serv_annuler" value="Annuler">
					</p>
				</fieldset>
			</div>
		</div>
<?php	
	}
?>
	</form>
</div>
<script>
	var demandeConfirmationService = false;
	function confirmationService(){
		demandeConfirmationService = true;
	}
	function verifConfirmationService(){
		if (demandeConfirmationService == true){
			if (confirm('Êtes vous sûr de vouloir supprimer ce service ?')){
				return true;
			}else{
				demandeConfirmationService = false;
				return false;
			}
		}else{
			return true;
		}
	}
	function profilUtilisateur(){
		var formulaire = document.getElementById('form_service');

		formulaire.onSubmit = function(){
			return true;
		}

		formulaire.submit();
	}
</script>