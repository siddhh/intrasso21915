<div id="logo">
	<p>Exploitations Fiscales</p>
	<a href="index.php"><img src="img/fp_logo_h.png" alt="DGFiP SI2A-DME"></a>
</div>
<?php
	if ($erreur==0){
?>
		<div id="menu">
			<fieldset><legend> Suivi </legend>
				<ul>
					<li><a href="index.php?page=prevision" <?php echo (((getPost('page')=='prevision') || (getPost('page')==''))?'class="selection"':'');?>>Prévisionnel</a></li>
					<li><a href="index.php?page=realise" <?php echo (getPost('page')=='realise'?'class="selection"':'');?>>Réalisé</a></li>
				</ul>
			</fieldset>
			<fieldset><legend> Outils </legend>
				<ul>
					<li><a href="index.php?page=recherche" <?php echo (getPost('page')=='recherche'?'class="selection"':'');?>>Recherche</a></li>
<?php
				if ($cmd_ges_disabled){
					$lienGestionDate = '';
					$classGestionDate = 'class="inactif"';
				}else{
					$lienGestionDate = 'index.php?page=dates';
					$classGestionDate = (getPost('page')=='dates'?'class="selection"':'');
				}
?>
					<li><a href="<?php echo $lienGestionDate;?>" <?php echo $classGestionDate;?>>Gestion des dates</a></li>
<?php
				if ($cmd_ref_disabled){
					$lienReferentiel = '';
					$classReferentiel = 'class="inactif"';
				}else{
					$lienReferentiel= 'extraction.php';
					$classReferentiel= '';
				}
?>
					<li><a href="<?php echo $lienReferentiel;?>" <?php echo $classReferentiel;?>>Référentiel BE</a></li>
					<li><a href="lo/navette.ods" target="_blank">Fiche navette</a></li>
				</ul>
			</fieldset>
			<fieldset><legend> Aide </legend>
				<ul>
					<li><a href="http://esi44m.intranet.dgfip/outils/qualification/exploitation/calendrier/selection.php">Calendrier Paliers</a></li>
					<li><a href="doc/GuideSPPE.pdf" target="_blank">Documentation</a></li>
					<li><a href="index.php?page=aide">Aide</a></li>
				</ul>
			</fieldset>
		<?php
			if (isset($_SESSION) && array_key_exists('uti_id', $_SESSION) && ($_SESSION['uti_id'] != '0')) {
		?>
				<p id="nouveau"><a href="index.php?page=nouveaute&force_affichage=OUI" <?php echo (getPost('page')=='nouveaute'?'class="selection"':'');?>>Nouveautés</a></p>
		<?php
			}
		?>
			<p id="version"><?php echo VERSION;?></p>
		</div>
<?php
	}
?>