<?php

    /* Couleurs par défaut */

    define('SPPE_DEF_CALCULE',      '#cccccc');     // gris clair
    define('SPPE_DEF_MANUEL',       '#a56bc8');     // violet
    define('SPPE_DEF_TERMINE',      '#679500');     // vert
    define('SPPE_DEF_EN_COURS',     '#1e90ff');     // bleu
    define('SPPE_DEF_EN_ABORT',     '#c00c13');     // rouge
    define('SPPE_DEF_HORS_DELAI_APRES',   '#000000');     // noir
    define('SPPE_DEF_HORS_DELAI_AVANT',   '#E87309');     // orange
    define('SPPE_DEF_FERIE',        '#f9e7c7');     // beige
    define('SPPE_DEF_SANS_OBJET',   '#ffffff');     //'#F3FFF3');     // vert très pâle

    /* États des jobs en réalisé */
    define('SPPE_SANS_OBJET',   '0');   // sans objet
    define('SPPE_ETAT_PREVU',   'W');   // en attente de traitement, planifié
    define('SPPE_ETAT_ABORT',   'A');   // planté
    define('SPPE_ETAT_TERMINE', 'T');   // terminé sans erreur
    define('SPPE_ETAT_EXEC',    'X');   // en cours d'exécution
?>
