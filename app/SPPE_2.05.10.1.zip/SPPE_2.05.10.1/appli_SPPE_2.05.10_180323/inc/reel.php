<?php

	/* Saisie manuelle du réalisé */

	$pln_id = getPost('pln_id');
	if ((strlen($pln_id) > 0) && ctype_digit($pln_id)) {

		/* Lecture du plan */

		$req = 'SELECT p.pro_nom, p.pro_lib, q.*, u.uti_nom, u.uti_prenom, r.rea_debut, r.rea_fin, r.rea_statut, r.rea_notes
				FROM plan q
				JOIN processus p ON p.pro_id=q.pro_id
				LEFT OUTER JOIN realise r ON r.pln_id=q.pln_id AND r.esi_id=$2
				LEFT OUTER JOIN utilisateurs u ON u.uti_id=q.uti_id
				WHERE q.pln_id=$1';
		$res = pg_query_params($db, $req, array($pln_id, $_SESSION['esi_id']));

		if (pg_num_rows($res)) {
			$lu = pg_fetch_assoc($res);
			$abort = ($lu['rea_statut'] == 'A' ? ' checked' : '');
			$saisie_realise = '<div id="realise">'
							.'		<div id="realise_entete">'
							.'			<p>'
							.'				&bull; Processus : <strong>'.$lu['pro_nom'].'</strong>'
							.'				&bull; <em>'.$lu['pro_lib'].'</em>'
							.'			</p>'
							.			dates_previsionnelles($lu)
							.'		</div>'
							.'	<form action="index.php" name="frm_realise" id="frm_realise" method="POST">'
							.'		<input type="hidden" name="page" value="realise" />'
							.'		<input type="hidden" id="hreel_pln_id" name="hreel_pln_id" value="'.$pln_id.'">'
							.'		<input type="hidden" id="hreel_debut" name="hreel_debut" value="'.$lu['rea_debut'].'">'
							.'		<input type="hidden" id="hreel_fin" name="hreel_fin" value="'.$lu['rea_fin'].'">'
							.'		<input type="hidden" id="pln_debut" name="pln_debut" value="'.$lu['pln_debut'].'">'
							.'		<div id="saisie_realise">'	
							.'			<div id="saisie_notes_realise">'
							.'				<label data-for="reel_notes">Notes</label>'
							.'				<textarea rows="3" cols="40" name="reel_notes" id="reel_notes">'.$lu['rea_notes'].'</textarea>'
							.'			</div>'
							.'			<div id="saisie_dates_realise">'
							.'				<p>'
							.'					<label for="reel_debut">Début réel</label>'
							.'					<img src="img/calendar.gif" id="reel_debut_cal">'
							.'					<input type="text" name="reel_debut" id="reel_debut" value="'.jma($lu['rea_debut']).'" size="10" maxlength="10" />'
							.'					<img src="img/efface.gif" id="reel_debut_eff">'
							.'				</p>'
							.'				<p>'
							.'					<label data-for="reel_fin">Fin réelle</label>'
							.'					<img src="img/calendar.gif" id="reel_fin_cal">'
							.'					<input type="text" name="reel_fin" id="reel_fin" value="'.jma($lu['rea_fin']).'" size="10" maxlength="10">'
							.'					<img src="img/efface.gif" id="reel_fin_eff">'
							.'				</p>'
							.'			</div>'
							.'			<div id="saisie_abort_realise">'
							.'				<p><label data-for="reel_abort">Abort</label></p>'
							.'				<p><input type="checkbox" name="reel_abort" id="reel_abort"'.$abort.'></p>'
							.'			</div>'
							.'			<div id="saisie_cmd_realise">'
							.'				<p><input type="submit" name="cmd_sais_reel" id="cmd_sais_reel" value="Enregistrer"></p>'
							.'				<p><input type="submit" name="cmd_sais_annule" value="Annuler"></p>'
							.'			</div>'
							.'			<div id="saisie_suppr_rest_realise">'
							.'				<p>'
							.'					<input type="submit" name="cmd_sais_suppr_rea" id="cmd_sais_suppr_rea" value="Supprimer le réalisé">'
							.'					<input type="submit" name="cmd_sais_rest_rea" value="Restaurer le réalisé">'
							.'				</p>'
							.'			</div>'
							.'		</div>'
							.'	</form>'
							.'</div>';
		}
	}
?>
