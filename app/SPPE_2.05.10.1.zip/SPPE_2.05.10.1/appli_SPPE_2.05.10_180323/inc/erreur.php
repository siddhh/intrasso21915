<?php

    /* Affichage des erreurs */

    $err_msg = array(
        1 => "Appel incorrect de l'application SPPE",
        2 => "Échec de la connexion à la base de données SPPE",
    	3 => "Utilisateur inconnu de SPPE",
    	4 => "Utilisateur inconnu de l'annuaire LDAP DGFiP"
    );

	if ($erreur!=3){
?>
	<div id="erreur">
    	<p><?php echo $err_msg[$erreur];?></p>
    </div>
<?php
	}elseif($erreur==3){
?>
	<div id="erreur_utilisateur">
		<fieldset><legend><?php echo $err_msg[$erreur];?></legend>
			<div id="message_erreur">
				<p>
					Vous n'avez pas les habilitations nécessaires pour accéder à cette application
					<br/>
					sauf en consultation (voir les modalités ci-dessous pour obtenir une habilitation).
				</p>
			</div>
			<hr />
			<div id="modalite_habilitation">
				<p>Les comptes utilisateurs sont fournis par le Bureau SI-2A DME.</p>
				<p>Pour obtenir un compte utilisateur, merci d'adresser votre demande, par la voie hiérarchique, à l'adresse suivante :</p>
				<p id="message_mail"><a href="mailto:bureau.si2a-dme-soae@dgfip.finances.gouv.fr">bureau.si2a-dme-soae@dgfip.finances.gouv.fr</a></p>
				<p>Le mode consultation est accessible à tous.</p>
			</div>
			<div id="message_redirection">
				<p>
					Vous allez être redirigé dans quelques instants vers la version en consultation de SPPE.
					<br/>
					Merci de patienter.
				</p>
			</div>
		</fieldset>
	</div>
	<script>
		setTimeout(function(){
			window.location.href='<?php echo URL_PUBLIQUE.'/index.php';?>';
		},15000);
	</script>
<?php	
	}
?>