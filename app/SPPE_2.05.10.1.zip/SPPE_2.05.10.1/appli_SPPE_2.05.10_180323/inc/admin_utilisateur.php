<?php
	/* SPPE : Gestion des utilisateurs */

	$curid = $_SESSION['uti_id'];

	$etat_liste = 'disabled';
	$etat_creer = 'disabled';
	$etat_modifier = '';
	$etat_supprimer = 'disabled';
	$etat_saisie = false;

	$ut = array();  // Utilisateur créé ou modifié
	$msg = '';      // Message
	$habilitations = '';

	/* Lecture des données reçues --------------------------------------------------------------- */

	$listesel = $curid;
	if (array_key_exists('listeUtilisateur', $_POST)){
		$listesel = intval($_POST['listeUtilisateur']);
	}

	$selid = -1;
	if (array_key_exists('selid', $_POST)){
		$selid = intval($_POST['selid']);
	}
	
	$uidFonctionnel = '';
	if (array_key_exists('uidFonctionnel', $_POST)){
		$uidFonctionnel= strtolower(trim($_POST['uidFonctionnel']));
		$ut['uti_uid_fonctionnel'] = $uidFonctionnel;
	}

	$nom = '';
	if (array_key_exists('nomUtilisateur', $_POST)){
		$nom = trim($_POST['nomUtilisateur']);
		$ut['uti_nom'] = $nom;
	}

	$prenom = '';
	if (array_key_exists('prenomUtilisateur', $_POST)){
		$prenom = trim($_POST['prenomUtilisateur']);
		$ut['uti_prenom'] = $prenom;
	}

	$estAdmin = 'f';
	if (array_key_exists('utilisateurAdmin', $_POST)){
		$estAdmin = 't';
		$ut['uti_admin'] = $estAdmin;
	}
	
	$servId = 0;
	if (array_key_exists('service', $_POST)){
		$servId= $_POST['service'];
		$ut['serv_id'] = $servId;
	}

	$creer = (array_key_exists('creer', $_POST));
	$modifier = (array_key_exists('modifier', $_POST));
	$supprimer = (array_key_exists('supprimer', $_POST));
	$enregistrer = (array_key_exists('enregistrer', $_POST));

	/* Interprétation ------------------------------------------------------- */

	if($creer || $modifier){

		/* Clic sur les boutons Créer ou Modifier */
		$etat_modifier = 'disabled';
		$etat_saisie = true;
		if($modifier){
			/* Prêt à modifier */
			if ($listesel < 0){
				$listesel = $curid;
			}
			$selid = $listesel;
			$req = "SELECT *
					FROM utilisateurs
					WHERE uti_id=$1";
			$res = pg_query_params($db, $req, array($selid));
			$ut = pg_fetch_assoc($res);
		}else{
			/* Prêt à créer */
			$selid = -1;
			$ut['uti_uid_fonctionnel'] = '';
			$ut['uti_nom'] = '';
			$ut['uti_prenom'] = '';
			$ut['uti_admin'] = 'f';
			$ut['uti_serv_id'] = 0;
			$log_note = '';
		}
	}else{
		if ($supprimer) {
			/* Suppression d'un compte */
			if($listesel== $curid){
				$msg = erreur('Vous ne pouvez pas supprimer votre propre compte.');
			}else{
				$req = 'SELECT
							(SELECT COUNT(*) FROM plan WHERE uti_id=$1)
                        +
							(SELECT COUNT(*) FROM realise WHERE uti_id=$1)';
				$res = pg_query_params($db, $req, array($listesel));
				$lu = pg_fetch_row($res);
				if ($lu[0] > 0) {
					$msg = erreur('Impossible de supprimer un compte qui a déjà servi.');
				} else {
					$req = 'DELETE FROM utilisateurs WHERE uti_id=$1';
					$res = pg_query_params($db, $req, array($listesel));
					
					$msg = ($res === false ?erreur('La suppression a échoué !') :info('Suppression réalisée.'));
				}
			}
		}

		$etat_liste = '';
		$etat_creer = '';
		$etat_supprimer = '';

		if($enregistrer){
			$etat_saisie = true;
			/* Enregistrement */
			if($selid < 0){
				/* Création */
				if(strlen($nom) == 0){
					$msg = erreur('Le nom de l\'utilisateur ne peut être vide.');
				}elseif(strlen($prenom) == 0){
					$msg = erreur('Le prénom de l\'utilisateur ne peut être vide.');
				}elseif(strlen($uidFonctionnel) == 0){
					$msg = erreur('L\identifiant fonctionnel de l\'utilisateur ne peut être vide.');
				}elseif($servId == 0){
					$msg = erreur('Le service de l\'utilisateur ne peut être vide.');
				}else{
					$req = 'SELECT count(*) FROM utilisateurs WHERE uti_uid_fonctionnel ILIKE $1';
					$res = pg_query_params($db, $req, array($uidFonctionnel));
					$lu = pg_fetch_row($res);
					if($lu[0] > 0){
						$msg = erreur('Ce compte utilisateur existe déjà.');
					}else{
						if (!validationUidFonctionnel($uidFonctionnel)){
							$msg = erreur('L\'identifiant fonctionnel de l\'utilisateur est inconnu de l\'annuaire LDAP DGFiP.');
						}else{
							$req = "SELECT esi_id FROM services WHERE serv_id=$1";
							$res = pg_query_params($db, $req, array($servId));
							$esi = pg_fetch_assoc($res);
							if ($esi['esi_id']==0){
								$esi['esi_id']=NULL;
							}
							$req = 'INSERT INTO utilisateurs
										(uti_uid_fonctionnel, uti_nom, uti_prenom, esi_id, serv_id, uti_admin)
									VALUES
										($1,$2,$3,$4,$5,$6)';
							$param = array($uidFonctionnel, $nom, $prenom, $esi['esi_id'], $servId, $estAdmin);
							$res = pg_query_params($db, $req, $param);
							$msg = ($res === false ?erreur('Échec de la création !') :info('Utilisateur '.$prenom.' '.$nom.' créé.'));
						}
					}
				}
			}else{
				/* Modification */
				if(strlen($nom) == 0){
					$msg = erreur('Le nom de l\'utilisateur ne peut être vide.');
				}elseif(strlen($prenom) == 0){
					$msg = erreur('Le prénom de l\'utilisateur ne peut être vide.');
				}elseif(strlen($uidFonctionnel) == 0){
					$msg = erreur('L\identifiant fonctionnel de l\'utilisateur ne peut être vide.');
				}elseif($servId == 0){
					$msg = erreur('Le service de l\'utilisateur ne peut être vide.');
				}else{
					if (!validationUidFonctionnel($uidFonctionnel)){
						$msg = erreur('L\'identifiant fonctionnel de l\'utilisateur est inconnu de l\'annuaire LDAP DGFiP.');
					}else{
						$req = "SELECT esi_id FROM services WHERE serv_id=$1";
						$res = pg_query_params($db, $req, array($servId));
						$esi = pg_fetch_assoc($res);
						if ($esi['esi_id']==0){
							$esi['esi_id']=NULL;
						}
						$req = 'UPDATE utilisateurs SET
								uti_uid_fonctionnel=$2,
								uti_nom=$3,
								uti_prenom=$4,
								esi_id=$5,
								serv_id=$6,
								uti_admin=$7
								WHERE uti_id=$1';
						$param = array($selid,$uidFonctionnel, $nom, $prenom, $esi['esi_id'], $servId, $estAdmin);
						$res = pg_query_params($db, $req, $param);
						$msg = ($res === false ?erreur('Échec de la modification !') :info('Utilisateur '.$prenom.' '.$nom.' modifié.'));
					}
				}
			}
		}
	}

	/* Liste des utilisateurs (sauf l'automate) */
	$reqUtilisateurs = "SELECT uti_id, uti_nom, uti_prenom, uti_ok
						FROM utilisateurs
						WHERE uti_uid_fonctionnel!='automate'
						ORDER BY uti_nom, uti_prenom";
	$resUtilisateurs = pg_query($db,$reqUtilisateurs);
	$titre = ((!empty($ut['uti_prenom'])&&!empty($ut['uti_nom']))?'Utilisateur : '.$ut['uti_prenom'].' '.$ut['uti_nom']:'Nouvel Utilisateur');
?>
<h6 id="h6_admin_users">Administration : Gestion des utilisateurs</h6>
<?php echo $msg;?>
<div id="admin_users" class="moduleAdmin">
	<form action="" method="POST" onSubmit="return verifConfirmationUtilisateur();">
		<input type="hidden" name="module" value="admin_users" />
		<div id="adm_liste">
			<select id="listeUtilisateur" name="listeUtilisateur" size="15" <?php echo $etat_liste;?>>
		<?php
			while ($utilisateur = pg_fetch_assoc($resUtilisateurs)){
				echo option($utilisateur['uti_nom'].' '.$utilisateur['uti_prenom'],$utilisateur['uti_id'],$listesel,($utilisateur['uti_ok'] == 't' ? null : 'color:grey;'));
			}
		?>
			</select>
		</div>
		<div id="adm_boutons">
			<p><input type="submit" name="creer" value="Créer" <?php echo $etat_creer;?> /></p>
	    	<p><input type="submit" name="modifier" value="Modifier" <?php echo $etat_modifier;?> /></p>
	    	<p><input type="submit" name="supprimer" value="Supprimer" <?php echo $etat_supprimer;?> onClick="confirmationUtilisateur()"/></p>
		</div>
		<?php 
		if ($etat_saisie) {
		?>
			<div id="adm_utilisateur">
				<fieldset id="adm_saisie">
					<span style="font-weight:bold" id="uti_id"><?php echo $titre; ?></span>
					<input type="hidden" name="selid" value="<?php echo $selid; ?>" />
					<hr/>
					<label for="uidFonctionnel" title="Partie gauche de l'adresse mail">Identifiant fonctionnel</label>
					<input type="text" name="uidFonctionnel" id="uidFonctionnel" value="<?php echo $ut['uti_uid_fonctionnel'];?>" style="width:250px;cursor:help;"  title="Partie gauche de l'adresse mail" />
					<br/>
					<label for="nomUtilisateur">Nom de l'utilisateur</label>
					<input type="text" name="nomUtilisateur" id="nomUtilisateur" value="<?php echo (empty($ut['uti_nom'])?'':$ut['uti_nom']);?>" style="width:250px;" /><br/>
					<label for="prenomUtilisateur">Prénom de l'utilisateur</label>
					<input type="text" name="prenomUtilisateur" id="prenomUtilisateur" value="<?php echo (empty($ut['uti_prenom'])?'':$ut['uti_prenom']);?>" style="width:250px;" /><br/>
					<label for="service">Service</label>
					<select id="service" name="service">
						<option value="0"></option>
					<?php
						$res = sql_lis_services(true);
						while ($lu = pg_fetch_assoc($res)){
							echo option($lu['serv_nom'],$lu['serv_id'], $ut['serv_id']);
						}
					?>
					</select>
					<hr/>
					<label for="utilisateurAdmin">Administrateur SPPE</label>
					<input type="checkbox" id="utilisateurAdmin" name="utilisateurAdmin" <?php echo ((isset($ut['uti_admin']) && ($ut['uti_admin']=='t'))?'checked':'');?>/>
					<hr/>
					<p>
						<input type="submit" name="enregistrer" value="Enregistrer">
						<input type="submit" name="annuler" value="Annuler">
					</p>
				</fieldset>
			</div>
		<?php 
		}
		?>
	</form>
</div>
<script>
	var demandeConfirmationUtilisateur = false;
	function confirmationUtilisateur(){
		demandeConfirmationUtilisateur = true;
	}
	function verifConfirmationUtilisateur(){
		if (demandeConfirmationUtilisateur == true){
			if (confirm('Êtes vous sûr de vouloir supprimer cet utilisateur ?')){
				return true;
			}else{
				demandeConfirmationUtilisateur = false;
				return false;
			}
		}else{
			return true;
		}
	}
</script>
<?php
function validationUidFonctionnel($uidFonctionnel){
	require 'class.ldap.php';
	$trouve = false;
	
	$ldap = new LDAP();
	$dn = 'ou=dgfip,ou=mefi,o=gouv,c=fr';
	$filtre='(|(uidFonctionnel='.$uidFonctionnel.'))';
	if ($ldap->search($filtre)){
		while($entry = $ldap->fetch()){
			$trouve = true;
			break;
		}
	}
	return $trouve;
}
?>