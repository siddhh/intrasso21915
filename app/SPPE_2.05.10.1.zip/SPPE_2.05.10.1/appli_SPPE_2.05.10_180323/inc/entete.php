<div id="titre">
	<h1><a href="index.php">SPPE</a> <?php echo $serveur;?></h1>
	<h2>Suivi du Plan de Production des Exploitations</h2>
</div>
<?php
if ($erreur == 0){
?>
	<div id="utilisateur">
	<?php
		if (!MODE_CONNECTE){
	?>
			<a id="connexion" href="<?php echo URL_SECURE.$_SERVER['PHP_SELF'];?>" target="_self" title="Se connecter à SPPE">
				Connexion
				<img src="img/login.png"/>
			</a>
	<?php
		}else{
			$lienAdministration = '';
			if (isset($_SESSION) && array_key_exists('uti_id', $_SESSION) && intval($_SESSION['uti_id']) > 0){
				$lienAdministration = '?page=admin';
			}
			if (strpos($_SERVER['REQUEST_URI'], '?') === false){
				$lienEnregistrementPreferences = 'index.php?cmd_enr';
			}else{
				$lienEnregistrementPreferences = $_SERVER['REQUEST_URI'].'&cmd_enr';
			}
	?>
			<a id="connexion" href="index.php<?php echo $lienAdministration;?>" title="Administration de vos préférences utilisateur">
				<?php echo $_SESSION['uti_prenom'].' '.$_SESSION['uti_nom'];?>
			</a>
			<a id="cmd_enr" href="<?php echo $lienEnregistrementPreferences;?>" title="Enregistrement de vos préférences utilisateur"></a>
	<?php
		}
	?>
	</div>
	<div id="selections">
		<div id="conteneur-filtres">
			<fieldset id="filtres" style="display:none;"><legend> Filtres </legend>
				<form action="index.php" name="sppe_titre" method="GET">
					<input type="hidden" name="page" value="<?php echo getPost('page');?>" />
					<p>
						<label for="sel_dom">Domaine</label>
						<select name="sel_dom" id="sel_dom" size="1" class="court">
							<?php echo $sdom;?>
						</select>
						<label for="sel_esi" class="court">ESI</label>
						<select name="sel_esi" id="sel_esi" size="1">
							<?php echo $sesi;?>
						</select>
						<span id="suivi_simplif">
							<label for="sel_sui">Afficher suivi simplifié</label>
							<input type="checkbox" name="sel_sui" id="sel_sui" <?php echo $ssui;?>>
						</span>
						<span id="a_venir">
							<label for="sel_ave">Afficher travaux à venir</label>
							<input type="checkbox" name="sel_ave" id="sel_ave" <?php echo $save;?>>
						</span>
					</p>
					<p>
						<label for="sel_app">Equi./appli</label>
						<select name="sel_app" id="sel_app" size="1" class="court">
							<?php echo $sapp;?>
						</select>
						<label for="sel_chn" class="court">Chaîne</label>
						<select name="sel_chn" id="sel_chn" size="1">
							<?php echo $schn;?>
						</select>
						<label for="sel_pro">Processus</label>
						<select name="sel_pro" id="sel_pro" size="1" class="long">
							<?php echo $spro;?>
						</select>
					</p>
				</form>
			</fieldset>
		</div>
		<div id="conteneur-calendrier">
			<fieldset id="calendrier" style="display:none;"><legend> Calendrier </legend>
				<form action="index.php" id="sppe_calendrier" name="sppe_calendrier" method="GET">
					<input type="hidden" name="page" value="<?php echo getPost('page');?>" />
					<p>
						<input type="image" src="img/prec.png" name="cmd_prec" id="cmd_prec" alt="précédent">
						<select name="sel_cal" id="sel_cal" size="1">
							<?php echo $scal;?>
						</select>
						<input type="image" src="img/suiv.png" name="cmd_suiv" id="cmd_suiv" alt="suivant">
					</p>
					<p>
						<input type="submit" id="cmd_mod" name="cmd_mod" value="<?php echo $cmd_mod_lib;?>">
						<input type="submit" id="cmd_auj" name="cmd_auj" value="<?php echo $cmd_auj_lib;?>">
					</p>
				</form>
			</fieldset>
		</div>
	</div>
<?php
	if (isset($realise) and $realise) {
?>
		<div id="legende">
			<table>
				<tr>
					<td class="termine">terminé</td>
					<td class="encours">en cours</td>
					<td class="abort">en abort</td>
					<td class="hors_delai_avant">avant prévisionnel</td>
					<td class="hors_delai_apres">après prévisionnel</td>
				</tr>
			</table>
		</div>
<?php
	}
}
?>
<script>
	$(document).ready( function () {
		$("#cmd_prec").on("click",function(){
			var moisSelectionne = $("#sel_cal option:selected").index();
			moisSelectionne--;
			$("#sel_cal").prop('selectedIndex', moisSelectionne);
			return true;
		});
		$("#cmd_suiv").on("click",function(){
			var moisSelectionne = $("#sel_cal option:selected").index();
			moisSelectionne++;
			$("#sel_cal").prop('selectedIndex', moisSelectionne);
			return true;
		});
	});
</script>