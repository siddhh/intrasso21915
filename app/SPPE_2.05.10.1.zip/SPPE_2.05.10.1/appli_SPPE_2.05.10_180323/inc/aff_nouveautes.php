<div id="nouveautes">
    <form action="nouveau.php" method="POST">
        <h4>
            Nouveautés <?php echo $portee_titre;?>
            <input type="hidden" name="force_affichage" value="<?php echo $force_affichage;?>">
            <input type="submit" name="<?php echo $portee;?>" value="<?php echo $portee_lib;?>" style="margin-left:3em; width:20em;">
        </h4>
    </form>
    <p id="nv_entete">&nbsp;&nbsp; date &nbsp;&nbsp; heure &nbsp;&nbsp; &bull; &nbsp;&nbsp; objet</p>
    <?php echo $nouveautes;?>
</div>
