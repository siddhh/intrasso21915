<?php

	/* SPPE : Suivi du Plan de Production des Exploitations
	 * * SI-2A DME - DISI PARIS NORMANDIE - ESI ROUEN LM
	 * 
	 * Squelette de l'application
	 * 
	 * Avril 2014 */

	/* ----------- */
	$erreur = 1;
	if (isset($page)) {
		if (file_exists('inc/'.$page.'.php')) {
			$erreur = 0;
		}
	}
	/* Type de serveur */
	$serveur = '';
	
	/* Connexion */

	$messages = '';

	if (MODE_CONNECTE && ($_SESSION['uti_id']=='0')){ // premiere connexion de l'utilisateur
		/* Consultation de l'annuaire LDAP */
		$uidFonctionnel = identificationAgent($_SERVER['PHP_AUTH_USER']);
		if (!empty($uidFonctionnel)){
			/* Si besoin, le premier jour de la semaine (pjdls) est calculé par PostgreSQL */
			$req = 'SELECT *, (current_date-(extract(dow from current_date)-1)::int4) as pjdls
					FROM utilisateurs
					WHERE uti_uid_fonctionnel=$1';
			$prm = array($uidFonctionnel);
			$res = pg_query_params($db, $req, $prm);
	
			if ($lu = pg_fetch_assoc($res)){
				$_SESSION['uti_id'] 				= $lu['uti_id'];
				$_SESSION['uti_uid_fonctionnel'] 	= $lu['uti_uid_fonctionnel'];
				$_SESSION['uti_nom'] 				= $lu['uti_nom'];
				$_SESSION['uti_prenom'] 			= $lu['uti_prenom'];
				$_SESSION['uti_timbre'] 			= $lu['uti_timbre'];
				
				// constituion des droits de l'utilisateur
				$_SESSION['uti_droits'] 			= recupereDroits($lu['uti_id'],$lu['serv_id']);
				$_SESSION['uti_admin'] 				= $lu['uti_admin'];
				
				$_SESSION['esi_id'] 				= $lu['esi_id'];
				$_SESSION['serv_id'] 				= $lu['serv_id'];
				
				$_SESSION['sel_esi']				= ($lu['esi_id'] == null ? '0' : $lu['esi_id']);
				$_SESSION['sel_dom'] 				= ($lu['uti_sel_dom'] == null ? '0' : $lu['uti_sel_dom']);
				$_SESSION['sel_chn'] 				= ($lu['uti_sel_chn'] == null ? '0' : $lu['uti_sel_chn']);
				$_SESSION['sel_pro'] 				= ($lu['uti_sel_pro'] == null ? '0' : $lu['uti_sel_pro']);
				$_SESSION['sel_app'] 				= ($lu['uti_sel_app'] == null ? '0' : $lu['uti_sel_app']);
				$_SESSION['sel_sui'] 				= ($lu['uti_sel_sui'] == 't' ? 'on' : '');
				$_SESSION['sel_ave'] 				= ($lu['uti_sel_ave'] == 't' ? 'on' : '');
				$_SESSION['sel_cal'] 				= ($lu['uti_sel_cal'] == 't' ? $lu['pjdls'] : date('Y-m'));
	
				/* Actualisation de la connexion */
				$req = 'UPDATE utilisateurs SET uti_timbre=CURRENT_TIMESTAMP WHERE uti_id=$1';
				pg_query_params($db, $req, array($_SESSION['uti_id']));
	
	// 			header('Location:http:nouveau.php');
			}else{
				$erreur = 3;
			}
		}else{
			$erreur = 4;
		}
	}

	/* Enregistrement des préférences */
	if (array_key_exists('cmd_enr', $_GET)) {
		$req = 'UPDATE utilisateurs SET
				uti_sel_dom=$1,
				uti_sel_app=$2,
				uti_sel_chn=$3,
				uti_sel_pro=$4,
				uti_sel_sui=$5,
				uti_sel_cal=$6,
				uti_sel_ave=$7
				WHERE uti_id=$8';
		$prm = array(nullorid('sel_dom'),
					nullorid('sel_app', false),
					nullorid('sel_chn'),
					nullorid('sel_pro'),
					($_SESSION['sel_sui'] == 'on' ? 't' : 'f'),
					(strlen($_SESSION['sel_cal']) == 10 ? 't' : 'f'),
					($_SESSION['sel_ave'] == 'on' ? 't' : 'f'),
					$_SESSION['uti_id']);
		$res = pg_query_params($db, $req, $prm);

		if ($res === false) {
			$cnx_info = '<p id="cnx_erreur">Échec</p>';
		} else {
			$cnx_info = '<p id="cnx_info">Préférences enregistrées</p>';
		}
	}

	/* Nouveautés */

	$nouveautes = '';
	if ($page == 'aff_nouveautes') {
		require 'inc/nouveautes.php';
		if ($nouveautes == ''){
			$page = 'grille';
		}
	}
	
	/* Calendrier */
	require 'calendrier.php';

	/* Sélections */
	if ($erreur == 0) {
		require 'selections.php';
	}

	$cmd_ges_disabled= (estHabil(HABIL_GESTION_DATE) ? false : true);
	$cmd_ref_disabled = ((estHabil(HABIL_GESTION_DATE) && ($_SESSION['sel_app']{0} === 'E')) ? false : true);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<title>SPPE : Suivi du Plan de Production des Exploitations</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="CACHE-CONTROL" content="max-age=600,s-maxage=600,no-cache,public,must-revalidate,proxy-revalidate">
	<link rel="icon" type="image/png" href="img/fp_icone.png">
	<link rel="stylesheet" type="text/css" href="css/sppe.css?<?php echo DATE_VERSION;?>">
<?php
	if (($page == 'gesdates') || ($page == 'grille')) {
		require 'css_couleurs.php';
	}
	if ($realise) {
?>
		<link rel="stylesheet" type="text/css" href="css/calendar.css?<?php echo DATE_VERSION;?>">
		<script src="js/calendar.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
		<script src="js/realise.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
<?php
	}
	if (($page == 'gesdates') || (($page == 'grille') && !$realise)) {
?>
		<link rel="stylesheet" type="text/css" href="css/calendar.css?<?php echo DATE_VERSION;?>">
		<script src="js/calendar.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
		<script src="js/gesdates.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
<?php
	}
	if ($page == 'admin') {
?>
		<script type="text/javascript" src="js/jscolor/jscolor.js?<?php echo DATE_VERSION;?>"></script>
<?php
	}
?>
	<script src="js/jquery-3.2.1.min.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
	<!--  <script src="js/backfix.min.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script> -->
	<script src="js/outils.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
	<script src="js/sppe.js?<?php echo DATE_VERSION;?>" type="text/javascript"></script>
	<script type="text/javascript">
		var cmd_bouton = '<?php echo $cmdb;?>';
		var page_affichee = '<?php echo $page;?>';
		var droits = JSON.parse('<?php echo json_encode($_SESSION['uti_droits']);?>');
		var admin = <?php echo (($_SESSION['uti_admin']=='t')?'true':'false');?>;
	</script>
</head>
<body>
	<!-- Partie gauche ========================================================================= -->
	<div id="gauche">
	<?php
		require 'menu_gauche.php';
	?>
	</div>
	<!-- Partie droite ========================================================================= -->
	<div id="droite">
		<div id="tete">
		<?php
			require 'entete.php'
		?>
		</div>
		<div id="page">
		<?php
// 					debug($_SERVER);

			if ($erreur) {
				require 'erreur.php';
			} else {
				require $page.'.php';
			}
		?>
		</div>
	</div>
</body>
</html>
<!-- FIN ======================================================================================= -->
