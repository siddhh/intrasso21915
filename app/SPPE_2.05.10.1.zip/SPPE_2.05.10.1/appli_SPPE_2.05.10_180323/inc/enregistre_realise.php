<?php
	/* SPPE
	 * enregistre_realise.php
	 * Enregistrement du réalisé
	 */

	$messages = '';

	$prerequis = (isset($_SESSION) && array_key_exists('esi_id', $_SESSION) && ($_SESSION['esi_id'] != null) && ($_SESSION['esi_id'] != 0));

	$enregistre_realise = ((getPost('cmd_sais_reel')!='') && $prerequis);
	$supprime_realise = ((getPost('cmd_sais_suppr_rea')!='') && $prerequis);
	$restaure_realise = ((getPost('cmd_sais_rest_rea')!='') && $prerequis);

	$pln_id_reel = 0;
	$esi_id_reel = 0;

	if ($prerequis) {
		$esi_id_reel = $_SESSION['esi_id'];
		if (getPost('hreel_pln_id')!='') {
			$pln_id_reel = getPost('hreel_pln_id');
		}
	}

	if ($enregistre_realise) {

		/* Enregistrement du réalisé ------------------------------------------------------------ */

		/* Présence d'un réalisé ? */
		$req = 'SELECT COUNT(*) FROM realise WHERE pln_id=$1 AND esi_id=$2';
		$prm = array($pln_id_reel, $esi_id_reel);
		$res = pg_query_params($db, $req, $prm);
		$lu = pg_fetch_row($res);

		if ($lu[0] > 0) {

			/* Oui : requête de mise-à-jour */
			$req = 'UPDATE realise SET
					uti_id=$3,
					rea_debut=$4,
					rea_fin=$5,
					rea_statut=$6,
					rea_notes=$7,
					rea_timbre=current_timestamp
					WHERE pln_id=$1 AND esi_id=$2';
		} else {

			/* Non : requête d'insertion */
			$req = 'INSERT INTO realise
						(pln_id, esi_id, uti_id, rea_debut, rea_fin, rea_statut, rea_notes)
					VALUES
						($1, $2, $3, $4, $5, $6, $7)';
		}

		/* Données du réalisé */
		$debut = pg_date(getPost('reel_debut'));
		$fin = pg_date(getPost('reel_fin'));
		$abort = array_key_exists('reel_abort', $_REQUEST);
		$statut = ($abort ? 'A' : ($fin != null ? 'T' : null));
		$notes_rea = trim(getPost('reel_notes'));

		if (is_null($debut) && is_null($fin) && (strlen($notes_rea) < 2)) {

			/* Suppression du réalisé par vidage des champs */
			$supprime_realise = true;

		} else {

			/* Enregistrement */
			$prm = array($pln_id_reel, $esi_id_reel, $_SESSION['uti_id'],$debut, $fin, $statut, $notes_rea);
			$res = pg_query_params($db, $req, $prm);

			if ($res === false) {
				$messages = '<p id="messages"><span class="erreur">Échec de l\'enregistrement !</span></p>';
			} else {
				$messages = '<p id="messages"><span class="info">Enregistrement réussi</span></p>';
			}
		}
	}

	if ($supprime_realise) {
		
		/* Suppression du réalisé --------------------------------------------------------------- */

		sql_gen('begin');

		/* Suppression d'un éventuel archivage précédent */
		$prm = array($pln_id_reel, $esi_id_reel);
		sql_gen("DELETE FROM steps_archive
				WHERE  job_id IN (
					SELECT job_id
					FROM jobs_archive
					WHERE pln_id=$1
					AND esi_id=$2
				)",$prm);
		sql_gen("DELETE FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2", $prm);
		sql_gen("DELETE FROM realise_archive WHERE pln_id=$1 AND esi_id=$2", $prm);

		/* Archivage */
		$req = "INSERT INTO steps_archive
					(stp_id,job_id,stp_lib,stp_etat,stp_debut,stp_fin,stp_elapsed,stp_cpu)
				SELECT stp_id, job_id, stp_lib, stp_etat, stp_debut, stp_fin, stp_elapsed, stp_cpu
				FROM steps
				WHERE job_id IN (
					SELECT job_id FROM jobs WHERE pln_id=$1 AND esi_id=$2
				)";
		sql_gen($req, $prm);

		$req = "INSERT INTO jobs_archive
					(job_id,job_lib,mbx_id,pln_id,ent_id,esi_id,job_debut,job_fin,job_ron,job_etat, job_dernier)
				SELECT job_id, job_lib, mbx_id, pln_id, ent_id, esi_id,job_debut, job_fin, job_ron, job_etat, job_dernier
				FROM jobs
				WHERE pln_id=$1
				AND esi_id=$2";
		sql_gen($req, $prm);

		$req = "INSERT INTO realise_archive
					(rea_id,pln_id,esi_id,uti_id,rea_debut,rea_fin,rea_statut,rea_timbre,rea_notes)
				SELECT rea_id, pln_id, esi_id, uti_id, rea_debut, rea_fin, rea_statut, rea_timbre, rea_notes
				FROM realise
				WHERE pln_id=$1
				AND esi_id=$2";
		sql_gen($req, $prm);

		/* Suppression */
		sql_gen("DELETE FROM steps
				WHERE job_id IN (
					SELECT job_id FROM jobs WHERE pln_id=$1 AND esi_id=$2
				)", $prm);
		sql_gen("DELETE FROM jobs WHERE pln_id=$1 AND esi_id=$2", $prm);
		sql_gen("DELETE FROM realise WHERE pln_id=$1 AND esi_id=$2", $prm);

		sql_gen('commit');
		$messages = '<p id="messages"><span class="info">Réalisé supprimé</span></p>';
	}

	if ($restaure_realise) {

		/* Restauration d'un réalisé ------------------------------------------------------------ */

		sql_gen('begin');

		/* Vérification présence d'archivage à restaurer */
		$prm = array($pln_id_reel, $esi_id_reel);
		$req = "SELECT (SELECT COUNT(*) FROM realise_archive where pln_id=$1 AND esi_id=$2) +
						(SELECT COUNT(*) FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2) +
						(	SELECT COUNT(*) FROM steps_archive
							WHERE job_id IN (
								SELECT job_id FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2
							)
						)
				";
		$res = sql_gen($req, $prm);
		$lu = pg_fetch_row($res);

		if ($lu[0]) {

			/* Vérification absence réalisé */
			$prm = array($pln_id_reel, $esi_id_reel);
			$req = "SELECT (
						SELECT COUNT(*) FROM realise WHERE pln_id=$1 AND esi_id=$2
					) +
					(SELECT COUNT(*) FROM jobs WHERE pln_id=$1 AND esi_id=$2)";
			$res = sql_gen($req, $prm);
			$lu = pg_fetch_row($res);

			if ($lu[0]) {

				$messages = '<p id="messages"><span class="erreur">Restauration impossible en présence de réalisé plus récent !</span></p>';

			} else {

				sql_gen('begin');

				$req = "INSERT INTO jobs
							(job_id,job_lib,mbx_id,pln_id,ent_id,job_debut,job_fin,job_ron,job_etat, job_dernier)
						SELECT job_id, job_lib, mbx_id, pln_id, ent_id, job_debut, job_fin, job_ron, job_etat, job_dernier
						FROM jobs_archive
						WHERE pln_id=$1
						AND esi_id=$2";
				sql_gen($req, $prm);

				$req = "INSERT INTO realise
							(rea_id,pln_id,esi_id,uti_id,rea_debut,rea_fin,rea_statut,rea_timbre,rea_notes)
						SELECT rea_id, pln_id, esi_id, uti_id, rea_debut, rea_fin, rea_statut, rea_timbre, rea_notes
						FROM realise_archive
						WHERE pln_id=$1
						AND esi_id=$2";
				sql_gen($req, $prm);

				$req = "INSERT INTO steps
							(stp_id,job_id,stp_lib,stp_etat,stp_debut,stp_fin,stp_elapsed,stp_cpu)
						SELECT stp_id, job_id, stp_lib, stp_etat, stp_debut, stp_fin, stp_elapsed, stp_cpu
						FROM steps_archive
						WHERE job_id IN (
							SELECT job_id FROM jobs_archive WHERE pln_id=$1 aND esi_id=$2
						)";
				sql_gen($req, $prm);

				$req = "DELETE FROM steps_archive
						WHERE job_id IN (
							SELECT job_id FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2
						)";
				sql_gen($req, $prm);

				$req = "DELETE FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2";
				sql_gen($req, $prm);

				$req = "DELETE FROM realise_archive WHERE pln_id=$1 AND esi_id=$2";
				$res = sql_gen($req, $prm);

				if ($res === false) {
					sql_gen('rollback');
					$messages = '<p id="messages"><span class="erreur">La restauration a échoué !</span></p>';
				} else {
					sql_gen('commit');
					$messages = '<p id="messages"><span class="info">Réalisé restauré</span></p>';
				}
			}
		} else {
			$messages = '<p id="messages"><span class="erreur">Il n\'existe aucun réalisé archivé à restaurer !</span></p>';
		}

		sql_gen('commit');
	}

    

// fin
