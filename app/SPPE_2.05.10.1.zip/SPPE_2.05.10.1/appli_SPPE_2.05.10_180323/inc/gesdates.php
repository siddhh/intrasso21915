<?php

	/* Gestion des dates ou recherche seulement */

	require 'ferie.php';
	require 'calcul.php';
	require 'enregistre.php';

	$an = date('Y');

	/* Variable de session */

	sess('gd_objet', '0');
	sess('gd_recherche', '');
// 	sess('gd_mois', '0');
	sess('gd_annee', $an);
	sess('gd_res', '0');

	if ($recherche_seulement) {
		$soustitre = 'Recherche';
	} else {
		$soustitre = 'Gestion des dates';
	}

	/* Confirmation globale */

	if (($recherche_seulement === false) && (array_key_exists('gd_confglob', $_POST)) && ($_POST['gd_confirme'] == 'oui')) {
		$req = "UPDATE plan SET
				pln_confirm='t'
				WHERE pro_id=$1
				AND EXTRACT(year FROM pln_debut)=$2";
		pg_query_params($db, $req, array($_SESSION['gd_res'], $_SESSION['gd_annee']));
	}

	/* Application de la règle de planification */

	if (($recherche_seulement === false) && (array_key_exists('gd_regplan', $_POST)) && $_POST['gd_confirme'] == 'oui') {
		$rapport = '';
		$req = 'SELECT * FROM processus WHERE pro_id=$1';
		$res = pg_query_params($db, $req, array($_SESSION['gd_res']));
		if ($pro = pg_fetch_assoc($res)){
			$rapport = calcul($pro, null, false, null, true);
		}
		if ($rapport === '') {
			$messages = '<p id="messages"><span class="erreur">Échec de l\'application de la règle de planification !</span></p>';
		} elseif (strpos($rapport, 'ATTENTION')) {
			$messages = '<p id="messages"><span class="erreur">Problème sur la règle de planification !<br>'.$rapport.'</span></p>';
		} else {
			$messages = '<p id="messages"><span class="info">Règle de planification appliquée</span></p>';
			sql_touche_processus($_SESSION['gd_res']);
		}
	}

	/* Objet */

	$objet = option('Processus', '0', $_SESSION['gd_objet'])
			.option('Processus sans dates', '1', $_SESSION['gd_objet'])
			.option('Chaîne', '2', $_SESSION['gd_objet'])
			.option('Application', '3', $_SESSION['gd_objet'])
			.option('Job', '4', $_SESSION['gd_objet']);

	/* Années */

	$an--;
	$annees = option($an, $an, $_SESSION['gd_annee']);
	$an++;
	$annees .= option($an, $an, $_SESSION['gd_annee']);
	$an++;
	$annees .= option($an, $an, $_SESSION['gd_annee']);;

	$annee_modifiable = ($_SESSION['gd_annee'] >= date('Y'));

// 	/* Mois */
// 	$lesMois = array ('','Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre');
// 	$selectMois = '';
// 	foreach( $lesMois as $num => $mois){
// 		$selectMois .= option($mois,$num,$_SESSION['gd_mois']);
// 	}
	
	/* Résultats de la sélection */

	$gd_res = '';

	$champ = array('p.pro_nom', 'p.pro_nom', 'c.chn_nom', 'a.app_nom', 'm.mbx_nom');

	$explicite = (array_key_exists('gd_cmd_go', $_REQUEST));
	$implicite = ($_SESSION['gd_res'] != '0');
	$recherche = (strlen(trim($_SESSION['gd_recherche'])) > 0);
	$sans_date = ($_SESSION['gd_objet'] == '1');

	if ($explicite){
		$_SESSION['gd_res'] = '0';
	}

	if ($explicite || $implicite) {

		$prm = array('%'.trim($_SESSION['gd_recherche']).'%');

		$cond_sup = '';

		if ($sans_date) {
			$cond_sup = ' AND p.pro_id NOT IN (
							SELECT DISTINCT q.pro_id
							FROM plan q 
							WHERE (EXTRACT(year FROM pln_debut)=$2 OR EXTRACT(year FROM pln_fin)=$2)
						) ';
			array_push($prm, $_SESSION['gd_annee'], $_SESSION['gd_mois']);
		}

		$req = 'SELECT DISTINCT p.pro_id, p.pro_nom, k.lst_chaines
				FROM processus p
				JOIN liens l ON l.pro_id=p.pro_id
				JOIN membrex m ON m.mbx_id=l.mbx_id
				JOIN chaines c ON c.chn_id=m.chn_id
				JOIN applications a ON a.app_id=c.app_id
				JOIN liste k ON k.pro_id=p.pro_id AND k.pro_version=p.pro_version
				WHERE '.$champ[intval($_SESSION['gd_objet'])].' ILIKE $1 '.$cond_sup.'
				ORDER BY p.pro_nom';
		$res = pg_query_params($db, $req, $prm);

		while ($lu = pg_fetch_assoc($res)) {
			$gd_res .= option($lu['pro_nom'].' ('.$lu['lst_chaines'].')', $lu['pro_id'], $_SESSION['gd_res']);
		}
	}

	/* Gestion du report N+1 */

	$gd_rapport = '';
	if (($recherche_seulement === false) && array_key_exists('gd_projette', $_POST) && ($_POST['gd_confirme'] == 'oui')) {
		/* Report N+1 */

		$_SESSION['gd_res'] = '0';
		$gd_rapport = '<div id="gd_rapport">'.report().'</div>';

	} else {
		if (($recherche_seulement === false) && array_key_exists('gd_purge', $_POST) && ($_POST['gd_confirme'] == 'oui')) {
			/* Purge du report N+1 */

			$_SESSION['gd_res'] = '0';
			$gd_rapport = '<div id="gd_rapport">'.purge_report().'</div>';
		}
	}

	/* Calendrier annuel*/

	$gd_pro_nom = '';
	$gd_pro_lib = '';
	$gd_pro_objet = '';
	$saisie_dates = '';
	$gd_annuel = '';
	$gd_recalcul = false;   // possibilité de réappliquer la règle de calcul

	$gd_res_size = 20;

	$conf_globale = 0;

	if ($_SESSION['gd_res'] != '0') {

		$gd_res_size = 4;

		/* Description du processus */

		$req = 'SELECT pro_nom, pro_lib, pro_vindex, pro_premier, pro_objet,  pro_regle
				FROM processus
				WHERE pro_id=$1';
		$res = pg_query_params($db, $req, array($_SESSION['gd_res']));
		$lu = pg_fetch_row($res);

		$gd_pro_nom = '<h4><a href="'.LEONARD.$lu[2].'" target="_blank">'.$lu[0].'</a></h4>';
		$gd_pro_lib = '<h5>'.$lu[1].'</h5>';
		$gd_pro_objet = ((trim($lu[4]) == '') ? '' :'<div id="objet"><div id="objet_titre">Planification :</div><div id="objet_contenu">'.$lu[4].'</div></div>');
		$premier = ($lu[3] == 't');

		/* impossibilité de réappliquer la règle de calcul si la règle commence par D=J ou F=D */
		$regle3 = substr($lu[5], 0, 3);
		$gd_recalcul = (($regle3 != 'D=J') && ($regle3 != 'F=D'));

		/* Stockage des mises au plan du processus */

		$an = $_SESSION['gd_annee'];

		$req = 'SELECT *,(pln_debut<>COALESCE(pln_debut_calc, $3::date) OR pln_fin<>COALESCE(pln_fin_calc, $3::date)) as manuel
				FROM plan
				WHERE pro_id=$1
				AND (EXTRACT(year FROM pln_debut)=$2 OR EXTRACT(year FROM pln_fin)=$2)
				ORDER BY pln_debut';
		$res = pg_query_params($db, $req, array($_SESSION['gd_res'], $an, DATE_PASSE));

		$map = array();
		$ids = array();
		$deux = array();    // à vrai si la planif fait au moins deux jours
		$un_jour = new DateInterval('P1D');
		/*if ($an > '2014' and $an == date('Y') and $cmdb == 'cmd_ges')
			$d = new DateTime(date('Y-m').'-01');
		else*/
		$d = new DateTime($an.'-01-01');

		$premier_janvier = false;
		while (($lu = pg_fetch_assoc($res)) && ($d->format('Y') <= $an)) {

			while ($d->format('Y-m-d') < $lu['pln_debut']) {
				array_push($map, 0);
				array_push($deux, false);
				array_push($ids, '0d'.$d->format('Ymd'));
				$d->add($un_jour);
			}
			while ($d->format('Y-m-d') <= $lu['pln_fin']) {
				if ($premier && ($d->format('m-d') == '01-01') && ($d->format('Y-m-d') == $lu['pln_debut'])) {
					$premier_janvier = true;
				}
				array_push($deux, ($lu['pln_fin'] > $lu['pln_debut']));
				if ($lu['pln_suppr'] == 't') {
					array_push($map, 5);
				} else {
					if ($lu['pln_confirm'] == 't') {
						if ($lu['manuel'] == 't') {
							array_push($map, 3);
						} else {
							array_push($map, 1);
						}
					} else {
						$conf_globale++;
						if ($lu['manuel'] == 't') {
							array_push($map, 4);
						} else {
							array_push($map, 2);
						}
					}
				}
				array_push($ids, $lu['pln_id'].'d'.$d->format('Ymd'));
				$d->add($un_jour);
			}
		}

		while ($d->format('Y') <= $an) {
			array_push($map, 0);
			array_push($ids, '0d'.$d->format('Ymd'));
			$d->add($un_jour);
		}

		/* Entête du tableau */

		$gd_annuel = '<table id="annuel">';

		$gd_annuel .= '<tr id="gd_jours"><th>'.$an.'</th>';
		for ($j=1; $j<32; $j++) {
			$gd_annuel .= '<td class="ferie">'.$j.'</td>';
		}
		$gd_annuel .= '</tr>';

		$mois = 0;
		/*if ($an > '2014' and $an == date('Y') and $cmdb == 'cmd_ges')
			$d->setDate(intval($an), intval(date('m'), 10), 1);
		else*/
		$d->setDate(intval($an), 1, 1);

		$feries = feries($d, 366);

		$j = 0;
		$k = 0;
		$pj = true;     // premier jour d'une période
		while ($d->format('Y') == $an) {

			if ($d->format('m') != $mois) {
				if ($mois) {
					for ($i=$k; $i<31 ; $i++) {
						$gd_annuel .= '<td class="hachures">&nbsp;</td>';
					}
					$gd_annuel .= '</tr>';
				}
				$gd_annuel .= '<tr><th>'.ucfirst(strftime('%B', $d->getTimestamp())).'</th>';
				$mois = $d->format('m');
				$k = 0;
			}

			$s = '&nbsp;';
			if ($map[$j] > 0) {
				/* condition premier jour obligatoire (!) */
				$cpjo = ($pj && $premier && ($j || $premier_janvier) && $deux[$j]);
				if ($cpjo){
					$s = '!';
				}
				switch ($map[$j]) {
					case 1 :
						$c = ' class="sure"';
						break;
					case 2 :
						$c = ' class="pas_sure"';
						$s = ($cpjo ? '!' : '?').'??';
						break;
					case 3 :
						$c = ' class="sure_manuel"';
						break;
					case 4 :
						$c = ' class="pas_sure_manuel"';
						$s = ($cpjo ? '!' : '?').'??';
						break;
					case 5 :
						$c = ' class="supprime"';
						$s = 'X';
						break;
				}
				$pj = false;
			} else {
				$pj = true;
				$c = ($feries{$j} == '0' ? ' class="ferie"' : '');
			}

			/* Identification */
			$i = ((($cmdb == 'cmd_ges') && $annee_modifiable) ?' id="'.$ids[$j].'"' : '');

			$gd_annuel .= '<td'.$i.$c.'>'.$s.'</td>';

			$d->add($un_jour);
			$j++;
			$k++;
		}

		$gd_annuel .= '</tr></table>';

		if (array_key_exists('pln_id', $_REQUEST) and estHabil(HABIL_GESTION_DATE)) {
			$pln_id_suivant = $_REQUEST['pln_id'];
		}

		if ($pln_id_suivant !== '') {
			require 'saisie_dates.php';
		}
	}

	/* Confirmation groupée de toutes les mises au plan */

	$bouton_conf_globale = '';
	if (($recherche_seulement === false) && ($conf_globale > 1) && estHabil(HABIL_GESTION_DATE)) {
		$bouton_conf_globale = '<input type="submit" name="gd_confglob" id="gd_confglob" value="Confirmer toutes les occurrences">';
	}

	/* Application de la règle de planification */

	$bouton_regle_planif = '';
	if (($recherche_seulement === false) && estHabil(HABIL_GESTION_DATE) && $gd_recalcul) {
		$bouton_regle_planif = '<input type="submit" name="gd_regplan" id="gd_regplan" value="Appliquer la règle de planification">';
	}

	/* Boutons du report N+1 */

	$boutons_report = '';
	$req = "SELECT valeur FROM statut WHERE objet='report'";
	$res = pg_query($db, $req);
	if ($lu = pg_fetch_row($res)) {
		if ($lu[0] == 'on') {
			$boutons_report = '<input type="submit" name="gd_projette" id="gd_projette" value="Effectuer le report N+1"><input type="submit" name="gd_purge" id="gd_purge" value="Purger le report N+1">';
		}
	}
?>
<div id="gd_dates">
	<form action="index.php" name="gd_sel" method="GET">
		<input type="hidden" name="page" value="<?php echo $action;?>" />
		<div id="gd_selection">
			<div id="gd_tit">
				<h3><?php echo $soustitre;?></h3>
			</div>
			<div id="gd_sel">
				<label data-for="gd_objet">Objet</label>
				<select name="gd_objet" id="gd_objet" size="1">
					<?php echo $objet;?>
				</select>
				<input type="text" name="gd_recherche" id="gd_recherche" value="<?php echo $_SESSION['gd_recherche'];?>">
				<label data-for="gd_annee">Année</label>
				<select name="gd_annee" id="gd_annee" size="1">
					<?php echo $annees;?>
				</select>
				<input type="hidden" id="idencours" value="<?php echo $pln_id_suivant;?>">
				<input type="submit" name="gd_cmd_go" value="Go">
			</div>
		</div>
		<div id="gd_resultats">
			<h4>Résultats</h4>
			<select id="gd_res" name="gd_res" size="<?php echo $gd_res_size;?>">
				<?php echo $gd_res;?>
			</select>
		</div>
	</form>
	<div id="gd_detail">
	<?php
		echo $gd_pro_nom
			.$gd_pro_lib
			.$gd_pro_objet
			.$saisie_dates
			.$messages
			.$gd_annuel;
	?>
	</div>
</div>
<?php
	if (($recherche_seulement === false) && $annee_modifiable) {
?>
	<div id="gd_report">
		<form action="index.php" name="gd_rep" method="POST">
			<input type="hidden" name="page" value="dates" />
			<div>
				<input type="hidden" name="gd_confirme" id="gd_confirme" value="non">
				<?php echo $bouton_conf_globale.$bouton_regle_planif.$boutons_report;?>
			</div>
		</form>
		<?php echo $gd_rapport;?>
	</div>
<?php
	}
?>
