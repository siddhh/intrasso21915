<?php

/* SPPE
 * Outils d'administration réservé à SI
 *
 * JMD - 11/02/2016
 */



/* admin_applis ------------------------------------------------------------------------------------
 * Administration des applications
 */

	/* Enregistrement des modifications */

	if (!empty($_POST['siga_enrgt'])) {
		/* Réception des variables postées */
		$app = filter_input(INPUT_POST, 'siga_app');
		$lib = filter_input(INPUT_POST, 'siga_lib',FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES );
		$dom = filter_input(INPUT_POST, 'siga_dom');
		$serv = filter_input(INPUT_POST, 'siga_serv');
		$act = (array_key_exists('siga_act', $_POST) ? 't' : 'f');

		/* Mise-à-jour de l'application */
		sql_maj_appli($app, $lib, $dom, $serv, $act);
	}

	/* Lecture des applications, des domaines et des équipes */

	$applis = sql_lis_applis();
	$js_app = array();
	while ($lu = pg_fetch_assoc($applis)){
		$js_app[$lu['app_id']] = $lu;
	}
	pg_result_seek($applis, 0);

	$services = sql_lis_services();
	$js_serv = array();
	while ($lu = pg_fetch_assoc($services)){
		$js_serv[$lu['serv_id']] = $lu;
	}
	pg_result_seek($services, 0);
	
	$domaines = sql_lis_domaines();
	$js_dom = array();
	while ($lu = pg_fetch_assoc($domaines)){
		$js_dom[$lu['dom_id']] = $lu;
	}
	pg_result_seek($domaines, 0);

/* IHM */
?>
<h6 id="h6_admin_appli">Administration : Gestion des applications</h6>
<div id="admin_appli" class="moduleAdmin">
	<form action="" method="POST">
		<fieldset id="appli_saisie">
			<input type="hidden" name="module" value="admin_appli" />
			<p>
				<label for="siga_app">Application</label>
				<select name="siga_app" id="siga_app">
				<?php echo options($applis, '', '---');?>
				</select>
			</p>
			<p>
				<label for="siga_lib">Libellé</label>
				<input type="text" name="siga_lib" id="siga_lib" size="40" maxlength="1000" />
			</p>
			<p>
				<label for="siga_dom">Domaine</label>
				<select name="siga_dom" id="siga_dom">
				<?php echo options($domaines, '', '---');?>
				</select>
			</p>
			<p>
				<label for="siga_serv">Services</label>
				<select name="siga_serv" id="siga_serv">
				<?php echo options($services, '', '---');?>
				</select>
			</p>
			<p>
				<label for="siga_act">Actuelle</label>
				<input type="checkbox" name="siga_act" id="siga_act" />
			</p>
			<hr/>
			<p>
				&nbsp;
				<input type="submit" name="siga_enrgt" id="siga_enrgt" value="Enregistrer" disabled />
				&nbsp;
				<input type="reset" value="Annuler" />
			</p>
		</fieldset>
	</form>
</div>
<script type="text/javascript">
	var siga_applis = <?php echo json_encode($js_app);?>;
	var siga_services = <?php echo json_encode($js_serv);?>;
	var siga_domaines = <?php echo json_encode($js_dom);?>;
</script>