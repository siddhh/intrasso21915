<?php
	/* Enregistrement de la saisie manuelle */

	$messages = '';
	$pln_id_suivant = '';
	if (array_key_exists('cmd_sais_enrgt', $_POST) || array_key_exists('cmd_sais_suiv', $_POST)) {

		$pln_id = getPost('hsais_pln_id');
		$pro_id = getPost('hsais_pro_id');
		$debut = pg_date(getPost('sais_debut'));
		$fin = pg_date(getPost('sais_fin'));
		$confirm = (array_key_exists('sais_confirm', $_REQUEST) ? 't' : 'f');
		$confirm = ((getPost('sais_confirm')!='') ? 't' : 'f');
		$notes = trim(getPost('sais_notes'));
		$prive = trim(getPost('prive_notes'));

		if ($pln_id > 0) {

			/* ----- Modification d'une occurrence ----- */

			$req = 'UPDATE plan SET
					pln_debut=$2,
					pln_fin=$3,
					pln_confirm=$4,
					uti_id=$5,
					pln_timbre=current_timestamp,
					pln_notes=$6,
					pln_prive=$7
					WHERE pln_id=$1';
			$prm = array($pln_id, $debut, $fin, $confirm, $_SESSION['uti_id'], $notes, $prive);
		} else {

			/* ----- Ajout d'une occurrence ----- */

			$req = 'INSERT INTO plan
						(pro_id, pln_debut, pln_fin, pln_confirm, uti_id, pln_notes, pln_prive)
					VALUES
						($1, $2, $3, $4, $5, $6, $7)';
			$prm = array($pro_id, $debut, $fin, $confirm, $_SESSION['uti_id'], $notes, $prive);
		}
		$res = pg_query_params($db, $req, $prm);
		if ($res === false) {
			$messages = '<p id="messages"><span class="erreur">Échec de l\'enregistrement !</span></p>';
		} else {
			$messages = '<p id="messages"><span class="info">Enregistrement réussi</span></p>';
			sql_touche_processus($pro_id, $pln_id);

			if (array_key_exists('cmd_sais_suiv', $_POST)) {

				/* Préparation du suivant */

				$anc_id = $_REQUEST['hsais_pln_id'];

				if ($anc_id > 0) {
					$req = 'SELECT p.pln_id, p.pln_debut
							FROM plan p
							WHERE p.pln_debut > (SELECT q.pln_debut FROM plan q WHERE q.pln_id=$1)
							AND p.pro_id=$2
							ORDER BY p.pln_debut
							LIMIT 1';
					$prm = array($anc_id, $pro_id);
					$res = pg_query_params($db, $req, $prm);
					if ($lu = pg_fetch_row($res)) {
						$pln_id_suivant = $lu[0].'d'.str_replace('-', '', $lu[1]);
					}
				} else {
					$pln_id_suivant = '0d0';
				}
			}
		}
	}

	if (array_key_exists('hsais_supdef', $_REQUEST) && ($_REQUEST['hsais_supdef'] == 'oui')) {

		/* ----- Suppression d'une occurrence ----- */

		/* La suppression n'est effective que pour les mises au plan
		* manuelles ou ajustables, sans réalisé  */

		$modif = true;
		if (array_key_exists('dialogue_sup', $_POST)) {
			$req = 'SELECT q.pln_debut_calc, q.pln_fin_calc, p.pro_ajustable
					FROM plan q 
					JOIN processus p ON p.pro_id=q.pro_id
					WHERE q.pln_id=$1
					AND NOT EXISTS (SELECT r.* FROM realise r WHERE r.pln_id=$1)';
			$prm = array($_REQUEST['hsais_pln_id']);
			$res = pg_query_params($db, $req, $prm);

			if ($lu = pg_fetch_row($res)) {
				if ((($lu[0] == null) && ($lu[1] == null)) || ($lu[2] == 't')) {
					$req = 'DELETE FROM plan WHERE pln_id=$1';
					$prm = array($_REQUEST['hsais_pln_id']);
					$modif = false;
				}
			}
		}
		if ($modif) {
			$req = 'UPDATE plan SET
					pln_suppr=$2,
					pln_confirm=$4,
					uti_id=$3,
					pln_timbre=current_timestamp
					WHERE pln_id=$1';
			$prm = array($_REQUEST['hsais_pln_id'], 't', $_SESSION['uti_id'], 'f');
		}
		$res = pg_query_params($db, $req, $prm);

		if ($res === false) {
			$messages = '<p id="messages"><span class="erreur">Échec de la suppression !</span></p>';
		} else {
			$messages = '<p id="messages"><span class="info">Suppression réalisée</span></p>';
		}
	}

	if (array_key_exists('cmd_sais_rest', $_POST)) {

		/* ----- Restaure une occurrence ----- */

		$debut = pg_date($_REQUEST['sais_debut']);
		$fin = pg_date($_REQUEST['sais_fin']);
		$confirm = (array_key_exists('sais_confirm', $_REQUEST) ? 't' : 'f');
		$req = 'UPDATE plan SET
				pln_suppr=$2,
				uti_id=$3,
				pln_timbre=current_timestamp,
				pln_debut=$4,
				pln_fin=$5,
				pln_confirm=$6
				WHERE pln_id=$1';
		$prm = array($_REQUEST['hsais_pln_id'], 'f', $_SESSION['uti_id'], $debut, $fin, $confirm);
		$res = pg_query_params($db, $req, $prm);
		if ($res === false) {
			$messages = '<p id="messages"><span class="erreur">Échec de la restauration !</span></p>';
		} else {
			$messages = '<p id="messages"><span class="info">Restauration réalisée</span></p>';
		}
	}
?>
