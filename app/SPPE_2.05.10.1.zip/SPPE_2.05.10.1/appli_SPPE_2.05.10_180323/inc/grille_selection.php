<?php

	/* Sélection des processus */

	$prm = array($deb, $fin, DATE_PASSE);

	$sql_select = 'SELECT DISTINCT p.pro_nom, p.pro_index, p.pro_lib,
						p.pro_nouveautes, p.pro_libelle, q.pln_suppr, p.pro_id,
						p.pro_timbre, p.pro_rupture, p.pro_id, p.pro_vindex, p.pro_premier, p.pro_realise,
						q.pln_timbre, q.pln_id, q.pln_debut, q.pln_fin, q.pln_confirm,
						k.lst_chaines, q.pln_notes, q.pln_prive,
						(q.pln_debut<>COALESCE(q.pln_debut_calc, $3::date) OR q.pln_fin<>COALESCE(q.pln_fin_calc, $3::date)) as manuel,
						CASE WHEN p.pro_suivi THEN 2 ELSE 1 END as tri1,
						CASE WHEN p.pro_suivi THEN q.pln_debut ELSE q.pln_fin END as tri2, 
						a.dom_id ';
	$sql_from = 'FROM plan q
				JOIN processus p ON p.pro_id=q.pro_id
				JOIN liens l ON l.pro_id=p.pro_id
				JOIN membrex m ON m.mbx_id=l.mbx_id
				JOIN chaines c ON c.chn_id=m.chn_id
				JOIN applications a ON a.app_id=c.app_id
				JOIN liste k ON k.pro_id=p.pro_id AND k.pro_version=p.pro_version
				JOIN realisations_globales z ON z.pln_id=q.pln_id ';
	$sql_where = 'WHERE (((XfinX >= $1) AND (XfinX < $2))
					OR ((q.pln_debut < $1) AND (XfinX >= $2))';
	$sql_order = ' ORDER BY tri1, tri2, q.pln_debut, p.pro_nom';

	/* Sélection des seuls processus qui relèvent de la compétence de l'ESI sélectionné */
	$n = 4;
	if (($_SESSION['sel_esi'] != '0') || $realise) {
		$n++;
		array_push($prm,  ($_SESSION['sel_esi'] == '0' ? '1' : $_SESSION['sel_esi']));
		/* limitation aux processus du ressort de l'ESI */
		$sql_from .= ' JOIN ressort o ON o.pro_id=p.pro_id AND o.esi_id=$4 ';
		/* limitation de l'affichage à la fin réelle du processus pour l'ESI */
		$sql_where = str_replace('XfinX', ($realise ? 'y.butee' : 'q.pln_fin'), $sql_where);
	} else {
		/* pas d'ESI sélectionné ==> fin globale considérée */
		$sql_where = str_replace('XfinX', 'q.pln_fin', $sql_where);
	}

	$liste_abort = array();
	if ($realise) {
		/* Particularités en réalisé */
		$n++;
		$sel = ($_SESSION['sel_esi'] == '0' ? '1' : $_SESSION['sel_esi']);
		array_push($prm, $sel);
		/* fin retenue pour l'affichage du hors délai : voir bugzilla 165567 */
		$req = $sql_select
				.', r.rea_debut, r.rea_fin, r.rea_statut, r.rea_notes, '
				.'CASE WHEN r.rea_heure<8 THEN r.rea_fin-1 ELSE r.rea_fin END as fin_retenue '
				.$sql_from
				.' LEFT OUTER JOIN realise r ON r.pln_id=q.pln_id AND r.esi_id=$'.($n - 1)
				.' JOIN realisations y ON y.pln_id=q.pln_id AND y.esi_id=$'.($n - 1).' '
				.$sql_where
				." OR ((r.rea_debut >= $1) AND (r.rea_debut < $2))
					OR ((r.rea_fin >= $1) AND (r.rea_fin < $2))
					OR ((r.rea_debut < $1) AND (r.rea_fin >= $2))
					OR CASE WHEN r.rea_debut IS NULL
						THEN ((q.pln_debut >= $1) AND (q.pln_debut < $2))
						ELSE 'f'::boolean END)
				AND "
				.filtresSQL($n, $prm)
				.$sql_order;
		/* Préparation de la liste de processus ayant connu un abort */
		$liste_abort = sql_liste_proc_abort($deb, $fin, $sel);
	} else {
		/* Particularités en prévisionnel */
		if ($_SESSION['sel_esi'] != '0') {
			$sql_from .= ' JOIN realisations y ON y.pln_id=q.pln_id AND y.esi_id=$4 ';
		}
		$req = $sql_select
				.$sql_from
				.$sql_where
				.' OR ((q.pln_debut >= $1) AND (q.pln_debut < $2))) AND '
				.filtresSQL($n, $prm)
				.$sql_order;
	}
	$res = pg_query_params($db, $req, $prm);

// 	echo $req;    var_dump($prm);    exit;

// fin
