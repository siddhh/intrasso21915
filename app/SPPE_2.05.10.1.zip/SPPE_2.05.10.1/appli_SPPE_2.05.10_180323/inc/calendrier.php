<?php

    /* Calendrier ------------------------------------------------------------------------------- */

    /* Détermination des extrêmes */

    $an = date('Y');
    $mini = new DateTime(($an - 1).'-01-07');
    $jsm = $mini->format('N');
    if ($jsm > 1) {
        $mini->sub(new DateInterval('P'.($jsm - 1).'D'));
    }
    $maxi = new DateTime(($an + 1).'-12-31');

    $un_mois = new DateInterval('P1M');
    $une_sem = new DateInterval('P7D');

    /* Navigation */
    if (strlen($_SESSION['sel_cal']) == 7) {

        /* Mode mois */
    	
        $dym = date('Y-m');
        if (getPost('cmd_mod')!='') {
            if ($_SESSION['sel_cal'] == $dym) {
                $nwd = new DateTime();
            } else {
                $nwd = new DateTime($_SESSION['sel_cal'].'-07');
            }
            $jsm = $nwd->format('N');
            if ($jsm > 1) {
                $nwd->sub(new DateInterval('P'.($jsm - 1).'D'));
            }
            $_SESSION['sel_cal'] = $nwd->format('Y-m-d');
        } else {
        	if (getPost('cmd_auj')!='') {
                $_SESSION['sel_cal'] = $dym;
            } else {
            	if (getPost('cmd_prec.y')!='') {
                    $nwd = new DateTime($_SESSION['sel_cal'].'-07');
                    $nwd->sub($un_mois);
                    if ($nwd >= $mini) {
                        $_SESSION['sel_cal'] = $nwd->format('Y-m');
                    }
                } else {
                	if (getPost('cmd_suiv.y')!='') {
                        $nwd = new DateTime($_SESSION['sel_cal'].'-07');
                        $nwd->add($un_mois);
                        if ($nwd <= $maxi) {
                            $_SESSION['sel_cal'] = $nwd->format('Y-m');
                        }
                    }
                }
            }
        }

    } else {

        /* Mode semaine */
    	
    	if (getPost('cmd_mod')!='') {
            $_SESSION['sel_cal'] = substr($_SESSION['sel_cal'], 0, 7);
        } else {
        	if (getPost('cmd_auj')!='') {
                $nwd = new DateTime();
                $jsm = $nwd->format('N');
                if ($jsm > 1) {
                    $nwd->sub(new DateInterval('P'.($jsm - 1).'D'));
                }
                $_SESSION['sel_cal'] = $nwd->format('Y-m-d');
            } else {
            	if (getPost('cmd_prec.y')!='') {
                    $nwd = new DateTime($_SESSION['sel_cal']);
                    $nwd->sub($une_sem);
                    if ($nwd >= $mini) {
                        $_SESSION['sel_cal'] = $nwd->format('Y-m-d');
                    }
                } else {
                	if (getPost('cmd_suiv.y')!='') {
                        $nwd = new DateTime($_SESSION['sel_cal']);
                        $nwd->add($une_sem);
                        if ($nwd <= $maxi) {
                            $_SESSION['sel_cal'] = $nwd->format('Y-m-d');
                        }
                    }
                }
            }
        }
    }

    /* Peuplement du calendrier */

    $base = $mini;
    $scal = '';

    if (strlen($_SESSION['sel_cal']) == 7) {

        /* Au mois */

        $cmd_mod_lib = 'À la semaine" title="Afficher le calendrier hebdomadaire';
        $cmd_auj_lib = 'Mois courant" title="Se placer sur le mois courant';

        while ($base <= $maxi) {
            $scal .= option(ucfirst(strftime('%B %Y', $base->getTimeStamp())),$base->format('Y-m'), $_SESSION['sel_cal']);
            $base->add($un_mois);
        }

    } else {

        /* À la semaine */

        $cmd_mod_lib = 'Au mois" title="Afficher le calendrier mensuel';
        $cmd_auj_lib = 'Sem. cour." title="Se placer sur la semaine courante';

        while ($base <= $maxi) {
            $scal .= option(strftime('S%V: %d %b %Y', $base->getTimeStamp()),
                $base->format('Y-m-d'), $_SESSION['sel_cal']);
            $base->add($une_sem);
        }
    }
?>
