<?php
define('VERSION', 'Version sppe-2.5<br>du 01 septembre 2017');
?>