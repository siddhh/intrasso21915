<?php

    /* SPPE
     * job_detail.php
     *
     * Affichage du détail d'un job sous forme d'un pop-up
     */

    if (!isset($_SESSION)) session_start();
    require_once __DIR__ .'/init.php';

    /* Identifiant du job à afficher */
    $job_id = filter_input(INPUT_GET, 'job', FILTER_VALIDATE_INT,
        array('options' => array('default' => 0)));

    /* Par défaut */
    $titre = 'ERREUR';
    $corps = 'Appel incorrect';
    $etat = '<span style="color:darkgray">au plan</span>';

    $etats = array('X' => '<span style="color:blue">En cours</span>',
        'A' => '<span style="color:red">En abort</span>',
        'T' => 'Terminé');

    if ($job_id) {
        $corps = '';
        $res = sql_lis_job($job_id);
        if (pg_num_rows($res) == 0) {
            $corps = 'Job non trouvé';
        } else {
            while ($lu = pg_fetch_array($res)) {

                /* titre du job */
                $titre = $lu['mbx_nom'].' - '.$lu['ent_code'];

                /* dernier état connu du job */
                if (is_null($lu['job_etat'])) {
                    $corps = '';
                } else {
                    $etat = $etats[$lu['job_etat']];
                    $fin = '';
                    $temps = '';
                    if (!is_null($lu['job_fin'])) {
                        $fin = '<p>'.($lu['job_etat'] == 'A' ? 'Abort : ' : 'Fin &nbsp; : ')
                            .$lu['job_fin'].'</p>';
                        $temps = $lu['temps'];
                    }

                    /* détail d'un passage */
                    $corps .= '<div class="passage">'
                    /* début */
                        .'<p>Début : '.$lu['job_debut']
                            .'<span class="ron">N° RON : '.$lu['job_ron'].'</span></p>'
                    /* fin */
                        .$fin
                    /* temps écoulé */
                        .'<p class="espace">Temps de traitement (temps elapsed) : '.$temps.'</p>'
                        .'</div>'."\n";
                }
            }
        }
    }

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>SPPE - JOB</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" type="image/png" href="../img/fp_icone.png">
    <link rel="stylesheet" type="text/css" href="../css/job.css">
    <script type="text/javascript" src="../js/job.js"></script>
</head>
<body>
    <h1><?php echo $titre;?></h1>
    <div id="etat">État : <?php echo $etat;?></div>
    <div id="corps"><?php echo $corps;?></div>
    <div id="bouton"><input type="button" id="steps" value="Afficher les steps"></div>
</body>
</html>
