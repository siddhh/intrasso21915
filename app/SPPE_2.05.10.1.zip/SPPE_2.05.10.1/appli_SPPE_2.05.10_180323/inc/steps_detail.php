<?php

    /* SPPE
     * steps_detail.php
     *
     * Affichage du détail d'un job sous forme d'un pop-up  (steps)
     */

    if (!isset($_SESSION)) session_start();
    require_once __DIR__ .'/init.php';

    /* Identifiant du job à afficher */
    $job_id = filter_input(INPUT_GET, 'job', FILTER_VALIDATE_INT,
        array('options' => array('default' => 0)));

    /* Par défaut */
    $titre = 'ERREUR';
    $corps = 'Appel incorrect';
    $ron = '';

    if ($job_id) {
        $corps = '';
        $res = sql_lis_steps($job_id);
        if (pg_num_rows($res) == 0) {
            $corps = "Job non trouvé ou pas d'information sur les steps";
        } else {
            while ($lu = pg_fetch_array($res)) {

                /* titre du job */
                $titre = $lu['mbx_nom'].' - '.$lu['ent_code'];

                /* Changement de ron ? */
                if ($ron != $lu['job_ron']) {
                    if ($ron) {
                        /* fermeture table */
                        $corps .= '</table></div>'."\n";
                    }
                    /* n° RON */
                    $ron = $lu['job_ron'];
                    $corps .= '<div class="ron2">N° RON : '.$ron.'</div>'."\n"
                    /* ouverture table */
                        .'<div><table>'
                        .'<tr class="entete"><th>Step</th><th>État</th><th>Début</th>'
                        .'<th>Fin</th><th>Elapse</th><th>CPU</th></tr>'."\n";
                }
                $corps .= '<tr>'
                    .'<th>'.$lu['stp_lib'].'</th>'
                    .'<td class="centre">'.$lu['stp_etat'].'</td>'
                    .'<td>'.$lu['stp_debut'].'</td>'
                    .'<td class="aere">'.$lu['stp_fin'].'</td>'
                    .'<td class="aere">'.str_pad($lu['stp_elapsed'], 7, '0', STR_PAD_LEFT).'</td>'
                    .'<td class="aere">'.str_pad($lu['stp_cpu'], 7, '0', STR_PAD_LEFT).'</td>'
                    .'</tr>'."\n";
            }
            /* fermeture table */
            $corps .= '</table></div>'."\n";
        }
    }

?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
            "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>SPPE - Steps</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" type="image/png" href="../img/fp_icone.png">
    <link rel="stylesheet" type="text/css" href="../css/job.css">
    <script type="text/javascript" src="../js/job.js"></script>
</head>
<body>
    <h1><?php echo $titre;?></h1>
    <div id="suivi">Suivi des steps</div>
    <div id="corps"><?php echo $corps;?></div>
    <div id="bouton"><input type="button" id="job" value="Retour"></div>
</body>
</html>
