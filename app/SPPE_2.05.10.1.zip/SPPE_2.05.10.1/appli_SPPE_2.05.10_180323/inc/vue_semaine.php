<?php

    /* Entête */

    $deb = $_SESSION['sel_cal'];    // Date de début incluse
    $nb_jours = 7;                  // Nombre de jours sur la période

    $cell = new Cellule($deb, 7);

    $tsp = $cell->jour()->getTimeStamp();
    $tit = strftime('Semaine %V : du %e', $tsp);
    $lbm = strftime('%B', $tsp);
    $lby = strftime('%Y', $tsp);

    while ($cell->ok()) {
        $cell->classe('jsem');
        if ($cell->iso() == $jour_iso) $cell->classe('aujourdhui');
        $jours .= $cell->fabrique(strftime('%a %e', $cell->jour()->getTimeStamp()), 'th');
        $cell->suivant();
    }

    $tsp = $cell->jour()->getTimeStamp() - 86400;
    $j = strftime(' au %e %B %Y', $tsp);
    $m = strftime('%B', $tsp);
    $y = strftime('%Y', $tsp);
    if ($m != $lbm) $tit .= ' '.$lbm;
    if ($y != $lby) $tit .= ' '.$lby;
    $tit .= $j;

    $entete = '<tr style="background-color:#EEEEEE"><th colspan="'
        .(4 + $col_sup).'" style="color:#CE8C1E">'
        .'<span style="margin-right:15px;">'.$titre_tableau.'</span>'
        .'<form action="pdf/etat.php" method="POST" target="_blank" class="enligne">'
        .'<input type="image" src="img/pdf.png" title="sortie PDF" alt="sortie PDF">'
        .$export.'</form>&nbsp;'
        .'<form action="csv/grille_csv.php" method="POST" class="enligne">'
        .'<input type="image" src="img/calc.png" title="sortie tableur" alt="sortie tableur">'
        .$export.'</form>'
        .'</th><th colspan="7">'.$tit.'</th><th colspan="2">&nbsp;</th></tr>'
        .'<tr class="lib"><th colspan="'.(2 + $col_sup)
        .'">Nom du processus</th><th>Chaînes</th><th>Date de début</th>'
        .$jours.'<th>Date de fin</th><th>Observations</th></tr>';

    $col_sup += 5;

?>
