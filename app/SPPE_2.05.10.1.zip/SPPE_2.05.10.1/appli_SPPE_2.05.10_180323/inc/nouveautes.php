<?php

    /* Nouveautés depuis la précédente session */

    if (isset($_SESSION) and
        array_key_exists('uti_id', $_SESSION) and
        $_SESSION['uti_id'] != '0') {

        /* Forcer l'affichage ? */

        $force_affichage = 'NON';
        if (array_key_exists('force_affichage', $_REQUEST))
            $force_affichage = $_REQUEST['force_affichage'];

        /* Équipe ? */

        $cond_eqp = '';
        if (array_key_exists('serv_id', $_SESSION) && ($_SESSION['serv_id'] != null) && ($_SESSION['serv_id'] != '0')) {
            $cond_eqp = ' and a.serv_id='.$_SESSION['serv_id'].' ';
        }

        /* ESI ? */

        $cond_esi = '';
        if (array_key_exists('esi_id', $_SESSION) and
            $_SESSION['esi_id'] != null and
            $_SESSION['esi_id'] != '0') {
            $cond_esi = ' and r.esi_id='.$_SESSION['esi_id'].' ';
        }

        /* Depuis quand */

        $bornage = $_SESSION['uti_timbre'];
        $portee = 'une_semaine';
        $portee_lib = 'Montrer depuis une semaine';
        $portee_titre = 'depuis la connexion précédente';
        if (array_key_exists('une_semaine', $_POST)) {
            $auj = new DateTime();
            $usm = new DateInterval('P7D');
            $auj->sub($usm);
            $bornage = $auj->format('Y-m-d');
            $portee = 'un_mois';
            $portee_lib = 'Montrer depuis un mois';
            $portee_titre = 'depuis une semaine';
        } else {
            if (array_key_exists('un_mois', $_POST)) {
                $auj = new DateTime();
                $umo = new DateInterval('P1M');
                $auj->sub($umo);
                $bornage = $auj->format('Y-m-d');
                $portee = 'connexion';
                $portee_lib = 'Montrer depuis la dernière connexion';
                $portee_titre = 'depuis un mois';
            }
        }

        /* Nouveautés */

        $req = "select a.app_timbre as timbre, 'application '||a.app_nom as obj, '#A52A2A' as coul
            from applications a
            where a.app_timbre>$1".$cond_eqp."
            UNION
            select c.chn_timbre as timbre, 'chaîne '||c.chn_nom as obj, '#7F7F7F' as coul
            from chaines c
                join applications a on a.app_id=c.app_id
            where c.chn_timbre>$1".$cond_eqp."
            UNION
            select distinct p.pro_timbre as timbre,
                'processus '||p.pro_nom||' ('||p.pro_version||')' as obj, '#0000FF' as coul
            from processus p
                join liens l on l.pro_id=p.pro_id
                join membrex m on m.mbx_id=l.mbx_id
                join chaines c on c.chn_id=m.chn_id
                join applications a on a.app_id=c.app_id
            where p.pro_timbre>$1".$cond_eqp."
            UNION
            select distinct q.pln_timbre as timbre,
                'mise au plan du processus '||p.pro_nom||' du '||
                    to_char(q.pln_debut, 'DD/MM/YYYY')||' au '||
                    to_char(q.pln_fin, 'DD/MM/YYYY') as obj, '#A020F0' as coul
            from plan q
                join processus p on p.pro_id=q.pro_id
                join liens l on l.pro_id=p.pro_id
                join membrex m on m.mbx_id=l.mbx_id
                join chaines c on c.chn_id=m.chn_id
                join applications a on a.app_id=c.app_id
            where q.pln_timbre>$1".$cond_eqp."
            UNION
            select distinct r.rea_timbre as timbre,
                'realisé par '||e.esi_nom||' sur processus '||p.pro_nom||
                    (case
                        when r.rea_fin is not null and r.rea_statut='T'
                        then ' : exécuté du '||to_char(r.rea_debut, 'DD/MM/YYYY')||
                            ' au '||to_char(r.rea_fin, 'DD/MM/YYYY')||' (terminé)'
                        when r.rea_fin is not null and r.rea_statut='A'
                        then ' : exécuté du '||to_char(r.rea_debut, 'DD/MM/YYYY')||
                            ' au '||to_char(r.rea_fin, 'DD/MM/YYYY')||' (en abort)'
                        when r.rea_fin is null and r.rea_debut is not null
                        then ' : en cours depuis le '||to_char(r.rea_debut, 'DD/MM/YYYY')
                        when r.rea_debut is null
                        then ' : réinitialisé pour la mise au plan du '||
                            to_char(q.pln_debut, 'DD/MM/YYYY')
                        else ''
                    end) as obj,
                (case
                    when r.rea_statut='A' then '#FF0000'
                    when r.rea_statut='T' then '#30BA2B'
                    else '#FFA500'
                end) as coul
            from realise r
                join esi e on e.esi_id=r.esi_id
                join plan q on q.pln_id=r.pln_id
                join processus p on p.pro_id=q.pro_id
                join liens l on l.pro_id=p.pro_id
                join membrex m on m.mbx_id=l.mbx_id
                join chaines c on c.chn_id=m.chn_id
                join applications a on a.app_id=c.app_id
            where r.rea_timbre>$1".$cond_eqp.$cond_esi."
            order by timbre desc, obj";
        $res = pg_query_params($db, $req, array($bornage));

        if (pg_num_rows($res) > 0) {
            while ($lu = pg_fetch_row($res)) {
                $nouveautes .= '<p>'.jma(substr($lu[0], 0, 10)).' '
                    .substr($lu[0], 11, 5).' &bull; <span style="color:'
                    .$lu[2].'">'.$lu[1].'</span></p>';
            }
        } else {
            if ($force_affichage == 'OUI') 
                $nouveautes .= '<p class="info">Pas de nouveauté sur la période.</p>';
        }
    }
?>
