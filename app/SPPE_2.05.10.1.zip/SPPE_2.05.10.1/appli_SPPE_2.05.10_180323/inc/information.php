<?php
?>
<div id="accueil">
    <h4>Aide de l'application SPPE</h4>
    <p>
        &bull; Veuillez vous identifier, en haut, à droite de cette page.
    </p>
    <p>
        &bull; Une fois connecté, positionnez les filtres ci-dessus à votre convenance.
        Ils conditionnent l'affichage des calendriers du prévisionnel et du réalisé.
    </p>
    <p>
        &bull; Une fois les filtres définis, cliquez le bouton <strong>Enrgt. préf.</strong>
        pour les conserver en mémoire d'une session à l'autre.
    </p>
    <p> &bull; Cliquez sur le logo ou sur le titre SPPE pour revoir cet écran après la connexion.</p>
    <hr>
    <p> &bull; Quelques recommandations dans l'utilisation de SPPE : </p>
    <p> &rarr; SPPE est conçu pour fonctionner avec les navigateurs standards de la DGFIP : Mozilla Firefox et Internet Explorer (version 8 seulement). Son comportement sera aléatoire avec les autres navigateurs.</p>
    <p> &rarr; Appuyez sur la touche F11 pour basculer en plein écran et vice-versa.</p>
    <p> &rarr; Vous pouvez zoomer en appuyant sur CONTROL et '+', réduire avec CONTROL et '-', revenir à l'affichage standard avec CONTROL + '0' (zéro). Avec le pavé numérique, c'est plus facile. Le zoom fonctionne mieux sous Firefox.</p>
    <p> &rarr; Évitez d'utiliser la touche retour arrière de votre navigateur. Privilégiez le menu SPPE.</p>
    <p> &rarr; La <em>Gestion des dates</em> est réservée aux utilisateurs ayant les droits CQMF.</p>
    <p> &rarr; Le <em>Référentiel BE</em> est disponible quand vous avez sélectionné une équipe dans le filtre <em>Application</em> et que vous avez les droits CQMF.</p>
    <p> &rarr; L'extraction du plan (<em>Référentiel BE</em>) nécessite LibreOffice v3.6.5.2, version officielle de la DGFIP. Ça ne fonctionne pas avec OpenOffice v3.1.1, ancienne version utilisée à la DGFIP.</p>
    <hr>
    <p style="color:red; font-size:smaller; margin-top:1em;">
        Le bureau SI-2A DME fournit les comptes utilisateurs.
    </p>
</div>
