<?php

    /* Constantes */

    define('VERSION', 'Version sppe-2.5<br>du 06 juin 2017');
    define('DATE_VERSION','201706061447');
    define('SPPE_MODE_DEBUG', true);
    define('LEONARD', ' http://esi44m.intranet.dgfip/outils/LEONARDeux/?version=');
    define('DATE_PASSE', '1900-01-01');
    define('DATE_FUTUR', '2900-01-01');

    
    // constantes des niveaux d'habilitation
    define('HABIL_GESTION_DATE',4);
    define('HABIL_REFERENTIEL_BE',16);
    define('HABIL_REALISE_MANUEL',64);
// fin
