<?php

    /* Initialisations */

    require_once __DIR__ .'/type_serveur.php';
    require_once __DIR__ .'/commun.php';
    require __DIR__ .'/../sql/sql.php';

    setlocale(LC_TIME, array('fr_FR.utf8', 'fr_FR', 'fr'));
    
    /* Connexion à la base de données */

    require __DIR__ .'/pg_connect.php';

    if ($db === false) {
        $erreur = 2;
    }

    /* Variables de session */
    sess('uti_id', '0');                    // identifiant utilisateur
    sess('uti_uid_fonctionnel', '0');       // identifiant utilisateur dans l'annuaire
    sess('uti_nom', '');                    // nom utilisateur
    sess('uti_prenom', '');                 // prénom utilisateur
    sess('uti_droits', array());            // droits de l'utilisateur (voir sppe_base.sql)
    sess('uti_admin', '');                 	// definit si l'utilisateur est administrateur SPPE
    sess('uti_timbre', DATE_FUTUR);         // timbre connexion utilisateur
    
    sess('esi_id', '0');                    // ESI de l'utilisateur
    sess('serv_id', '0');                   // Service de l'utilisateur

    sess('sel_dom', '0');                   // domaine sélectionné
    sess('sel_esi', $_SESSION['esi_id']);   // ESI sélectionné
    sess('sel_app', '0');                   // application ou équipe sélectionnée
    sess('sel_chn', '0');                   // chaîne sélectionnée
    sess('sel_pro', '0');                   // processus sélectionné

    /* suivi simplifié */
    if (array_key_exists('sel_pro', $_GET) and !array_key_exists('sel_sui', $_GET)) {
        $_SESSION['sel_sui'] = '';
    } else {
        sess('sel_sui', 'on');
    }

    /* à venir seulement */
    if (array_key_exists('sel_pro', $_GET) and !array_key_exists('sel_ave', $_GET)) {
        $_SESSION['sel_ave'] = '';
    } else {
        sess('sel_ave', '');
    }
    
    sess('sel_cal', date('Y-m'));           // période sélectionnée
    
    /* Prise en compte des préférences utilisateur */
    
    require __DIR__ .'/preferences.php';

// fin
