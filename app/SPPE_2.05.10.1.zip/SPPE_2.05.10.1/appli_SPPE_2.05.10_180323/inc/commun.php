<?php

    /* Constantes */

    require __DIR__ .'/constantes.php';

    /* Fonctions */

    $Selected = null;   // Dernière valeur sélectionnée d'une option marquée selected

    /* Initialisation d'une variable de session ----------------------------------------------------
     * 		$var = variable littérale
     * 		$def = valeur par défaut */
    function sess($var, $def) {
    	if (array_key_exists($var, $_GET)) {
    		$_SESSION[$var] = $_GET[$var];
    	}elseif (array_key_exists($var, $_POST)) {
    		$_SESSION[$var] = $_POST[$var];
    	} else {
    		if (!array_key_exists($var, $_SESSION)) {
    			$_SESSION[$var] = $def;
    		}
    	}
    }
    
    /* Dates prévisionnelles -----------------------------------------------------------------------
     * Affichage des dates prévisionnelles
     * 		$lu : enregistrement
     * --> retourne le paragraphe HTML */
    function dates_previsionnelles($lu) {

        $html = '';

        if (array_key_exists('pln_id', $lu) and $lu['pln_id'] > 0) {

            $confirm = ($lu['pln_confirm'] == 't' ? '' : 'non ').'confirmées';
            if (($lu['pln_debut'] == $lu['pln_debut_calc']) and
                ($lu['pln_fin'] == $lu['pln_fin_calc'])) {
                $statut = 'calculées';
                if ($lu['pln_confirm'] == 't') {
                    $qui = ($lu['uti_id'] == null ? 'dates sûres' : $lu['uti_nom']).' - ';
                } else {
                    $qui = '';
                }
            } else {
                $statut = 'manuelles';
                $qui = $lu['uti_prenom'].' '.$lu['uti_nom'].' - ';
            }

            $html = '<p id="dp">
                &bull; Dates prévisionnelles : début = <strong>'.jma($lu['pln_debut'])
                .'</strong> &bull; fin = <strong>'.jma($lu['pln_fin'])
                .'</strong> &bull; butoir = <strong>'.jma($lu['pln_butoir'])
                .'</strong> &bull; <em>'.$statut.' - '.$confirm.' - '
                .$qui.jma($lu['pln_timbre']).'</em>
                </p>';
        }

        return $html;
    }

    /* erreur --------------------------------------------------------------------------------------
     * Prépare un message d'erreur
     * $msg = message
     * retourne le message en HTML */
    function erreur($msg) {
        return "<p class=\"erreur\">".$msg."</p>\n";
    }

    /* info ----------------------------------------------------------------------------------------
     * Prépare un message d'information
     * $msg = message
     * retourne le message en HTML */
    function info($msg) {
        return "<p class=\"info\">".$msg."</p>\n";
    }

    /* jma -----------------------------------------------------------------------------------------
     * Transforme une date PostgreSQL (ISO) au format JJ/MM/AAAA pour affichage "human friendly"
     * $pgdate : date à transformer
     * --> retourne la date au format JJ/MM/AAAA */

    function jma($pgdate) {

        $rc = '-';

        if ($pgdate == null) {
            $rc = '-';
        } else {
            if (strlen($pgdate) > 9) {
                $rc = substr($pgdate, 8, 2).'/'.substr($pgdate, 5, 2).'/'.substr($pgdate, 0, 4);
            }
        }

        return $rc;
    }

    /* nullorid ------------------------------------------------------------------------------------
     * $clef : clef d'une variable de session
     * $integer : à transformer en entier si vrai (par défaut)
     * Renvoi null si $_SESSION[$clef] = 0 ou '0', sa valeur sinon */
    function nullorid($clef, $integer=true) {

        $rc = null;

        if (array_key_exists($clef, $_SESSION)) {
            $v = $_SESSION[$clef];
            if ($integer) {
                if ($v != '0' or intval($v, 10) != 0) {
                    $rc = intval($v, 10);
                }
            } else {
                if ($v != '0') {
                    $rc = $v;
                }
            }
        }
        return $rc;
    }

    /* occurrence_suivante -------------------------------------------------------------------------
     * Occurrence suivante d'un processus présentant plusieurs occurrence pour la période
     * $proc : tableau des processus courants
     * $realise : vrai si réalisé
     * $courant : date courante
     * --> retourne la date de l'occurrence suivante
     */
    function occurrence_suivante(&$proc, $realise, $courant) {

        $rc = DATE_FUTUR;

        if (count($proc) > 0) {
            $p = $proc[0]['pln_debut'];
            if ($realise) {
                $r = $proc[0]['rea_debut'];
                if (is_null($r) or $r > $p) {
                    $rc = $p;
                } else {
                    $rc = $r;
                }
            } else {
                $rc = $p;
            }
            if ($rc < $courant) {
                $rc = $courant;
            }
        }

        return $rc;
    }

    /* option --------------------------------------------------------------------------------------
     * $lib : libellé affiché
     * $vlr : valeur associée
     * $vlc : valeur comparée
     * $sty : style
     * -> retourne une option au sens HTML */

    function option($lib, $vlr, $vlc, $sty='') {

        global $Selected;

        $style = '';
        if ($sty) $style = ' style="'.$sty.'"';
        $rc = '<option value="'.$vlr.'" '.$style;
        if ($vlr == $vlc) {
            $rc .= ' selected';
            $Selected = $vlc;
        }
        $rc .= '>'.$lib."</option>\n";

        return $rc;
    }

    /* options -------------------------------------------------------------------------------------
     * $res : ressource SQL à deux champs (id, lib)
     * $vlc : valeur comparée
     * $tous : libellé pour tous ou rien
     * $groupe : libellé de groupe ou rien
     * -> retourne une option au sens HTML */

    function options($res, $vlc, $tous='', $groupe='') {

        global $Selected;

        $rc = '';
        $Selected = '0';

        if ($tous) {
            if ($vlc == 0) {
                $rc = '<option value="0" selected>'.$tous."</option>\n";
            } else {
                $rc = '<option value="0">'.$tous."</option>\n";
            }
        }

        if ($groupe) {
            $rc .= '<optgroup label="'.$groupe."\">\n";
        }

        while ($lu = pg_fetch_row($res)) {
            $rc .= option($lu[1], $lu[0], $vlc);
        }

        if ($groupe) {
            $rc .= "</optgroup>\n";
        }

        return $rc;
    }

    /* pg_date -------------------------------------------------------------------------------------
     * transforme une date jj/mm/aaaa en date PostgreSQL (ISO)
     * $d : date
     * retourne la date au format 'AAAA-MM-JJ' ou null */
    function pg_date($d) {

        $rc = null;

        $ds = str_replace('.', '/', $d);
        $dx = str_replace('-', '/', $ds);
        $x = explode('/', $dx);
        if (count($x) == 3) {
            $rc = $x[2].'-'.str_pad(intval($x[1], 10), 2, '0', STR_PAD_LEFT)
                .'-'.str_pad(intval($x[0], 10), 2, '0', STR_PAD_LEFT);
        }

        return $rc;
    }

    /* prepare_processus ---------------------------------------------------------------------------
     * Préparation des processus, du suivi simplifié
     * et des processus présentant plusieurs occurrences
     * $processus : tableau des processus à remplir
     * $res : ressource base de donnée
     */
    function prepare_processus(&$processus, $res) {
        $i = -1;
        $clefs_suivi = array();
        while ($lu = pg_fetch_assoc($res)) {
            if ($lu['tri1'] == 1) {
                /* suivi normal */
                $i++;
                $processus[$i] = array();
                array_push($processus[$i], $lu);
            } else {
                /* suivi simplifié */
                $id = $lu['pro_id'];
                if (array_key_exists($id, $clefs_suivi)) {
                    array_push($processus[$clefs_suivi[$id]], $lu);
                } else {
                    $i++;
                    $processus[$i] = array();
                    array_push($processus[$i], $lu);
                    $clefs_suivi[$id] = $i;
                }
            }
        }
    }

    /* processus_recent ----------------------------------------------------------------------------
     * Processus récemment mis-à-jour
     * $auj : date système (objet DateTime)
     * $iso : idem au format ISO
     * $lu : mise au plan courante d'un processus
     * $proc : tableau des mises au plan suivante d'un processus
     * $age : ancienneté de la modification du processus
     * --> retourne vrai si le panneau doit être affiché
     */
    function processus_recent($auj, $iso, $lu, $proc, $age) {

        $rc = false;

        if ($age < 1) {

            $deb = $lu['pln_debut'];
            $fin = $lu['pln_fin'];
            $hor = $lu['pln_timbre'];
            $tot = count($proc);
            $idx = 0;

            do {
                $ddt = new DateTime($deb);
                $hdt = new DateTime($hor);
                $dif = intval($auj->diff($ddt)->format('%a'), 10);
                $dta = intval($auj->diff($hdt)->format('%a'), 10);
                $rc = ($dta < 1 and ($dif < 7 or $deb < $iso) and $fin >= $iso);
                // echo $dta.' '.$dif.' '.$deb.' '.$iso.' '.$fin.' '.$rc.'<br>';
                $encore = ($idx < $tot);
                if ($encore) {
                    $deb = $proc[$idx]['pln_debut'];
                    $fin = $proc[$idx]['pln_fin'];
                    $hor = $proc[$idx]['pln_timbre'];
                    $idx++;
                }
                unset($ddt);
                unset($hdt);
            } while ($rc == false and $encore);
        }
        return $rc;
    }

    /* rgb -----------------------------------------------------------------------------------------
     * Extraction d'une couleur RGB à partir d'une couleur hexadécimale
     * $coul : couleur 'r', 'g' ou 'b'
     * $hexa : couleur hexadecimale
     * retourne le code couleur entier
     */

    function rgb($coul, $hexa) {
        $pos = strpos('rgb', $coul) * 2 + 1;
        $rc = hexdec(substr($hexa, $pos, 2));
        return $rc;
    }

    /* souligne_rouge ------------------------------------------------------------------------------
     * Souligné rouge si modification de la mise au plan depuis moins d'un mois
     * $ref : date de référence
     * $dur : durée (un mois)
     * $auj : aujourd'hui (DateTime)
     * --> retourne le statut en texte
     */
    function souligne_rouge($ref, $dur, $auj) {
        $rc = '';
        $d = new DateTime($ref);
        if (intval($auj->diff($d)->format('%a'), 10) < $dur)
            $rc = 'souligne_rouge';
        return $rc;
    }

    /* identificationAgent -----------------------------------------------------------------------------------------
     * Extraction de l'uidFonctionnel de l'Agent depuis l'annuaire LDAP DGFiP
     * 
     * 		$dnUtilisateur : dn de l'utilisateur connecté 
     */
    
    function identificationAgent($dnUtilisateur) {
    	require __DIR__ .'/class.ldap.php';
    	
    	$ldap = new LDAP();
    	$ldap->basedn = 'ou=personnes,ou=dgfip,ou=mefi,o=gouv,c=fr';
    	// 		exemple de dn utilisateur => 'uid=1024358107-0,ou=personnes,ou=dgfip,ou=mefi,o=gouv,c=fr';
    	$ldap->cat($dnUtilisateur); //lecture des informations de la personne dans l'annuaire
    	$donneesLdapUtilisateur=$ldap->fetch(); // mise en tableau des valeurs

    	$uidFonctionnel = '';
    	if (!empty($donneesLdapUtilisateur)){
    		$uidFonctionnel = $donneesLdapUtilisateur['uidFonctionnel'][0];
    	}
    	
    	return $uidFonctionnel;
    }

    /* recupereDroits -----------------------------------------------------------------------------------------
     * Lit et renvoi les droits de l'utilisateur par domaine
     *
     * 		$idUtilisateur	: identifiant de l'utilisateur connecté
     * 		$idService		: identifiant du service de l'utilisateur
     */
    function recupereDroits($idUtilisateur,$idService){
    	$droits = array();
    	
    	// recupère les profils du service
    	$req = 'SELECT dom_id, profil
    			FROM attacher a
    			WHERE serv_id=$1';
    	$res = sql_gen($req,array($idService));
    	while ($lu = pg_fetch_assoc($res)){
    		$droits[$lu['dom_id']] = $lu['profil'];
    	}
    	// recupère les habilitations particulières de l'utilisateur
    	$req = 'SELECT dom_id, habilitation
    			FROM habiliter
    			WHERE uti_id=$1';
    	$res = sql_gen($req,array($idUtilisateur));
    	while ($lu = pg_fetch_assoc($res)){
    		$droits[$lu['dom_id']] = $lu['habilitation'];
    	}
    	
    	return $droits;
    }
    /* estAdmin -----------------------------------------------------------------------------------------
     * Verification de la qualité d'administrateur SPPE de l'utilisateur
     *
     */
    function estAdmin(){
    	return $_SESSION['uti_admin']=='t';
    }
    /* estHabil -----------------------------------------------------------------------------------------
     * Verification de l'habilitation d'un utilisateur pour un domaine donné
     *
     *		$valeur		: habilitation demandée
     *		$idDomaine	: identifiant du domaine pour lequel on veut savoir si l'utilisateur est habilité
     */
    function estHabil($valeur,$idDomaine=NULL){
    	$habil = false;
    	if (is_null($idDomaine)){
    		foreach ($_SESSION['uti_droits'] as $valeurHabil){
    			$habil = ($habil || ($valeurHabil & $valeur));
    		}
    	}else{
    		if (!empty($_SESSION['uti_droits'])){
    			$habil = ($_SESSION['uti_droits'][$idDomaine] & $valeur);
    		}
    	}
    	return (estAdmin() || $habil);
    }
    
    
    function debug($objet){
    	echo '<p><pre style="font-size:1.2em;background-color:#FFA500;">'; print_r($objet); echo '</pre></p>';
    }

    /* initialisationPage -------------------------------------------------------------------------------
     * Initialisation des variables pour le chargement de la page
     *
     *		$pageACharger		: code de la page à charger
     */
    
    function initialisationPage($pageACharger=''){
    	$parametrageRetour = array();
    	
    	switch ($pageACharger){
    		case 'realise':
    			$parametrageRetour[] = 'grille';
    			$parametrageRetour[] = 'cmd_rea';
    			$parametrageRetour[] = 'Calendrier prévisionnel &amp; réalisé';
    			$parametrageRetour[] = true;
    			$parametrageRetour[] = false;
    			$parametrageRetour[] = '';
    			break;
    		case 'recherche':
    			$parametrageRetour[] = 'gesdates';
    			$parametrageRetour[] = 'cmd_rch';
    			$parametrageRetour[] = '';
    			$parametrageRetour[] = false;
    			$parametrageRetour[] = true;
    			$parametrageRetour[] = 'recherche';
    			break;
    		case 'dates':
    			$parametrageRetour[] = 'gesdates';// $page
    			
    			if (isset($_SESSION) && array_key_exists('uti_droits', $_SESSION) && estHabil(HABIL_GESTION_DATE)) {
    				$parametrageRetour[] = 'cmd_ges';			// $cmdb
    				$parametrageRetour[] = '';					// $titre_tableau
    				$parametrageRetour[] = false;				// $realise
    				$parametrageRetour[] = false;				// $recherche_seulement
    				$parametrageRetour[] = 'dates';				// $action
    			}else{
    				$parametrageRetour[] = 'cmd_rch';				// $cmdb
    				$parametrageRetour[] = '';						// $titre_tableau
    				$parametrageRetour[] = false;					// $realise
    				$parametrageRetour[] = true;					// $recherche_seulement
    				$parametrageRetour[] = 'recherche';				// $action
    			}
    			break;
    		case 'aide':
    			$parametrageRetour[] = 'information';	// $page
    			$parametrageRetour[] = 'cmd_help';		// $cmdb
    			$parametrageRetour[] = '';				// $titre_tableau
    			$parametrageRetour[] = false;			// $realise
    			$parametrageRetour[] = false;			// $recherche_seulement
    			$parametrageRetour[] = '';				// $action
    			break;
    		case 'nouveaute':
    			$parametrageRetour[] = 'aff_nouveautes';	// $page
    			$parametrageRetour[] = 'cmd_pre';		// $cmdb
    			$parametrageRetour[] = 'Calendrier prévisionnel';				// $titre_tableau
    			$parametrageRetour[] = false;			// $realise
    			$parametrageRetour[] = false;			// $recherche_seulement
    			$parametrageRetour[] = '';				// $action
    			break;
    		case 'pdf':
    			$parametrageRetour[] = 'pdf';	// $page
    			$parametrageRetour[] = '';		// $cmdb
    			$parametrageRetour[] = '';				// $titre_tableau
    			$parametrageRetour[] = false;			// $realise
    			$parametrageRetour[] = false;			// $recherche_seulement
    			$parametrageRetour[] = '';				// $action
    			break;
    		case 'csv':
    			$parametrageRetour[] = 'csv';	// $page
    			$parametrageRetour[] = '';		// $cmdb
    			$parametrageRetour[] = '';				// $titre_tableau
    			$parametrageRetour[] = false;			// $realise
    			$parametrageRetour[] = false;			// $recherche_seulement
    			$parametrageRetour[] = '';				// $action
    			break;
    		case 'admin':
    			$parametrageRetour[] = 'admin';	// $page
    			$parametrageRetour[] = '';		// $cmdb
    			$parametrageRetour[] = '';				// $titre_tableau
    			$parametrageRetour[] = false;			// $realise
    			$parametrageRetour[] = false;			// $recherche_seulement
    			$parametrageRetour[] = '';				// $action
    			break;
    		case 'prevision':
    		default :
    			$parametrageRetour[] = 'grille';					// $page : page par défaut
    			$parametrageRetour[] = 'cmd_pre';					// $cmdb : la page d'accueil est la page de prévisionnel
    			$parametrageRetour[] = 'Calendrier prévisionnel';	// $titre_tableau
    			$parametrageRetour[] = false;						// $realise
    			$parametrageRetour[] = false;						// $recherche_seulement
    			$parametrageRetour[] = '';							// $action
    			break;
    	}
    	return $parametrageRetour;
    }
    
    /* getPost -----------------------------------------------------------------------------------------
     * Renvoie la valeur du paramètre $nomParam présent dans $_GET ou dans $_POST, un chaine vide sinon
     *
     */
    function getPost($nomParam){
    	if (!empty($_GET[$nomParam])){
    		$valeurRetour = $_GET[$nomParam];
    	}elseif(!empty($_POST[$nomParam])){
    		$valeurRetour = $_POST[$nomParam];
    	}else{
    		$valeurRetour = '';
    	}
    	return $valeurRetour;
    }
    
// fin
