<?php

    require_once 'ferie.php';

    /* ---------------------------------------------------------------------------------------------
     * Cellule d'un calendrier
     *
     * Appel : new Cellule(date initiale, nombre de jours)
     *
     * Construit une cellule de tableau calendrier avec les classes associées
     * ------------------------------------------------------------------------------------------ */

    class Cellule {

        /* Attributs ============================================================================ */

        private $classes;   // Classes associées à la cellule
        private $title;     // Title associé à la cellule
        private $curseur;   // Curseur entier des jours fériés
        private $feries;    // Tableau binaire de jours fériés
        private $ident;     // ID de la cellule
        private $domaine;	// domaine associé (FE,FP,COP,...)
        private $journee;   // Date du jour associé à la cellule
        private $initial;   // Date initiale au format ISO
        private $jours;     // Nombre de jours à traiter
        private $un_jour;   // Interval d'un jour
        private $ce_jour;   // Date du jour en ISO
        private $pasti='';  // Pastille absente par défaut

        /* Méthodes ============================================================================= */

        /* Constructeur
         * $diso : date initiale au format ISO
         * $jours : nombre de jours traités */
        function __construct($diso, $jours) {

            /* Création de l'objet DateTime associé à la cellule */
            $this->journee = new DateTime($diso);

            /* Définition de l'interval d'un jour */
            $this->un_jour = new DateInterval('P1D');

            /* Préparation des jours fériés pour la période entière */
            $this->feries = feries($this->journee, $jours);

            /* Conservation du nombre de jours initial */
            $this->jours = $jours;

            /* Conservation de la date initiale pour permettre la réitération de la période */
            $this->initial = $diso;

            /* Aujourd'hui */
            $this->ce_jour = date('Y-m-d');

            /* Initialisation de la période */
            $this->raz();
        }

        /* classe ----------------------------------------------------------------------------------
         * ajoute une classe à la cellule
         * $c : nom de la classe */
        function classe($c) {
            if ($c){
            	$this->classes .= $c.' ';
            }
        }

        /* csv -------------------------------------------------------------------------------------
         * prépare les données pour le fichier CSV
         * $contenu : contenu de la cellule */
        function csv($contenu) {

            if ($this->classes == '') {
                if ($this->feries{$this->curseur} == '0') $c = 'ferie';
                else $c = 'vide';
            } else $c = trim($this->classes);

            $csv = $c.':'.$contenu;

            return $csv;
        }

        /* etat ------------------------------------------------------------------------------------
         * retourne l'état des classes */
        function etat() {
            return $this->classes;
        }

        /* fabrique --------------------------------------------------------------------------------
         * fabrique la cellule HTML
         * $contenu : contenu de la cellule
         * $tag : tag HTML utilisé (td par défaut)
         * $fer : mise en évidence des jours fériés */
        function fabrique($contenu, $tag='td', $fer=true) {

            $f = '';
            if (($this->feries{$this->curseur} == '0') and $fer){
            	$f = 'ferie';
            }
            $c = trim($this->classes.$f);

            if ($this->iso() == $this->ce_jour){
            	$c = trim($c.' aujourdhui2');
            }
            
            $i = trim($this->ident);
            $d = trim($this->domaine);
            $t = trim($this->title);
            $html = '<'.$tag
                .($i != '' ? ' id="'.$i.'"' : '')
                .($c != '' ? ' class="'.$c.'"' : '')
                .($d != '' ? ' data-domaine="'.$d.'"' : '')
                .' data-jour="'.$this->journee->format('j').'"'
                .($t != '' ? ' title="'.$t.'"' : '')
                .'>'.$contenu.$this->pasti.'</'.$tag.'>';
            $this->pasti = '';
            return $html;
        }

        /* id --------------------------------------------------------------------------------------
         * ajoute un id
         * $i : id */
        function id($i) {
            if ($i){
            	$this->ident = $i;
            }
        }
        /* domaine --------------------------------------------------------------------------------------
         * ajoute un domaine
         * $dom : domaine */
        function domaine($dom) {
            if ($dom){
            	$this->domaine = $dom;
            }
        }

        /* iso -------------------------------------------------------------------------------------
         * retourne le jour de la cellule au format AAAA-MM-JJ */
        function iso() {
            return $this->journee->format('Y-m-d');
        }

        /* jour ------------------------------------------------------------------------------------
         * retourne l'objet DateTime associé à la cellule */
        function jour() {
            return $this->journee;
        }

        /* ok --------------------------------------------------------------------------------------
         * indique s'il y a encore une journée à traiter */
        function ok() {
            return ($this->curseur < $this->jours);
        }

        /* raz -------------------------------------------------------------------------------------
         * réinitialisation de l'objet à la date initiale */
        function raz() {
            $this->classes = '';
            $this->title = '';
            $this->ident = '';
            $this->curseur = 0;
            $this->journee->setDate(
                intval(substr($this->initial, 0, 4), 10),
                intval(substr($this->initial, 5, 2), 10),
                intval(substr($this->initial, 8, 2), 10)
            );
        }

        /* pastille --------------------------------------------------------------------------------
         * demande l'ajout d'une pastille rouge pour marquer l'abort au cours du réalisé
         * $etat : état à considéré (abort ou hors prévisionnel)
         */
        function pastille($etat) {
            $this->pasti = '<span class="pastille_'
                .($etat == SPPE_ETAT_ABORT ? 'rouge' : 'noire').'">&bull;</span>';
        }

        /* suivant ---------------------------------------------------------------------------------
         * se place sur le jour suivant */
        function suivant() {

            /* Jour suivant */
            $this->journee->add($this->un_jour);
            $this->curseur++;

            /* RAZ */
            $this->classes = '';
            $this->title = '';
            $this->ident = '';
        }

        /* title -----------------------------------------------------------------------------------
         * ajoute un title à la cellule
         * $t : contenu du title */
        function title($t) {
            if ($t) $this->title .= str_replace('"', "'", $t).' ';
        }
    }

?>
