<?php
	/* Partie d'administration réservée au CQ */
?>
<h6 id="h6_admin_gestionDate">Administration réservée au centre de qualification</h6>
<div id="admin_gestionDate"  class="moduleAdmin">
	<form action="" method="POST">
		<input type="hidden" name="module" value="admin_gestionDate" />
<?php
	/* Détection des chevauchements dans le plan */
	$req = 'SELECT p.pro_nom, q.pln_debut, q.pln_fin
			FROM plan q
			JOIN processus p ON p.pro_id=q.pro_id
			WHERE (
				SELECT COUNT(b.*)
				FROM plan b
				WHERE b.pln_id!=q.pln_id
				AND b.pro_id=q.pro_id
				AND (
					(q.pln_debut between b.pln_debut and b.pln_fin)
					OR
					(q.pln_fin between b.pln_debut and b.pln_fin)
				)
			)>0';
	$res = pg_query($db, $req);
	$nb = pg_num_rows($res);

	if ($nb) {
?>
		<p class="erreur">Chevauchements détectés dans la mise au plan</p>
		<table style="width:auto;">
			<thead>
				<tr>
					<th>Processus</th>
					<th>Début</th>
					<th>Fin</th>
				</tr>
			</thead>
			<tbody>
<?php
			while ($lu = pg_fetch_assoc($res)) {
?>
				<tr>
					<td><?php echo $lu['pro_nom'];?></td>
					<td><?php echo jma($lu['pln_debut']);?></td>
					<td><?php echo jma($lu['pln_fin']);?></td>
				</tr>
<?php
			}
?>
			</tbody>
		</table>
<?php
	}else{
?>
		<p class="info">Pas de chevauchements détectés dans la mise au plan</p>
<?php
	}
?>
		<p class="notes">Cette option affiche les éventuels processus pour lesquels il existe des chevauchements dans les mises au plan.</p>
		<hr>
<?php
	/* Suppression d'un processus */
	$pro_nom = '';
	if (array_key_exists('acq_suppr_proc', $_POST)) {
		if ($_POST['acq_suppr_conf'] == 'OUI') {
			$pro_nom = trim($_POST['acq_suppr_nom']);
			if (strlen($pro_nom) > 0) {
				/* Recherche du processus */
				$req = 'SELECT pro_id FROM processus WHERE pro_nom=$1';
				$res = pg_query_params($db, $req, array($pro_nom));
				if ($lu = pg_fetch_row($res)) {
					/* Recherche de réalisé pour le processus */
					$pro_id = $lu[0];
					$req = 'SELECT COUNT(r.*)
							FROM realise r 
							JOIN plan p ON p.pln_id=r.pln_id
							WHERE p.pro_id=$1';
					$res = pg_query_params($db, $req, array($pro_id));
					$lu = pg_fetch_row($res);
					if ($lu[0]) {
						echo '<p class="erreur">Impossible de supprimer le processus '.$pro_nom.' car du réalisé existe</p>';
					}else{
						/* Suppression */
						$ok = false;
						$del = 'DELETE FROM ';
						$sql = ' WHERE pro_id=$1';
						$prm = array($pro_id);
						pg_query($db, 'begin');
						if (pg_query_params($db, $del.'recalcul'.$sql, $prm)) {
							if (pg_query_params($db, $del.'ressort'.$sql, $prm)) {
								if (pg_query_params($db, $del.'liens'.$sql, $prm)) {
									if (pg_query_params($db, $del.'liste'.$sql, $prm)) {
										if (pg_query_params($db, $del.'plan'.$sql, $prm)) {
											if (pg_query_params($db, $del.'processus'.$sql, $prm)) {
												$ok = pg_query($db, 'commit');
											}
										}
									}
								}
							}
						}
						if ($ok) {
							echo '<p class="info">Le processus '.$pro_nom.' est supprimé</p>';
						}else{
							echo '<p class="erreur">La suppression du processus '.$pro_nom.' a échoué</p>';
							pg_query($db, 'rollback');
						}
						$pro_nom = '';
					}
				}else{
					echo '<p class="erreur">Le processus indiqué n\'existe pas</p>';
				}
			}
		}
	}
?>
		<p>
			<input type="text" name="acq_suppr_nom" id="acq_suppr_nom" value="<?php echo $pro_nom;?>">
			<input type="hidden" name="acq_suppr_conf" id="acq_suppr_conf" value="NON">
			&nbsp;
			<input type="submit" name="acq_suppr_proc" id="acq_suppr_proc" value="Supprimer le processus" style="width:15em">
		</p>
		<p class="notes">
			Cette option permet de supprimer un processus de SPPE.<br>Elle fonctionne seulement pour les processus pour lesquels aucun réalisé n'existe.
		</p>
<?php
	/* Verrouillage du report N+1 */
	if (array_key_exists('acq_report', $_POST)) {
		$req = "UPDATE statut SET
				valeur=(CASE WHEN valeur='on' THEN 'off' ELSE 'on' END)
				WHERE objet='report'";
		$res = pg_query($db, $req);
		$lu = pg_fetch_row($res);
	}
	$etat_report = 'Cacher les boutons relatifs au report N+1';
	$req = "select valeur from statut where objet='report'";
	$res = pg_query($db, $req);
	if ($lu = pg_fetch_row($res)){
		if ($lu[0] == 'off')
			$etat_report = 'Montrer les boutons relatifs au report N+1';
	}else{
		$req = "INSERT INTO statut (objet, valeur) VALUES ('report', 'on')";
		pg_query($db, $req);
	}
?>
		<hr>
		<p>
			<input type="submit" name="acq_report" id="acq_report" value="<?php echo $etat_report;?>" style="width:25em">
		</p>
		<p class="notes">Cette option suspend ou restaure l'affichage des boutons relatifs au report N+1 dans la gestion des dates.</p>
<?php
	/* Journal de chargement des processus */
?>
		<hr>
		<p>
			<input type="submit" name="acq_journal" id="acq_journal" value="Afficher le journal de chargement des processus" style="width:25em">
		</p>
	</form>
</div>
<?php
	/* Affichage éventuel du journal */
	if (array_key_exists('acq_journal', $_POST)) {
?>
		<div style="color:blue; font-size:0.8em; padding:0.3em;">
<?php
		if ($jnl = fopen('service/calculs.php.histo', 'r')) {
			while(!feof($jnl)){
				echo fgets($jnl).'<br>';
			}
			fclose($jnl);
		}

		if ($jnl = fopen('service/calculs.php.log', 'r')) {
			while(!feof($jnl)){
				echo fgets($jnl).'<br>';
			}
			fclose($jnl);
		}
?>
		</div>
<?php
}
?>