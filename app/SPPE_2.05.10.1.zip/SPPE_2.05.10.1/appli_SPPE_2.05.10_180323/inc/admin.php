<?php
	
	include __DIR__.'/../sql/sql_admin.php';
	
	$activPanel = 'admin_prefs';
	if (!empty($_POST['module'])){
		$activPanel = $_POST['module'];
	}
?>
	<script src="js/adminsi.js?<?php echo DATE_VERSION;?>"></script>
	<input type="hidden" id="activ_panel" value="<?php echo $activPanel;?>" />
<?php
	include 'admin_preferences.php';
	
	if (estHabil(HABIL_GESTION_DATE)){
		include 'admin_gestion_date.php';
	}
	if (estAdmin()){
		include 'admin_utilisateur.php';
		include 'admin_services.php';
		include 'admin_application.php';
	}
?>
