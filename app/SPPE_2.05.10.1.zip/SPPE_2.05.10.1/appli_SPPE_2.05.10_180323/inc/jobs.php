<?php
/* SPPE
 * Détails des jobs en réalisé
 */

/* jobs --------------------------------------------------------------------------------------------
 * Dresse le tableau des jobs
 * $proc : processus en cours
 * $nbcols : nombre de colonnes en référence
 * --> retourne  le code HTML correspondant
 */
function jobs(&$proc, $nbcols) {

    static $occurrence = 0;

    $rc = '';

    $couleurs = array(
        SPPE_SANS_OBJET   => SPPE_DEF_SANS_OBJET,
        SPPE_ETAT_ABORT   => $_SESSION['prf_coul_en_abort'],
        SPPE_ETAT_EXEC    => $_SESSION['prf_coul_en_cours'],
        SPPE_ETAT_PREVU   => $_SESSION['prf_coul_calcule'],
        SPPE_ETAT_TERMINE => $_SESSION['prf_coul_termine']);

    $contenu = array(
        SPPE_SANS_OBJET   => '-',
        SPPE_ETAT_ABORT   => '&nbsp;',
        SPPE_ETAT_EXEC    => '&nbsp;',
        SPPE_ETAT_PREVU   => '&nbsp;',
        SPPE_ETAT_TERMINE => '&nbsp;');

    /* présence de réalisé supprimé manuellement ? */
    $exresu = (sql_existe_realise_supprime($proc[$occurrence]['pln_id']) ?
        '<p class="realise_supprime">Réalisé automatique supprimé manuellement</p>' : '');

    /* réalisé manuel ? */
    $res = sql_lis_realise_manuel($proc[$occurrence]['pln_id']);
    if ($lu = pg_fetch_row($res)) {
        $exresu .= '<p class="realise_manuel">Réalisé mis à jour manuellement'
            .'<span style="font-weight:normal"> : '
            .$lu[0].' <span style="color:#888888"> &bull; le '
            .jma(substr($lu[1], 0, 10)).' à '.substr($lu[1], 11, 5).'</span></span></p>';
    }

    /* ---------------- */

    $res = sql_jobs($proc[$occurrence]['pln_id'],$proc[$occurrence]['pro_id']);

    $rc .= '<tr><td colspan="'.$nbcols.'" class="jobs">'.$exresu.'<table>';

    /* entête */
    $ent = '<tr><th>Jobs</th>';
    $entetes = array();
    while ($lu = pg_fetch_assoc($res)) {
        $e = $lu['ent_code'];
        if (!in_array($e, $entetes)) {
            array_push($entetes, $e);
            $ent .= '<th>'.$e.'</th>';
        }
    }
    $ent .= '</tr>';

    $acc = '';
    if (count($proc) > 1) {
        /* suivi simplifié avec plusieurs occurrence, affichage en accordéon */
        $acc = '<tr><th colspan="'.(count($entetes) + 1).'">Traitement du '
            .jma($proc[$occurrence]['tri2']).'</th></tr>';
    }
    $rc .= $acc.$ent;

    /* jobs */
    $jobs = array();
    pg_result_seek($res, 0);
    while ($lu = pg_fetch_assoc($res)) {
        $m = $lu['mbx_nom'];
        if (!array_key_exists($m, $jobs)) {
            /* initialisation du job à vierge */
            $jobs[$m] = array();
            foreach($entetes as $e) {
                $jobs[$m][$e] = array('0', '', '');
            }
        }
        $jobs[$m][$lu['ent_code']] = array($lu['etat'],
            ($lu['job_id'] ? 'job'.$lu['job_id'] : ''),
            ($lu['abort'] == 't' ? '<span class="pastille_rouge">&bull;</span>' : ''));
    }

    /* présentation */
    foreach($jobs as $j => $job) {
        $rc .= '<tr><th>'.$j.'</th>';
        foreach($job as $jb) {
            $rc .= '<td style="background-color:'.$couleurs[$jb[0]].'" id="'.$jb[1].'">'
                .$contenu[$jb[0]].$jb[2].'</td>';
        }
        $rc .= '</tr>';
    }
    $rc .= '</table></td></tr>';

    $occurrence++;
    if ($occurrence < count($proc)) {
        /* occurrence suivante en suivi simplifié */
        $rc .= jobs($proc, $nbcols);
    }

    return $rc;
}

// fin
