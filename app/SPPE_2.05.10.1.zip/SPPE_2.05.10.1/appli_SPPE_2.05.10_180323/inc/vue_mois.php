<?php

	/* Entête */

	$deb = $_SESSION['sel_cal'].'-01';      // Date de début incluse

	$un_jour = new DateInterval('P1D');
	$un_mois = new DateInterval('P1M');

	$nwd = new DateTime($deb);
	$tsp = $nwd->getTimeStamp();
	$tit = strftime('%B %Y', $tsp);
	$libjours = '';

	$nwd->add($un_mois);
	$nwd->sub($un_jour);
	$nb_jours = intval($nwd->format('d'), 10);

	$cell = new Cellule($deb, $nb_jours);

	$j = 0;
	while ($cell->ok()) {
		$j++;
		if ($cell->iso() == $jour_iso){
			$cell->classe('aujourdhui');
		}
		$jours .= $cell->fabrique($j, 'th');
		$libjours .= $cell->fabrique(strftime('%a', $cell->jour()->getTimeStamp()), 'th');
		$cell->suivant();
	}

	$entete = '<tr style="background-color:#EEEEEE">'
			.'		<th rowspan="2" colspan="'.(3 + $col_sup).'" style="color:#CE8C1E">'
			.'			<span style="margin-right:15px;">'.$titre_tableau.'</span>'
			.'			<a href="index.php?page=pdf'.$exportBis.'" target="_blank" ><img src="img/pdf.png" title="Sortie PDF" alt="pdf" class="enligne" /></a>'
			.'			<a href="index.php?page=csv'.$exportBis.'" target="_blank" ><img src="img/calc.png" title="Sortie Tableur" alt="tableur" class="enligne" /></a>'
			.'		</th>'
			.'		<th colspan="'.$nb_jours.'">'.$tit.'</th>'
			.'</tr>'
			.'<tr class="jours">'
			.$jours
			.'</tr>'
			.'<tr class="lib"><th colspan="'.(2 + $col_sup).'">Nom du processus</th><th>Chaînes</th>'.$libjours.'</tr>';

	$col_sup += 2;

?>
