<?php
if (($_SERVER['HTTP_HOST']=='sppe-local') || ($_SERVER['HTTP_HOST']=='sppe-local-secure')){
	define('URL_PUBLIQUE','http://sppe-local');
	define('URL_SECURE','http://sppe-local-secure');
	
	define('ENVIRONNEMENT','LOCAL');
	define('AFF_ENVIRONNEMENT','LOCAL');
	
	define('HOST_BASE','127.0.0.1');
	
	if ($_SERVER['HTTP_HOST']=='sppe-local-secure'){
		define('MODE_CONNECTE',TRUE);
		$_SERVER['PHP_AUTH_USER'] = 'uid=1024358107-0,ou=personnes,ou=dgfip,ou=mefi,o=gouv,c=fr'; // willy
		// 		$_SERVER['PHP_AUTH_USER'] = 'uid=1002827768-0,ou=personnes,ou=dgfip,ou=mefi,o=gouv,c=fr'; // laurent -> inconnu
	}else{
		define('MODE_CONNECTE',FALSE);
	}
}elseif(($_SERVER['HTTP_HOST']=='10.153.91.148') || ($_SERVER['HTTP_HOST']=='172.16.171.10') || ($_SERVER['HTTP_HOST']=='sppe.iria.appli.impots') || ($_SERVER['HTTP_HOST']=='sppe.iria.appli.dgfip')){ // RECETTE
	define('URL_PUBLIQUE','http://10.153.91.148');
	define('URL_SECURE','http://sppe.iria.appli.impots');
	
	define('ENVIRONNEMENT','RECETTE');
	define('AFF_ENVIRONNEMENT','RECETTE');
	
	define('HOST_BASE','spedgsd001-d');
	
	if ($_SERVER['HTTP_HOST']=='sppe.iria.appli.impots'){
		define('MODE_CONNECTE',TRUE);
	}else{
		define('MODE_CONNECTE',FALSE);
	}
// }elseif(($_SERVER['HTTP_HOST']=='') || ($_SERVER['HTTP_HOST']=='') || ($_SERVER['HTTP_HOST']=='') || ($_SERVER['HTTP_HOST']=='')){ // INTEX
// 	define('URL_PUBLIQUE','http://');
// 	define('URL_SECURE','http://');
	
// 	define('ENVIRONNEMENT','INTEX');
// 	define('AFF_ENVIRONNEMENT','INTEX');
	
// 	define('HOST_BASE','');
	
// 	if ($_SERVER['HTTP_HOST']=='sppe.iria.appli.impots'){
// 		define('MODE_CONNECTE',TRUE);
// 	}else{
// 		define('MODE_CONNECTE',FALSE);
// 	}
}else{ // PRODUCTION
	define('URL_PUBLIQUE','http://sppe.appli.dgfip');
	define('URL_SECURE','http://sppe.appli.impots');
	
	define('ENVIRONNEMENT','PRODUCTION');
	define('AFF_ENVIRONNEMENT','');
	
	define('HOST_BASE','spepgsd001-d');
	
	if ($_SERVER['HTTP_HOST']=='sppe.appli.impots'){
		define('MODE_CONNECTE',TRUE);
	}else{
		define('MODE_CONNECTE',FALSE);
	}
	
}

if (AFF_ENVIRONNEMENT!=''){
	$serveur = '<span id="environnement">'.AFF_ENVIRONNEMENT.'</span>';
}
?>
