<?php

$recherche_seulement = true;
$cmdb = 'cmd_rch';
$page = 'gesdates';
$action = 'action="recherche.php"';

require 'inc/page.php';

?>
