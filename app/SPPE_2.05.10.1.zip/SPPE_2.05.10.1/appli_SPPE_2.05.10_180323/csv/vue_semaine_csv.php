<?php
    $deb = $_SESSION['sel_cal'];    // Date de début incluse
    $nb_jours = 7;                  // Nombre de jours sur la période

    $cell = new Cellule_csv($deb, 7, 10, $csv);

    $col_pro = 72;

    $tsp = $cell->jour()->getTimeStamp();
    $tit = strftime('Semaine %V : du %e', $tsp);
    $lbm = strftime('%B', $tsp);
    $lby = strftime('%Y', $tsp);

    $tjours = array();
    while ($cell->ok()) {
        array_push($tjours,
            array(strftime('%a %e', $cell->jour()->getTimeStamp()),
                $cell->est_ferie(), ($cell->iso() == $jour_iso)));
        $cell->suivant();
    }

    $tsp = $cell->jour()->getTimeStamp() - 86400;
    $j = strftime(' au %e %B %Y', $tsp);
    $m = strftime('%B', $tsp);
    $y = strftime('%Y', $tsp);
    if ($m != $lbm) $tit .= ' '.$lbm;
    if ($y != $lby) $tit .= ' '.$lby;
    $tit .= $j;

    $col_sup = 4;

// fin
