<?php

	/* Extraction du calendrier au format CSV
	 * 
	 * Appel d'un fichier calc LibreOffice
	 * avec exécution de macro automatique */

	/* Création du fichier CSV ------------------------------------------------------------------ */

	require __DIR__ .'/../inc/selections.php';
	require __DIR__ .'/../sql/sql_realise.php';
	require 'Cellule_csv.php';

	/* ------------------------------------------------------------------------------------------ */

	/* Ouverture du fichier CSV */

	$csv = fopen(__DIR__ .'/../lo/extr'.$_SESSION['uti_id'].'.csv', 'w');
	if ($csv === false){
		exit;
	}

	/* Grille des processus -- prévisionnel et réalisé -- format CSV */

	$aujourdhui = new DateTime();
	$jour_iso = $aujourdhui->format('Y-m-d');

	$jours = '';

	$realise = false;
	if (getPost('realise')!=''){
		$realise = (getPost('realise')== '1');
	}

	$titre_tableau = 'Calendrier prévisionnel'.($realise ? ' & réalisé' : '');

	$vue_semaine = (strlen($_SESSION['sel_cal']) > 7);

	if ($vue_semaine) {
		require 'vue_semaine_csv.php';
	} else {
		require 'vue_mois_csv.php';
	}

	$fin = $cell->iso();	/* Fin non incluse */

	/* article entête :
	 * T, date premier jour, nombre de jours, titre du tableau, titre de la période
	 */
	$ligne = array('T', $deb, $nb_jours, $titre_tableau, $tit);
	fputcsv($csv, $ligne);

	/* article jours : J, suivi des jours avec indication férié ou pas */
	$ligne = array('J');
	$c = $_SESSION['prf_coul_ferie'];
	$cferie = 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c);
	foreach ($tjours as $jour) {
		array_push($ligne, ($jour[1] == 1 ? $cferie : '').':');
	}
	fputcsv($csv, $ligne);

	/* Sélection des processus */
	require __DIR__ .'/../inc/grille_selection.php';

	$suivi_simplif = false;

	if (pg_num_rows($res)) {

		/* Préparation du suivi simplifié et des processus présentant plusieurs occurrences */

		$processus = array();
		prepare_processus($processus, $res);

		/* Affichage des lignes du calendrier */

		$un_mois = 30;
		$manuel = array('t' => '_manuel', 'f' => '');

		$indice = 0;
		$remarques = array();	   // Tableau des annotations et observations
		$chaines_fin = array();	 // Tableau des chaînes affichées en fin de document

		foreach($processus as $proc) {

			$lu = array_shift($proc);
			$prev_suivante = occurrence_suivante($proc, $realise, $deb);

			$timbre1 = new DateTime($lu['pro_timbre']);

			/* Notes du CQMF */
			$observation = trim($lu['pln_notes']).((estHabil(HABIL_GESTION_DATE,$lu['dom_id']) && trim($lu['pln_prive'])) ?(trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
			$observations = $observation;

			/* Notes du réalisé */
			$annotation = '';
			if (array_key_exists('rea_notes', $lu)) {
				$annotation = trim($lu['rea_notes']);
			}

			/* nom du processus en rouge si modifié depuis moins d'un mois */
			$age = intval($aujourdhui->diff($timbre1)->format('%a'), 10);
			$rouge = ($age < $un_mois);
			/* nom du processus en italique s'il comporte une rupture */
			$pro_classe = 'B';
			if ($lu['pro_rupture'] == 't'){
				$pro_classe = 'I'; // en italique
			}

			/* ---------- NOUVELLE LIGNE ---------- */

			/* mise en évidence du passage aux processus en suivi simplifié */
			if (($lu['tri1'] == 2) && !$suivi_simplif) {
				$suivi_simplif = true;
				$c = $_SESSION['prf_coul_ferie'];
					$sep = 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':';
					$ligne = array('D');
				for ($i=0; $i<($nb_jours+$col_sup); $i++){
					array_push($ligne, $sep);
				}
				if ($nb_jours < 10){
					array_push($ligne, '');
				}
				fputcsv($csv, $ligne);
			}

			$ligne = array('D');

			/* nom du processus et liste des chaînes */
			array_push($ligne, 'pro'.$pro_classe.($rouge ? 'rouge' : '').':'.$lu['pro_nom']);

			/* if ($age < 1) {
				// panneau d'avertissement si du jour ('../img/du_jour.png');
			} */

			array_push($ligne, 'chaines:'.trim($lu['lst_chaines']));

			if ($vue_semaine) {
				array_push($ligne, 'dates:'.($lu['pln_debut'] < $deb ? jma($lu['pln_debut']) : ''));
			}

			$recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);

			$j = 0;
			$cell->raz();

			while ($cell->ok()) {

				$j++;
				$raz = false;
				$courant = $cell->iso();

				/* Lecture de l'occurrence suivante pour les processus en suivi simplifié
				 * quand la date courante atteint le  début de l'occurrence suivante */

				if ($courant >= $prev_suivante) {
					$lu = array_shift($proc);
					$prev_suivante = occurrence_suivante($proc, $realise, $courant);
					$observation = trim($lu['pln_notes']).((estHabil(HABIL_GESTION_DATE,$lu['dom_id']) && trim($lu['pln_prive'])) ? (trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
					if ($observation) {
						if ($observations){
							$observations .= ' / '.$observation;
						}else{
							$observations = $observation;
						}
					}
					/* Notes du réalisé */
					$annotation = '';
					if (array_key_exists('rea_notes', $lu)) {
						$annotation = trim($lu['rea_notes']);
					}
					$recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);
				}

				/* contenu par défaut */
				$premier = (($lu['pro_premier'] == 't') && ($lu['pln_debut'] == $courant) && ($lu['pln_debut'] != $lu['pln_fin']));
				$contenu = ($premier ? '!' : '');

				if ($realise && ($lu['rea_debut'] != null)) {

					/* Définition hors prévisionnel */
					$hors_previsionnel = (($courant < $lu['pln_debut'] && $courant >= $lu['rea_debut']) ||
											($courant > $lu['pln_fin'] && $courant <= $jour_iso &&
											($courant <= $lu['fin_retenue'] || $lu['rea_fin'] == null)));

					/* Présentation du réalisé en priorité */
					if ($lu['rea_fin'] == null) {

						/* Pas encore de date de fin */
						if ($courant >= $lu['rea_debut'] && $courant <= $jour_iso){
							$cell->classe(($lu['rea_statut'] == 'A' ? 'abort' : 'encours'));
						}

						/* * (étoile), processus hors prévisionnel */
						if ($hors_previsionnel){
							$contenu .= '*';
						}
					} else {

						/* Présence d'une date de fin */
						if ($hors_previsionnel) {

							/* Hors période */
							if (($courant < $lu['pln_debut']) && ($courant >= $lu['rea_debut'])){
								$cell->classe('hors_delai_avant');
							}else{
								$cell->classe('hors_delai_apres');
							}
						} else {

							/* Dans les délais */
							if (($courant <= $lu['rea_fin']) && ($courant >= $lu['rea_debut'])) {
								$cell->classe(($lu['rea_statut'] == 'A' ? 'abort' :'termine'));
							} else {
								$raz = (($courant > $lu['rea_fin']) && ($lu['rea_statut'] == 'T'));
							}
						}
					}
				}

				/* Mise en évidence d'une information éventuelles */

				$prevision = (($courant >= $lu['pln_debut']) && ($courant <= $lu['pln_fin']));
				$reel = ($cell->etat() != '');

				if (($prevision || $reel) && ($raz == false)) {

					/* Cellule en évidence */

					/* Souligner en rouge les modifications récentes */
					$cell->classe($recent);

					/* Réalisé seulement */
					if ($reel) {
// 						if (bulle($observation, $annotation, $indice, $remarques)) {
// 							$contenu = ($premier ? $contenu : '').'*'.$indice;
// 							$cell->classe('cell_info');
// 						}
						$cell->fabrique($ligne, $contenu, false);
					} else {
						/* Prévisions seulement (y compris dans le réalisé) */
						if ($prevision) {
							if ($lu['pln_suppr'] == 't') {
								$cell->classe('supprime');
								$cell->fabrique($ligne, 'X', false);
							} else {
								if ($lu['pln_confirm'] == 't') {
									if ($realise && ($lu['pro_realise'] == 'f') && ($lu['pln_fin'] < $jour_iso) && ($lu['rea_debut'] == null)) {
										$cell->classe('termine');
									} else {
										$cell->classe('sure'.$manuel[$lu['manuel']]);
									}
									$cell->fabrique($ligne, $contenu, false);
								} else {
									$cell->classe('pas_sure'.$manuel[$lu['manuel']]);
									$cell->fabrique($ligne, ($premier ? $contenu : '?').'??', false);
								}
							}
						}
					}
				} else {

					/* Processus pas au plan ou remis à blanc */
					$cell->fabrique($ligne, $contenu);
				}
				$cell->suivant();
			}

			if ($vue_semaine) {
				$borne = ($lu['pln_fin'] >= $fin ? jma($lu['pln_fin']) : '');
				array_push($ligne, 'dates:'.$borne, $observations);
			}

			/* Écriture du processus */
			fputcsv($csv, $ligne);
		}
	}

	/* Légende en réalisé */

	if ($realise) {
		$ligne = array('L');

		/* terminé */
		$c = $_SESSION['prf_coul_termine'];
		array_push($ligne, 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':terminé','');

		/* en cours */
		$c = $_SESSION['prf_coul_en_cours'];
		array_push($ligne, 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':en cours','');

		/* en abort */
		$c = $_SESSION['prf_coul_en_abort'];
		array_push($ligne, 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':en abort','');

		/* terminé hors délai (avant)*/
		$c = $_SESSION['prf_coul_hors_delai_avant'];
		array_push($ligne, 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':avant prévisionnel');
		
		/* terminé hors délai (après)*/
		$c = $_SESSION['prf_coul_hors_delai_apres'];
		array_push($ligne, 'RGB|'.rgb('r', $c).'|'.rgb('g', $c).'|'.rgb('b', $c).':après prévisionnel');

		fputcsv($csv, $ligne);
	}
	fclose($csv);

	$ou = 'ods.php?fic=extr';
	header('Location: '.$ou);
	exit;
// fin
