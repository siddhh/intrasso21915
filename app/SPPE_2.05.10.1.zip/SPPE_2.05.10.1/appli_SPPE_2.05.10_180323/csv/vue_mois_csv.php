<?php
    $deb = $_SESSION['sel_cal'].'-01';      // Date de début incluse

    $un_jour = new DateInterval('P1D');
    $un_mois = new DateInterval('P1M');

    $nwd = new DateTime($deb);
    $tsp = $nwd->getTimeStamp();
    $tit = strftime('%B %Y', $tsp);
    $libjours = '';

    $nwd->add($un_mois);
    $nwd->sub($un_jour);
    $nb_jours = intval($nwd->format('d'), 10);

    $col_pro = 66 + 6 * (31 - $nb_jours);   // Largeur de la colonne processus

    $cell = new Cellule_csv($deb, $nb_jours, 6, $csv);

    $tjours = array();
    while ($cell->ok()) {
        array_push($tjours,
            array(strftime('%a', $cell->jour()->getTimeStamp()),
                $cell->est_ferie(), ($cell->iso() == $jour_iso)));
        $cell->suivant();
    }

    $col_sup = 2;

// fin
