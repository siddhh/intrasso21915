<?php

$page = 'information';
$cmdb = 'cmd_help';
$realise = false;

require 'inc/page.php';

?>
