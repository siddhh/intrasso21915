<?php

    /* Extraction du plan de production pour le bureau d'études
     * 
     * Appel d'un fichier calc LibreOffice
     * avec exécution de macro automatique */

    /* Création du fichier CSV ------------------------------------------------------------------ */

    require __DIR__ .'/inc/type_serveur.php';
    require __DIR__ .'/inc/commun.php';
    require __DIR__ .'/inc/Cellule.php';

    function creation_CSV() {

        require __DIR__ .'/inc/pg_connect.php';

        /* Ouverture du fichier CSV */

        $csv = fopen('lo/plan'.$_SESSION['uti_id'].'.csv', 'w');
        if ($csv === false) return false;

        /* Nom de l'équipe */

        $req = 'select serv_nom from services where serv_id=$1';
        $res = pg_query_params($db, $req, array(substr($_SESSION['sel_app'], 1)));
        if ($lu = pg_fetch_row($res)) {
            fputcsv($csv, array('E', $lu[0]));
        } else {
            return false;
        }

        /* Période concernée :
         *  nov / fév => fév -> mai
         *  mar / jun => jun -> sep
         *  jul / oct => oct -> jan */

        $un_jour = new DateInterval('P1D');
        $un_mois = new DateInterval('P1M');

        $mois = intval(date('n'));
        $an = intval(date('Y'));
        if ($mois > 10) $an++;
        $m = array('', '02', '02', '06', '06', '06', '06', '10', '10', '10', '10', '02', '02');
        $mo = $m[$mois];

        $nbmois = 4;

        while ($nbmois > 0) {

            $deb = $an.'-'.$mo.'-01';

            $nwd = new DateTime($deb);
            $nwd->add($un_mois);
            $nwd->sub($un_jour);
            $nb_jours = intval($nwd->format('d'), 10);

            fputcsv($csv, array('M', $deb, $nb_jours));

            $cell = new Cellule($deb, $nb_jours);
            $jfer = new Cellule($deb, $nb_jours);

            $nwd->add($un_jour);
            $fin = $nwd->format('Y-m-d');

            /* Sélection des processus */

            $sql_select = 'select distinct p.pro_nom, p.pro_index, p.pro_lib,
                    p.pro_timbre, p.pro_rupture, p.pro_id, p.pro_vindex,
                    q.pln_timbre, q.pln_id, q.pln_debut, q.pln_fin, q.pln_confirm,
                    k.lst_chaines, 
                    case when p.pro_suivi then 2 else 1 end as tri1,
                    case when p.pro_suivi then q.pln_debut else q.pln_fin end as tri2 ';
            $sql_from = 'from plan q
                    join processus p on p.pro_id=q.pro_id
                    join liens l on l.pro_id=p.pro_id
                    join membrex m on m.mbx_id=l.mbx_id
                    join chaines c on c.chn_id=m.chn_id
                    join applications a on a.app_id=c.app_id
                    join liste k on k.pro_id=p.pro_id and k.pro_version=p.pro_version ';
            $sql_where = 'where (((q.pln_debut >= $1) and (q.pln_debut < $2))
                    or ((q.pln_fin >= $1) and (q.pln_fin < $2))
                    or ((q.pln_debut < $1) and (q.pln_fin >= $2)))
                    and a.serv_id=$3 and not q.pln_suppr ';
            $sql_order = ' order by tri1, tri2, q.pln_debut, p.pro_nom';

            $req = $sql_select.$sql_from.$sql_where.$sql_order;
            $prm = array($deb, $fin, substr($_SESSION['sel_app'], 1));
            $res = pg_query_params($db, $req, $prm);
            // echo $req; var_dump($prm);exit;
            if (pg_num_rows($res)) {

                /* Préparation du suivi simplifié et des processus présentant plusieurs occurrences */

                $processus = array();
                prepare_processus($processus, $res);

                /* Affichage des lignes du calendrier */

                $occ = 0;
                foreach($processus as $proc) {

                    $lu = array_shift($proc);

                    $occ++;
                    $ferie = array('F');
                    $ligne = array('O');

                    /* nom du processus et liste des chaînes */
                    array_push($ligne, $lu['pro_nom']);
                    array_push($ligne, $lu['lst_chaines']);

                    $j = 0;
                    $cell->raz();
                    if ($occ == 1) $jfer->raz();

                    while ($cell->ok()) {

                        $j++;
                        $contenu = '   ';
                        $courant = $cell->iso();

                        $prevision = (($courant >= $lu['pln_debut']) and ($courant <= $lu['pln_fin']));

                        if ($prevision) {

                            if ($lu['pln_confirm'] == 't') {
                                $cell->classe('sure');
                                array_push($ligne, $cell->csv($contenu));
                            } else {
                                $cell->classe('pas_sure');
                                array_push($ligne, $cell->csv('???'));
                            }

                        } else {

                            /* Processus pas au plan */
                            array_push($ligne, $cell->csv($contenu));
                        }

                        $cell->suivant();

                        if ($occ == 1) {
                            array_push($ferie, $jfer->csv('   '));
                            $jfer->suivant();
                        }

                        /* Lecture de l'occurrence suivante pour les processus en suivi simplifié
                         * quand la date courante atteinte la date de fin de l'occurrence courante */

                        if (($courant >= $lu['pln_fin']) and (count($proc) > 0)) {
                            $lu = array_shift($proc);
                        }
                    }
                    if ($occ == 1) fputcsv($csv, $ferie);
                    fputcsv($csv, $ligne);
                }
            } else {
                $ligne = array('N', "Aucune occurrence pour la période.");
                fputcsv($csv, $ligne);
            }
            /* Mois suivant */
            $nbmois--;
            $mosuiv = intval($mo, 10) + 1;
            if ($mosuiv > 12) {
                $mosuiv = 1;
                $an++;
            }
            $mo = str_pad($mosuiv, 2, '0', STR_PAD_LEFT);
        }
        fclose($csv);
        return true;
    }

    /* Préparation de l'extraction -------------------------------------------------------------- */

    session_start();
    $ou = 'index.php';

    if (isset($_SESSION) && ($_SESSION['uti_id'] != 0)) {
        if (creation_CSV()){
        	$ou = 'ods.php?fic=plan';
        }
    }
    header('Location: '.$ou);
    exit;
?>
