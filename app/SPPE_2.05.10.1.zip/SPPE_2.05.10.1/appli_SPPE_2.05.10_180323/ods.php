<?php
session_start();
$fic = filter_input(INPUT_GET, 'fic');
if (isset($_SESSION) && (($_SESSION['uti_id'] != 0) || ($fic == 'extr'))) {
    $serveur = $_SERVER['SERVER_ADDR'];
    //local
    if ($serveur=="127.0.0.1"){
    	$serveur='10.202.42.107';
    // recette
    }elseif (substr($serveur, 0, 12) == '192.168.171.'){
    	$serveur = '10.153.91.148';
    // production
    }else{
    	$serveur = 'IP_PRODUCTION';
    }
    $nom = $fic.'.'.$serveur.'.'.$_SESSION['uti_id'].'.x.ods';
    $source = 'lo/'.$fic.'.ods';
    header('Content-Disposition: attachment; filename='.$nom);
    header('Content-Type: application/vnd.oasis.opendocument.spreadsheet');
    readfile($source);
} else {
    header('Location: index.php');
}
exit;
?>
