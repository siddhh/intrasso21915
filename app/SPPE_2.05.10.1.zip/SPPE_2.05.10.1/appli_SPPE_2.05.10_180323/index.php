<?php

/* -------------------------------------------------------------------------------------------------
 * Application SPPE : Suivi du Plan de Production des Exploitations
 * -------------------------------------------------------------------------------------------------
 * Point d'entrée de l'application
 * JMD - août 2014
 * ---------------------------------------------------------------------------------------------- */

/* initialise la session */
if (!isset($_SESSION)){
	session_start();
}

/* initialisation de l'application */
require_once 'inc/init.php';

/* definition des variables de chargement de la page */
if (getPost('page')!=''){
	list($page, $cmdb, $titre_tableau, $realise, $recherche_seulement, $action) = initialisationPage(getPost('page'));
}else{
	list($page, $cmdb, $titre_tableau, $realise, $recherche_seulement, $action) = initialisationPage();
}

/*  chargement de la page */
if ($page=='pdf'){
	require 'pdf/etat.php';
}elseif($page=='csv'){
	require 'csv/grille_csv.php';
}else{
	require 'inc/page.php';
}

// fin
