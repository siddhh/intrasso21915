<?php

$page = 'aff_nouveautes';
$cmdb = 'cmd_pre';
$titre_tableau = 'Calendrier prévisionnel';
$realise = false;

require 'inc/page.php';

?>
