/* Interactivité du calendrier réalisé */

/* realise_init ------------------------------------------------------------------------------------
 * Initialisation dans le domaine du réalisé
 */
function realise_init() {
    affiche_job_popup();
//    details_realise();
    saisies_realise();
}

/* affiche_job -------------------------------------------------------------------------------------
 * Affichage du détail du job cliqué
 */
function affiche_job() {
    var job = this.id.substr(3);
    var plus = document.getElementById('plus').value;
    var suiv = 'plus=' + plus + '&job=' + job;
    var prec = document.URL.split('?')[1];
    if (suiv == prec) {
        document.location.reload();
    } else {
        document.location = 'index.php?page=realise&' + suiv;
    }
}

/* affiche_job_popup -------------------------------------------------------------------------------
 * Affiche les détails d'un job dans un pop-up
 */
function affiche_job_popup() {
    var job_detail = document.getElementById('job_detail');
    if (job_detail) {
        var job_id = job_detail.value;
        if (job_id > 0) {
            var pw = popup_window('inc/job_detail.php?job='+job_id, 'job_detail', 540, 300);
            pw.focus();
        }
    }
}

/* Calendrier ----------------------------------------------------------------------------------- */
function calend() {

    var id = this.id.substr(0, this.id.length - 4);

    if (id == 'reel_debut') {
        var reel_debut = document.getElementById('reel_debut');
        var pln_debut = document.getElementById('pln_debut');
        if (reel_debut.value == '-') {
            reel_debut.value = jma(pln_debut.value);
        }
    } else {
        var reel_debut = document.getElementById('reel_debut');
        var reel_fin = document.getElementById('reel_fin');
        var pln_debut = document.getElementById('pln_debut');
        if (reel_fin.value == '-') {
            if (reel_debut.value == '-') {
                reel_fin.value = jma(pln_debut.value);
            } else {
                reel_fin.value = reel_debut.value;
            }
        }
    }
    displayDatePicker(id, false, 'dmy', '/');
}

/* Appel detail réalisé ------------------------------------------------------------------------- */
function detail_realise() {
    var sens = this.id.substr(0, 4);
    if (sens == 'plus') {
        /* ouverture des détails */
        var plus = this.id.substr(4);
        document.location = 'index.php?page=realise&plus=' + plus;
    } else {
        /* fermeture des détails */
//        var moins = this.id.substr(5);
        document.location = 'index.php?page=realise';
    }
}

/* Association d'un évènement click à tous les TD qui comportent un ID plus ou moins ------------ */
function details_realise() {
    var table = document.getElementById('grille');
    var cells = table.getElementsByTagName('img');

    for (var i = 0, len = cells.length ; i < len ; i++) {
        var deb = cells[i].id.substr(0,4);
        if (deb == 'plus' || deb == 'moin') {
            cells[i].onclick = detail_realise;
        }
    }

    var tables = document.querySelectorAll('.jobs')

    for (var t = 0, tlen = tables.length; t < tlen; ++t) {
        cells = tables[t].getElementsByTagName('td');
        for (var i = 0, len = cells.length ; i < len ; i++) {
            if (/^job\d/.test(cells[i].id)) {
                cells[i].style.cursor = 'pointer';
                cells[i].onclick = affiche_job;
            }
        }
    }
}

/* Efface la date ------------------------------------------------------------------------------- */
function efface() {
    var id = this.id.substr(0, this.id.length - 4);
    var el = document.getElementById(id);
    el.value = '';
    el.focus();
}

/* Vérification de la saisie -------------------------------------------------------------------- */
function saisie_verif() {

	/* confirmation */
	if (confirm("Confirmez-vous l'utilisation de la procédure manuelle ?") === false) {
		return false;
	}

	/* Suppression du réalisé par vidage des champs */
    if ((deb === undefined || deb === null) &&
        (fin === undefined || fin === null) &&
        reel_notes.value.trim().length < 2) {
        return valide_suppression_realise();
    }
	
    /* Note obligatoire */
    var reel_notes = document.getElementById('reel_notes');
    if (reel_notes.value.trim().length < 2) {
        alert('Le réalisé automatique nécessite un commentaire.');
        reel_notes.focus();
        return false;
    }

    /* date de fin */
    var reel_fin = document.getElementById('reel_fin');
    var fin = date_verif(reel_fin.value);

    if (fin === undefined) {
        reel_fin.focus();
        return false;
    }
    reel_fin.value = jma(fin);

    /* date de début */
    var reel_debut = document.getElementById('reel_debut');
    var deb = date_verif(reel_debut.value);

    if (deb === undefined || ((deb === null) && (fin != null))) {
        alert('Vous devez définir une date de début.');
        reel_debut.focus();
        return false;
    }
    reel_debut.value = jma(deb);

    /* chronologique */
    if ((deb != null) && (fin != null) && (fin < deb)) {
        alert('Dates incohérentes');
        reel_debut.focus();
        return false;
    }

    /* plage des dates */
    var auj = today(true);
    var limb = date_add('a', -1, auj);
    if (deb != null) {
        if (deb < limb) {
            alert('Attention, date trop éloignée dans le temps.');
            reel_debut.focus();
            return false;
        }
        if (deb > auj) {
            alert('Attention, date dans le futur.');
            reel_debut.focus();
            return false;
        }
    }
    if (fin != null) {
        if (fin > auj) {
            alert('Attention, date dans le futur.');
            reel_fin.focus();
            return false;
        }
    }

    /* Conservation des dates */
    var hreel_debut = document.getElementById('hreel_debut');
    var hreel_fin = document.getElementById('hreel_fin');
    
    if (deb === null) {
        hreel_debut.value = '';
    } else {
        hreel_debut.value = deb;
    }

    if (fin === null) {
        hreel_fin.value = '';
    } else {
        hreel_fin.value = fin;
    }

    /* Abort 
    var abort = document.getElementById('reel_abort');
    if (abort.checked && fin === null) {
        alert("En l'absence de date de fin,\nla notion d'abort est ignorée.");
    }*/

    return true;
}

/* Appel saisie réalisé ------------------------------------------------------------------------- */
function saisie_realise() {
	document.location = 'index.php?page=realise&pln_id='+this.id.substr(4);
}
function saisie_realise_jquery( objet ) {
	console.log(objet);
    window.location.href = 'index.php?page=realise&pln_id='+objet.attr('id').substr(4);
}

/* Association d'un évènement click à tous les TD qui comportent un ID -------------------------- */
function saisies_realise() {

    var table = document.getElementById('grille');
    var cells = table.getElementsByTagName('td');

    for (var i = 0, len = cells.length ; i < len ; i++) {
        if (/^j\d\di\d/.test(cells[i].id)) {
            cells[i].style.cursor = 'pointer';
            cells[i].onclick = saisie_realise;
        }
    }
//    $("#grille table tbody tr td").on("click",function(){
//    	saisie_realise_jquery( $(this) );
//    });

    /* autres évènements */

    var cmd = document.getElementById('cmd_sais_reel');
    if (cmd != undefined && cmd != null) {
        cmd.onclick = saisie_verif;
    }

    var sais_suppr_rea = document.getElementById('cmd_sais_suppr_rea');
    if (sais_suppr_rea) {
        sais_suppr_rea.onclick = valide_suppression_realise;
    }

    var reel_debut_eff = document.getElementById('reel_debut_eff');
    var reel_debut_cal = document.getElementById('reel_debut_cal');
    var reel_fin_eff = document.getElementById('reel_fin_eff');
    var reel_fin_cal = document.getElementById('reel_fin_cal');

    if (reel_debut_eff != undefined && reel_debut_eff != null) {
        reel_debut_eff.onclick = efface;
        reel_debut_cal.onclick = calend;
        reel_fin_eff.onclick = efface;
        reel_fin_cal.onclick = calend;
    }
}

/* valide_suppression_realise ------------------------------------------------------------------- */
function valide_suppression_realise() {
    return confirm("Confirmez-vous la suppression du réalisé pour cette mise au plan ?");
}

// fin
