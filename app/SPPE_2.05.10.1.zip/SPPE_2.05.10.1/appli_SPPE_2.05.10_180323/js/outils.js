/* Outils Javascript */

// =================================================================================================

// REPEAT
String.prototype.repeat = function(num) {
    return new Array(num + 1).join(this);
}

// LEFT
String.prototype.left = function(lg) {
    return this.substr(0, lg);
}

// LPAD
String.prototype.lpad = function(lg, car) {
    if (car === undefined) car = '0';
    var s = car.repeat(lg) + this;
    return s.substring(s.length - lg);
}

// RIGHT
String.prototype.right = function(lg) {
    return this.substring(this.length - lg);
}

// TRIM
String.prototype.trim = function() {
    return this.replace(/^\s+/,'').replace(/\s+$/,'');
}

// =================================================================================================

/* Ajout à une date --------------------------------------------------------------------------------
 *  - quoi : j, m ou a
 *  - combien : nombre
 *  - aquoi : date ref (au format ISO / PGSQL)
 */
function date_add(quoi, combien, aquoi) {
    var x = aquoi.split('-');
    var hor = aquoi.substr(10,9);
    var an = parseInt(x[0]);
    var mois = parseInt(x[1], 10) - 1;
    var jour = parseInt(x[2].left(2), 10);
    var nwd = new Date(an, mois, jour);
    switch (quoi) {
        case 'j' : nwd.setDate(jour + combien); break;
        case 'm' : nwd.setMonth(mois + combien); break;
        case 'a' : nwd.setFullYear(an + combien); break;
    }
    an = nwd.getFullYear();
    mois = parseInt(nwd.getMonth(), 10) + 1;
    mois = mois.toString().lpad(2);
    jour = nwd.getDate().toString().lpad(2);
    return an + '-' + mois + '-' + jour + hor;
}

/* date_verif --------------------------------------------------------------------------------------
 * Vérification d'une date
 *  - d : date au format string jour, mois, année
 * retourne la date au format ISO ou null */
function date_verif(d) {

    var rc = 'erreur';

    if (d !== undefined && d !== null) {

        /* Transformation */
        var ds = d.trim().replace(/\//g, '.').replace(/-/g, '.');

        if (ds == '' || ds == '.') {
            rc = null;
        } else {

            /* Éclatement */
            var xd = ds.split('.');

            /* Tests */
            if (xd.length == 2) {
                var nwd = new Date();
                xd.push(nwd.getFullYear().toString());
            }
            if (xd.length == 3) {
                if ((/^\d*$/.test(xd[0])) && (/^\d*$/.test(xd[1])) && (/^\d*$/.test(xd[2]))) {
                    var jo = parseInt(xd[0], 10);
                    var mo = parseInt(xd[1], 10);
                    var an = parseInt(xd[2], 10);
                    if ((jo > 0) && (jo < 32) &&
                        (mo > 0) && (mo < 13) &&
                        (an > 1900) && (an < 9999)) {
                        rc = an.toString() + '-'
                           + mo.toString().lpad(2) + '-'
                           + jo.toString().lpad(2);
                    }
                }
            }
        }
    } else {
        rc = d;
    }

    if (rc == 'erreur') {
        rc = undefined;
        alert('Date incorrecte');
    }

    return rc;
}

/* jma ---------------------------------------------------------------------------------------------
 * Transforme une date ISO au format JJ/MM/AAAA
 *  - d : date au format ISO / PostgreSQL
 * retourne la date au format JJ/MM/AAAA */
function jma(d) {
    var rc = '-';
    if (d !== undefined && d !== null) {
        var xd = d.split('-');
        if (xd.length == 3) {
            rc = xd[2] + '/' + xd[1] + '/' + xd[0];
        }
    }
    return rc;
}

/* today -------------------------------------------------------------------------------------------
 *  - iso : vrai pour un retour ISO, faux pour un retour français
 * retourne la date du jour */
function today(iso) {

    var rc = '';
    var td = new Date();
    var dd = td.getDate();
    var mm = td.getMonth()+1;
    var yyyy = td.getFullYear();

    if(dd<10) {
        dd='0'+dd
    }
    if(mm<10) {
        mm='0'+mm
    } 
    if (iso == undefined || iso == null || iso == false) {
        rc = dd+'/'+mm+'/'+yyyy;
    } else {
        rc = yyyy+'-'+mm+'-'+dd;
    }

    return rc;
}

/* FIN */
