/* adminsi.js
 * Fonctions Javascript pour l'administration réservée à SI
 * JMD - 11 février 2016
 */

var siga_ini = { 'charge' : true };

var siga_app;
var siga_lib;
var siga_serv;
var siga_dom;
var siga_act;
var siga_enrgt;

var sige_liste;
var sige_modifier;
var sige_supprimer;

/* adminsi_init ------------------------------------------------------------------------------------
 * Fonctions au chargement (appelé par l'init de sppe.js si l'id adminsi existe)
 */
function adminsi_init() {

    /* DOM */
    siga_app = document.getElementById('siga_app');
    siga_lib = document.getElementById('siga_lib');
    siga_dom = document.getElementById('siga_dom');
    siga_serv = document.getElementById('siga_serv');
    
    siga_act = document.getElementById('siga_act');
    siga_enrgt = document.getElementById('siga_enrgt');

//    sige_liste = document.getElementById('sige_liste');
//    sige_modifier = document.getElementById('sige_modifier');
//    sige_supprimer = document.getElementById('sige_supprimer');

    /* Événements */
    siga_app.onkeydown = change_appli;
    siga_app.onclick = change_appli;

    siga_lib.onchange = siga_modif;
    siga_dom.onchange = siga_modif;
    siga_serv.onchange = siga_modif;
    siga_act.onchange = siga_modif;
    
    siga_enrgt.onclick = siga_verif;

    siga_ini.cur = 0;               // application actuellement sélectionnée
    siga_ini.charge = false;        // indicateur de chargement de la page
    siga_ini.siga_modif = false;    // indicateur de modifications

//    sige_liste.onclick = active_boutons;
//    active_boutons();
}

/* active_boutons ----------------------------------------------------------------------------------
 * Active les boutons modifier et supprimer si une équipe est sélectionnée
 */
function active_boutons() {
    var etat = (sige_liste.selectedIndex < 0);
    sige_modifier.disabled = etat;
    sige_supprimer.disabled = etat;
}

/* change_appli ------------------------------------------------------------------------------------
 * Actualisation au changement d'application
 */
function change_appli() {
    var rc = true;
    var id = parseInt(siga_app.value, 10);
    siga_enrgt.disabled = (id == 0);
    if (id != siga_ini.cur) {
        if (siga_ini.modif) {
            rc = confirm("Voulez-vous abandonner les modifications en cours ?");
        }
        if (rc) {
            siga_ini.modif = false;
            siga_ini.cur = id;
            if (id == 0) {
                siga_lib.value = '';
                siga_dom.selectedIndex = 0;
                siga_serv.selectedIndex = 0;
                siga_act.checked = false;
            } else {
                siga_lib.value = siga_applis[id].app_lib;
                siga_dom.value = siga_applis[id].dom_id;
                siga_serv.value = siga_applis[id].serv_id;
                siga_act.checked = (siga_applis[id].app_ok == 't');
            }
        } else {
            siga_app.value = siga_ini.cur;
        }
    }
    return rc;
}

/* siga_modif --------------------------------------------------------------------------------------
 * Positionne l'indicateur de modifications (gestion des applications)
 */
function siga_modif() {
    siga_ini.modif = true;
}

/* siga_verif --------------------------------------------------------------------------------------
 * Vérifications en gestion des applications
 */
function siga_verif() {
    var id = parseInt(siga_app.value, 10);
    if (id == 0/* || siga_dom.value == 0 || siga_eqp.value == 0*/) {
        alert("Erreur : Choisissez une application"/*, un domaine et une équipe."*/);
        return false;
    }
    if (siga_dom.value != siga_equipes[siga_eqp.value].dom_id) {
        alert("Erreur : le domaine de l'équipe diffère du domaine de l'application.");
        return false;
    }
    if (!siga_equipes[siga_eqp.value].eqp_ok) {
        alert("Avertissement : Attention, l'équipe sélectionnée n'est plus d'actualité.");
    }
    if (!siga_domaines[siga_dom.value].dom_ok) {
        alert("Avertissement : Attention, le domaine sélectionné n'est plus d'actualité.");
    }
    return true;
} 

// fin
