/* Recherche et gestion des dates */

/* Calendrier ----------------------------------------------------------------------------------- */
function calend() {
    var id = this.id.substr(0, this.id.length - 4);
    displayDatePicker(id, false, 'dmy', '/');
}

/* change_fin --------------------------------------------------------------------------------------
 * Change la date de fin quand elle est vierge par celle de début quand elle est modifiée */
function change_fin() {
    var deb = document.getElementById('sais_debut');
    var fin = document.getElementById('sais_fin');
    if (deb.value.trim().length == 10 && fin.value.trim().length < 2) {
        fin.value = deb.value;
    }
}

/* Efface la date ------------------------------------------------------------------------------- */
function efface() {
    var id = this.id.substr(0, this.id.length - 4);
    var el = document.getElementById(id);
    el.value = '';
    el.focus();
}

/* Confirmation de la confirmation globale des mises au plan ------------------------------------ */
function confirm_confglob() {
    var cf = confirm('Confirmez-vous toutes les occurrences ?');
    if (cf) {
        var gd_confirme = document.getElementById('gd_confirme');
        gd_confirme.value = 'oui';
    }
    return cf;
}

/* Confirmation de l'application de la règle de planification ----------------------------------- */
function confirm_regplan() {
    var cf = confirm("Confirmez-vous l'application de la règle de planification ?");
    if (cf) {
        var gd_confirme = document.getElementById('gd_confirme');
        gd_confirme.value = 'oui';
    }
    return cf;
}

/* Confirmation du report N+1 ------------------------------------------------------------------- */
function confirm_report() {
    var cf = confirm('Confirmez-vous le report N+1 ?');
    if (cf) {
        cf = confirm("Le réalisation du report N+1 dure quelques dizaines de secondes.\n" +
            "Il est important de ne pas interrompre cette opération\n" +
            "au risque de verrouiller la base de données SPPE.\n\n" +
            "Pour la deuxième fois, confirmez-vous le report N+1 ?");
        if (cf) {
            var gd_confirme = document.getElementById('gd_confirme');
            gd_confirme.value = 'oui';
        }
    }
    return cf;
}

/* Confirmation de la suppression des notes privées --------------------------------------------- */
function confirm_priv() {
    var cf = confirm('Confirmez-vous la suppression des notes privées ?');
    return cf;
}

/* Confirmation de la purge du report N+1 ------------------------------------------------------- */
function confirm_purge() {
    var cf = confirm('Confirmez-vous la purge complète du report N+1 ?');
    if (cf) {
        var gd_confirme = document.getElementById('gd_confirme');
        gd_confirme.value = 'oui';
    }
    return cf;
}

/* Confirmation de la suppression d'une occurrence ---------------------------------------------- */
function confirm_suppr() {

    var cf = confirm("Confirmez-vous la suppression de l'occurrence ?");

    if (cf) {

        var manuel = document.getElementById('hsais_manuel');
        var ajustable = document.getElementById('hsais_ajustable');
        var supdef = document.getElementById('hsais_supdef');
        supdef.value = 'oui';

        if (manuel.value == 't' || ajustable.value == 't') {

            /* Processus planifié manuellement ou ajustable */

            var texte = document.getElementById('dialogue_texte');
            if (manuel.value == 't') {
                texte.innerHTML = 'manuelle';
            } else {
                texte.innerHTML = 'planifiée mais ajustable';
            }

            /* Placement du dialogue */

            var dialg = document.getElementById("dialogue");
            var coeur = document.getElementById("dialogue_coeur");
            coeur.style.marginLeft = (parseInt((document.body.offsetWidth - 300) / 2)).toString() + 'px';
            coeur.style.marginTop = (parseInt((document.body.offsetHeight - 200) / 2)).toString() + 'px';
            dialg.style.visibility = "visible";

        } else {

            /* Processus planifié automatiquement et non ajustable */

            document.frm_sais_dates.submit();
        }
    }
    return cf;
}

/* Confirmation de la restauration d'une occurrence --------------------------------------------- */
function confirm_rest() {
    return (confirm("Confirmez-vous la restauration de l'occurrence ?"));
}

/* Vérification de la saisie -------------------------------------------------------------------- */
function saisie_verif() {

    /* date de début */
    var sais_debut = document.getElementById('sais_debut');
    var deb = date_verif(sais_debut.value);

    if (deb === undefined || deb === null) {
        alert('Vous devez définir une date de début.');
        sais_debut.focus();
        return false;
    }
    sais_debut.value = jma(deb);

    /* date de fin */
    var sais_fin = document.getElementById('sais_fin');
    var fin = date_verif(sais_fin.value);

    if (fin === undefined || fin === null) {
        alert('Vous devez définir une date de fin.');
        sais_fin.focus();
        return false;
    }
    sais_fin.value = jma(fin);

    /* chronologique */
    if (fin < deb) {
        alert('Dates incohérentes');
        sais_debut.focus();
        return false;
    }

    /* plage des dates */
    var auj = today(true);
    var limb = date_add('a', -1, auj);
    var limh = date_add('a', 2, auj);
    if (deb < limb) {
        alert('Attention, date trop éloignée dans le temps.');
        sais_debut.focus();
        return false;
    }
    if (fin > limh) {
        alert('Attention, date trop éloignée dans le temps.');
        sais_fin.focus();
        return false;
    }

    /* Conservation des dates */
    var hsais_debut = document.getElementById('hsais_debut');
    var hsais_fin = document.getElementById('hsais_fin');

    hsais_debut.value = deb;
    hsais_fin.value = fin;

    return true;
}

/* Évènements sur gesdates et recherche */
function gesdates() {
    var gd_res = document.getElementById('gd_res');
    gd_res.onclick = soumettre3;

    var table = document.getElementById('annuel');

    if (table != null) {
        var cells = table.getElementsByTagName('td');

        for (var i = 0, len = cells.length ; i < len ; i++) {
            if (cells[i].id) {
                cells[i].style.cursor = 'pointer';
                cells[i].onclick = saisie_dates;
            }
        }
    }
    evnt_dates();

    /* Confirmation globale */

    var gd_confglob = document.getElementById('gd_confglob');
    if (gd_confglob) {
        gd_confglob.onclick = confirm_confglob;
    }

    /* Application de la règle de planification */

    var gd_regplan = document.getElementById('gd_regplan');
    if (gd_regplan) {
        gd_regplan.onclick = confirm_regplan;
    }

    /* Report N+1 */

    var gd_projette = document.getElementById('gd_projette');
    if (gd_projette) {
        gd_projette.onclick = confirm_report;
    }
    
    var gd_purge = document.getElementById('gd_purge');
    if (gd_purge) {
        gd_purge.onclick = confirm_purge;
    }
}

/* Soumettre ------------------------------------------------------------------------------------ */
function soumettre3() {
    document.gd_sel.submit();
}
