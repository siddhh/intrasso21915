/* SPPE
 * job.js
 * Javascript pour le détail d'un job
 */

window.onload = job_init;

/* job_init ----------------------------------------------------------------------------------------
 * Initialisation au chargement
 */
function job_init() {
    var steps = document.getElementById('steps');
    if (steps) {
        steps.onclick = aff_page;
    }
    var job = document.getElementById('job');
    if (job) {
        job.onclick = aff_page;
    }
}

/* aff_page ----------------------------------------------------------------------------------------
 * Affiche la page des jobs ou des steps
 */
function aff_page() {
    document.location = this.id + '_detail.php' + document.location.search;
}

// fin
