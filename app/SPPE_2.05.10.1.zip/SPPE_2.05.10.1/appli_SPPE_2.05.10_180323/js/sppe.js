/* SPPE : Suivi du Plan de Production des Exploitations
 * SI-2A DME - DISI PARIS NORMANDIE - ESI ROUEN LM
 * Avril 2014 */

var HABIL_GESTION_DATE = 4;
var HABIL_REFERENTIEL_BE = 16;
var HABIL_REALISE_MANUEL = 64;


var droite;
var gauche;
var logo;
var menu;
var page;
var tete;
var titre;
var utilisateur;
var filtres;
var calendrier;

/* Éléments sélectionnés par l'utilisateur */
var sel_dom;    // Domaine
var sel_esi;    // ESI
var sel_app;    // Application
var sel_chn;    // Chaîne
var sel_pro;    // Processus
var sel_sui;    // Afficher le suivi simplifié
var sel_ave;    // Afficher les travaux à venir

var sel_cal;    // Calendrier
var cmd_prec;
var cmd_suiv;
var cmd_mod;
var cmd_auj;

var acq_suppr_proc;

var cnx_info;
var messages;

var idencours;

/* Initiateur */

window.onload = initialise;

/* Initialisation ------------------------------------------------------------------------------- */

function initialise() {

    /* Instanciation des éléments du DOM */

    droite = document.getElementById('droite');
    gauche = document.getElementById('gauche');
    logo = document.getElementById('logo');
    menu = document.getElementById('menu');
    page = document.getElementById('page');
    tete = document.getElementById('tete');
    titre = document.getElementById('titre');
    utilisateur = document.getElementById('utilisateur');
    filtres = document.getElementById('filtres');
    calendrier = document.getElementById('calendrier');

    sel_dom = document.getElementById('sel_dom');
    sel_esi = document.getElementById('sel_esi');
    sel_app = document.getElementById('sel_app');
    sel_chn = document.getElementById('sel_chn');
    sel_pro = document.getElementById('sel_pro');
    sel_sui = document.getElementById('sel_sui');
    sel_ave = document.getElementById('sel_ave');

    sel_cal = document.getElementById('sel_cal');
    cmd_prec = document.getElementById('cmd_prec');
    cmd_suiv = document.getElementById('cmd_suiv');
    cmd_mod = document.getElementById('cmd_mod');
    cmd_auj = document.getElementById('cmd_auj');
    acq_suppr_proc = document.getElementById('acq_suppr_proc');

    cnx_info = document.getElementById('cnx_info');
    messages = document.getElementById('messages');

    /* Gestion des évènements */

//    window.onresize = agencement;
    sel_dom.onchange = soumettre;
    sel_esi.onchange = soumettre;
    sel_app.onchange = soumettre;
    sel_chn.onchange = soumettre;
    sel_pro.onchange = soumettre;
    sel_sui.onclick = soumettre;
    sel_ave.onclick = soumettre;

    sel_cal.onchange = soumettre2;
//    cmd_prec.onclick = nettoie_url;
//    cmd_suiv.onclick = nettoie_url;
    cmd_mod.onclick = nettoie_url;
    cmd_auj.onclick = nettoie_url;

    if (acq_suppr_proc != undefined) {
        acq_suppr_proc.onclick = confirm_suppr_proc;
    }

//    bajb_backdetect.OnBack = retour_arriere;
    // window.onstatechange = retour_arriere;

    /* Agencement de la page */

    if (page_affichee == 'accueil' || page_affichee == 'grille') {
        calendrier.style.display = 'block';
//        agencement();
        filtres.style.display = 'block';
    }
//    agencement();
    sel_bouton();

//    if (cnx_info != undefined) {
//        setTimeout(function() { cnx_info.style.display = 'none'; agencement(); }, 2000);
//    }
//    if (messages != undefined) {
//        setTimeout(function() { messages.style.display = 'none'; agencement(); }, 8000);
//    }

    /* Activation des saisies sur grille */
    if (page_affichee == 'gesdates') {
        gesdates();
    } else {
        if (cmd_bouton == 'cmd_rea') {
            realise_init();
        } else {
        	var habil = false;
        	for(var i in droits){
        		habil = habil || (droits[i] & HABIL_GESTION_DATE);
//        		habil = admin || (habil || (droits[i] & 4));
        	}
        	habil = admin || habil;
            if (habil) {
                sais_dates();
                evnt_dates();
            }
        }
    }

    /* Administration */
    var h6_admin_prefs = document.getElementById('h6_admin_prefs');
    if (h6_admin_prefs) {
        
        var h6_admin_users = document.getElementById('h6_admin_users');
        var h6_admin_gestionDate = document.getElementById('h6_admin_gestionDate');
        var h6_admin_appli = document.getElementById('h6_admin_appli');
        var h6_admin_service = document.getElementById('h6_admin_service');
        
        h6_admin_prefs.onclick = permute_prefs;
        if (h6_admin_users){
        	h6_admin_users.onclick = permute_prefs;
        }
        if (h6_admin_gestionDate){
        	h6_admin_gestionDate.onclick = permute_prefs;
        }
        if (h6_admin_appli){
        	h6_admin_appli.onclick = permute_prefs;
        }
        if (h6_admin_service){
        	h6_admin_service.onclick = permute_prefs;
        }
        var panel = document.getElementById('activ_panel');
        if (panel) {
            var activ_panel = document.getElementById('h6_' + panel.value);
            if (activ_panel) {
                activ_panel.onclick();
            }
        }
    }
    /* Administration SI */
    if (h6_admin_prefs) {
        adminsi_init();
    }
}

/* Confirmation de la suppression d'une occurrence ---------------------------------------------- */
function confirm_suppr_proc() {    
    var acq_suppr_nom = document.getElementById('acq_suppr_nom');
    if (acq_suppr_nom.value.trim() == '') {
        cf = false;
    } else {
        var cf = confirm("Confirmez-vous la suppression du processus ?");
        if (cf) {
            var acq_suppr_conf = document.getElementById('acq_suppr_conf');
            acq_suppr_conf.value = 'OUI';
        }
    }
    return cf;
}

/* Évènements de saisie des dates */
function evnt_dates() {
    /* Prise de main on Submit */

    var cmda = document.getElementById('cmd_sais_enrgt');
    var cmdb = document.getElementById('cmd_sais_suiv');
    var cmds = document.getElementById('cmd_sais_suppr');
    var cmdr = document.getElementById('cmd_sais_rest');
    var priv = document.getElementById('prive_suppr');

    if (cmda) {
        cmda.onclick = saisie_verif;
    }

    if (cmdb) {
        cmdb.onclick = saisie_verif;
    }

    if (cmds) {
        cmds.onclick = confirm_suppr;
    }

    if (cmdr) {
        cmdr.onclick = confirm_rest;
    }

    if (priv) {
        priv.onclick = confirm_priv;
    }

    /* Calendrier et RAZ */

    var sais_debut_eff = document.getElementById('sais_debut_eff');
    var sais_debut_cal = document.getElementById('sais_debut_cal');
    var sais_debut = document.getElementById('sais_debut');
    var sais_fin_eff = document.getElementById('sais_fin_eff');
    var sais_fin_cal = document.getElementById('sais_fin_cal');

    if (sais_debut_eff != undefined && sais_debut_eff != null) {
        sais_debut_eff.onclick = efface;
        sais_debut_cal.onclick = calend;
        sais_debut_cal.onblur = change_fin;
        sais_debut.onblur = change_fin;
        sais_fin_eff.onclick = efface;
        sais_fin_cal.onclick = calend;
    }

    /* Marquage de la journée */

    var idencours = document.getElementById('idencours');
    if (idencours) {
        var videncours = idencours.value;
        if (videncours.length > 3) {
            var jour = document.getElementById(videncours);
            if (jour) {
                jour.style.border = '3px solid blue';
            }
        }
    }
}

/* nettoie_url -------------------------------------------------------------------------------------
 * Nettoie l'URL avant soumission
 */
function nettoie_url() {
    document.sppe_calendrier.action = document.URL.split('?')[0];
    return true;
}

/* Permutation administration ----------------------------------------------------------------------
 * Permute les différents panels en administration
 */
function permute_prefs() {
    var admin_prefs = document.getElementById('admin_prefs');
    var admincq = document.getElementById('admin_gestionDate');
    var admin_users = document.getElementById('admin_users');
    var admin_appli = document.getElementById('admin_appli');
    var admin_service = document.getElementById('admin_service');

    
    admin_prefs.style.display = 'none';
    if (admincq){
    	admincq.style.display = 'none';
    }
    if (admin_users){
    	admin_users.style.display = 'none';
    }
    if (admin_appli){
    	admin_appli.style.display = 'none';
    }
    if (admin_service){
    	admin_service.style.display = 'none';
    }

    document.getElementById(this.id.substr(3)).style.display = 'block';
}

/* Retour arrière ------------------------------------------------------------------------------- */
//function retour_arriere() {
//    alert("Évitez d'utiliser la touche retour arrière\nde votre navigateur avec SPPE.\n"
//        + "SPPE produit de nombreuses pages dynamiques\nque le navigateur n'est pas\n"
//        + "en mesure de rétablir correctement.\n"
//        + "Privilégiez l'utilisation du menu SPPE.");
//    window.history.forward(1);
//}

/* sais_date ---------------------------------------------------------------------------------------
 * Permet la saisie des dates pour le CQ */
function sais_dates() {
    
    var table = document.getElementById('grille');
    if (table != undefined && table != null) {
        var cells = table.getElementsByTagName('td');
        for (var i = 0, len = cells.length ; i < len ; i++) {
        	var domaine = cells[i].dataset.domaine;
        	
            if (cells[i].id && (domaine!='undefined')){
            	var habil = false;
            	habil = admin || (habil || (droits[domaine] & HABIL_GESTION_DATE));
            	if (habil){
            		cells[i].style.cursor = 'pointer';
            		cells[i].onclick = saisie_dates;
            	}
            }
        }
    }
}

/* saisie_dates ------------------------------------------------------------------------------------
 * Appelle la saisie des dates */
function saisie_dates() {
    if (page_affichee == 'gesdates') {
        document.location = 'index.php?page=dates?&pln_id='+this.id;
    } else {
        document.location = 'index.php?page=prevision&pln_id='+this.id;
    }
}

/* sel_bouton ----------------------------------------------------------------------------------- */
function sel_bouton() {
    if (cmd_bouton != '') {
        var bouton = document.getElementById(cmd_bouton);
            if (bouton != undefined && bouton != null) {
            bouton.style.color = '#CE8C1E';
            bouton.style.fontWeight = 'bold';
        }
    }
    var cnx_log = document.getElementById('cnx_log');
    if (cnx_log != undefined && cnx_log != null) {
        cnx_log.focus();
    }
}

/* Soumettre ------------------------------------------------------------------------------------ */
function soumettre() {
    document.sppe_titre.action = document.URL.split('?')[0];
    document.sppe_titre.submit();
}

/* Soumettre2 ----------------------------------------------------------------------------------- */
function soumettre2() {
    nettoie_url();
    console.log(document.sppe_calendrier);
    document.sppe_calendrier.submit();
}

/* popup_window ------------------------------------------------------------------------------------
 * Ouvre une fenêter PopUp
 * - url : adresse
 * - titre : titre de la fenêtre
 * - w : largeur
 * - h : hauteur
 * --> retourne l'identifiant de la fenêtre
 */
function popup_window(url, titre, w, h) {
    var wLeft = window.screenLeft ? window.screenLeft : window.screenX;
    var wTop = window.screenTop ? window.screenTop : window.screenY;
    var wWidth = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth;
    var wHeight = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight;
    var left = wLeft + (wWidth / 2) - (w / 2);
    var top = wTop + (wHeight / 2) - (h / 2);
    return window.open(url, titre, 'directories=0,titlebar=1,toolbar=0,location=0,status=0,' +
        'menubar=0,scrollbars=1,resizable=1,' +
        'width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
}

/* Fin */
