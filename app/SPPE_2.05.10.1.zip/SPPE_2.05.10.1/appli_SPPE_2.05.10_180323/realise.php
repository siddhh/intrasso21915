<?php

$page = 'grille';
$cmdb = 'cmd_rea';
$titre_tableau = 'Calendrier prévisionnel &amp; réalisé';
$realise = true;

require 'inc/page.php';

?>
