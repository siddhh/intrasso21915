<?php

    require_once 'inc/ferie.php';

    /* ---------------------------------------------------------------------------------------------
     * Cellule d'un calendrier
     *
     * Appel : new Cellule(date initiale, nombre de jours)
     *
     * Construit une cellule de tableau calendrier pour sortie PDF
     * ------------------------------------------------------------------------------------------ */

    class Cellule_pdf {

        /* Attributs ============================================================================ */

        private $classes;   // Classes associées à la cellule
        private $curseur;   // Curseur entier des jours fériés
        private $feries;    // Tableau binaire de jours fériés
        private $journee;   // Date du jour associé à la cellule
        private $initial;   // Date initiale au format ISO
        private $jours;     // Nombre de jours à traiter
        private $un_jour;   // Interval d'un jour
        private $ce_jour;   // Date du jour en ISO
        private $largeur;   // Largeur de la cellule
        private $pdf;       // Objet PDF utilisé
        private $pasti=0;   // Pastille rouge ou noire absente par défaut

        /* Méthodes ============================================================================= */

        /* Constructeur
         * $diso : date initiale au format ISO
         * $jours : nombre de jours traités
         * $largeur : largeur de la cellule
         * $pdf : objet PDF */
        function __construct($diso, $jours, $largeur, $pdf) {

            /* Création de l'objet DateTime associé à la cellule */
            $this->journee = new DateTime($diso);

            /* Définition de l'interval d'un jour */
            $this->un_jour = new DateInterval('P1D');

            /* Préparation des jours fériés pour la période entière */
            $this->feries = feries($this->journee, $jours);

            /* Conservation du nombre de jours initial */
            $this->jours = $jours;

            /* Conservation de la date initiale pour permettre la réitération de la période */
            $this->initial = $diso;

            /* Objet PDF */
            $this->pdf = $pdf;

            /* Largeur de la cellule */
            $this->largeur = $largeur;

            /* Aujourd'hui */
            $this->ce_jour = date('Y-m-d');

            /* Initialisation de la période */
            $this->raz();
        }

        /* classe ----------------------------------------------------------------------------------
         * ajoute une classe à la cellule
         * $c : nom de la classe */
        function classe($c) {
            if ($c) $this->classes .= $c.' ';
        }

        /* est_ferie -------------------------------------------------------------------------------
         * --> retourne 1 si le jour courant est férié, 0 sinon
         */
        function est_ferie() {
            return ($this->feries{$this->curseur} == '0' ? 1 : 0);
        }

        /* etat ------------------------------------------------------------------------------------
         * retourne l'état des classes */
        function etat() {
            return $this->classes;
        }

        /* fabrique --------------------------------------------------------------------------------
         * fabrique la cellule PDF
         * $contenu : contenu de la cellule
         * $fer : mise en évidence des jours fériés */
        function fabrique($contenu, $fer=true) {

            $souligne = false;

            $this->pdf->SetDrawColor(169,169,169);  // darkgray
            $this->pdf->SetFillColor(255,255,255);  // blanc
            $this->pdf->SetTextColor(0,0,0);        // noir
            $this->pdf->SetFont('','',8);

            /* mise en évidence jour férié */
            if ($this->est_ferie() and $fer) {
                $c = $_SESSION['prf_coul_ferie'];
                $this->pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
            }

            $classes = trim($this->classes);
            if ($classes) {
                $elements = explode(' ', $classes);
                foreach ($elements as $e) {
                    switch ($e) {
                        case 'termine' :
                            $c = $_SESSION['prf_coul_termine'];
                            break;
                        case 'encours' :
                            $c = $_SESSION['prf_coul_en_cours'];
                            break;
                        case 'abort' :
                            $c = $_SESSION['prf_coul_en_abort'];
                            break;
                        case 'hors_delai_avant' :
                            $c = $_SESSION['prf_coul_hors_delai_avant'];
                            break;
                        case 'hors_delai_apres' :
                            $c = $_SESSION['prf_coul_hors_delai_apres'];
                            break;
                        case 'supprime' :
                            $this->pdf->SetFont('','B',9);
                            $this->pdf->SetTextColor(0,0,0);  // blanc
                            $c = '#CCCCCC';
                            break;
                        case 'sure' :
                        case 'pas_sure' :
                            $c = $_SESSION['prf_coul_calcule'];
                            break;
                        case 'sure_manuel' :
                        case 'pas_sure_manuel' :
                            $c = $_SESSION['prf_coul_manuel'];
                            break;
                        case 'souligne_rouge';
                            $souligne = true;
                            break;
                        case 'cell_info' :
                            $this->pdf->SetTextColor(255,255,255);  // blanc
                            break;
                    }
                    if (isset($c)) 
                        $this->pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
                }
            }

            $this->pdf->Cell($this->largeur,5,$contenu,1,0,'C',1);

            /* mise en évidence si aujourd'hui */
            if ($this->iso() == $this->ce_jour) {
                $x = $this->pdf->GetX() - 0.2;
                $y = $this->pdf->GetY();
                $this->pdf->SetLineWidth(0.6);
                $this->pdf->SetDrawColor(206,140,30);   // jaune DGFIP
                $this->pdf->Line($x,$y,$x,$y+5);
                $x -= $this->largeur - 0.4;
                $this->pdf->Line($x,$y,$x,$y+5);
                $this->pdf->SetLineWidth(0.2);
                $this->pdf->SetDrawColor(169,169,169);  // darkgray
            }

            /* soulignement */
            if ($souligne) {
                $x = $this->pdf->GetX() - 0.4;
                $y = $this->pdf->GetY() + 4.6;
                $this->pdf->SetLineWidth(0.5);
                $this->pdf->SetDrawColor(192,12,19);   // rouge
                $this->pdf->Line($x,$y,$x-$this->largeur+0.8,$y);
                $this->pdf->SetLineWidth(0.2);
                $this->pdf->SetDrawColor(169,169,169);  // darkgray
            }

            /* pastille rouge */
            if ($this->pasti > 0) {
                $x = $this->pdf->GetX() - 4.95;
                $y = $this->pdf->GetY() + 3.95;
                $this->pdf->SetDrawColor(($this->pasti-1)*255,0,0);  // rouge vif ou noir
                $this->pdf->SetFillColor(($this->pasti-1)*255,0,0);  // idem
                $this->pdf->circle($x,$y,0.5,'FD');
                $this->pdf->SetDrawColor(169,169,169);  // darkgray
                $this->pdf->SetFillColor(255,255,255);  // blanc
                $this->pasti = 0;
            }
        }

        /* iso -------------------------------------------------------------------------------------
         * retourne le jour de la cellule au format AAAA-MM-JJ */
        function iso() {
            return $this->journee->format('Y-m-d');
        }

        /* jour ------------------------------------------------------------------------------------
         * retourne l'objet DateTime associé à la cellule */
        function jour() {
            return $this->journee;
        }

        /* ok --------------------------------------------------------------------------------------
         * indique s'il y a encore une journée à traiter */
        function ok() {
            return ($this->curseur < $this->jours);
        }

        /* pastille --------------------------------------------------------------------------------
         * demande l'ajout d'une pastille rouge pour marquer l'abort au cours du réalisé
         * $etat : abort ou hors prévisionnel
         */
        function pastille($etat) {
            $this->pasti = ($etat == SPPE_ETAT_ABORT ? 2 : 1);
        }

        /* raz -------------------------------------------------------------------------------------
         * réinitialisation de l'objet à la date initiale */
        function raz() {
            $this->classes = '';
            $this->curseur = 0;
            $this->journee->setDate(
                intval(substr($this->initial, 0, 4), 10),
                intval(substr($this->initial, 5, 2), 10),
                intval(substr($this->initial, 8, 2), 10)
            );
        }

        /* suivant ---------------------------------------------------------------------------------
         * se place sur le jour suivant */
        function suivant() {

            /* Jour suivant */
            $this->journee->add($this->un_jour);
            $this->curseur++;

            /* RAZ */
            $this->classes = '';
        }
    }

?>
