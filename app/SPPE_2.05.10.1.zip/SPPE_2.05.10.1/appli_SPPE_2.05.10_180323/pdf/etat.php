<?php

require 'fpdf17/fpdf.php';
require 'inc/selections.php';

/* Prépare la construction d'un état ---------------------------------------------------------------
 *
 * Paramètres :
 *  etat : état à inclure (obligatoire)
 *  sens : orientation de la feuille L ou P (par défaut)
 *  saut : 1 si saut de page automatique, 0 sinon (défaut)
 * ---------------------------------------------------------------------------------------------- */

/* Redéfinition de la classe PDF */

class PDF extends FPDF {

	/* Entête de page */
	function Header() {
	}

	function Circle($x, $y, $r, $style='D') {
		$this->Ellipse($x,$y,$r,$r,$style);
	}

	function Ellipse($x, $y, $rx, $ry, $style='D') {
		if($style=='F'){
			$op='f';
		}elseif($style=='FD' || $style=='DF'){
			$op='B';
		}else{
			$op='S';
		}
		$lx=4/3*(M_SQRT2-1)*$rx;
		$ly=4/3*(M_SQRT2-1)*$ry;
		$k=$this->k;
		$h=$this->h;
		$this->_out(sprintf('%.2F %.2F m %.2F %.2F %.2F %.2F %.2F %.2F c',
				($x+$rx)*$k,($h-$y)*$k,
				($x+$rx)*$k,($h-($y-$ly))*$k,
				($x+$lx)*$k,($h-($y-$ry))*$k,
				$x*$k,($h-($y-$ry))*$k));
		$this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c',
				($x-$lx)*$k,($h-($y-$ry))*$k,
				($x-$rx)*$k,($h-($y-$ly))*$k,
				($x-$rx)*$k,($h-$y)*$k));
		$this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c',
				($x-$rx)*$k,($h-($y+$ly))*$k,
				($x-$lx)*$k,($h-($y+$ry))*$k,
				$x*$k,($h-($y+$ry))*$k));
		$this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c %s',
				($x+$lx)*$k,($h-($y+$ry))*$k,
				($x+$rx)*$k,($h-($y+$ly))*$k,
				($x+$rx)*$k,($h-$y)*$k,
				$op));
	}

	/* Pied de page */
	function Footer() {
		$this->SetY(-15);
		$this->SetFont('Times','I',7);
		$this->SetTextColor(144,144,144);    // gris foncé
		$this->Cell(0,5,utf8_decode('produit le '.date('d/m/Y à H:i')),0,0,'C');
		$this->SetX(-50);
		$this->Cell(40,5,'page '.$this->PageNo().' / {nb}',0,0,'R');
		$this->SetFont('ARIAL','B',9);
		$this->SetX(10);
		$this->Write(5,'SPPE');
	}

	/* Tronque une chaîne de caractère à la longueur
	 *  s : chaîne de caractère
	 *  l : longueur maxi */
	function tronque($s, $l) {
		$l = $l - 0.5;
		while ($this->GetStringWidth($s) > $l){
			$s = substr($s, 0, strlen($s) - 1);
		}
		return $s;
	}
}

/* affiche_selections ------------------------------------------------------------------------------
 * Affiche les sélections en cours
 * $db : base de données
 * $pdf : objet PDF
 * $realise : vrai si réalisé
 * $limite : position verticale limite
 */
function affiche_selections($db, $pdf, $realise, $limite) {

	/* domaine */
	$sel_dom = 'Tous';
	if (array_key_exists('sel_dom', $_SESSION)) {
		$id = $_SESSION['sel_dom'];
		if ($id != '0') {
			$req = 'SELECT dom_nom FROM domaines WHERE dom_id=$1';
			$res = pg_query_params($db, $req, array($id));
			if ($lu = pg_fetch_row($res)){
				$sel_dom = $lu[0];
			}
		}
	}

	/* ESI */
	$sel_esi = '~ Vue nationale ~';
	if (array_key_exists('sel_esi', $_SESSION)) {
		$id = $_SESSION['sel_esi'];
		if (($id != '0') || $realise) {
			if ($id == '0') {
				$req = 'SELECT esi_nom FROM esi ORDER BY esi_nom LIMIT 1';
				$res = pg_query($db, $req);
			} else {
				$req = 'SELECT esi_nom FROM esi WHERE esi_id=$1';
				$res = pg_query_params($db, $req, array($id));
			}
			if ($lu = pg_fetch_row($res)){
				$sel_esi = $lu[0];
			}
		}
	}

	/* suivi simplifié */
	$sel_sui = 'Avec';
	if (array_key_exists('sel_sui', $_SESSION)) {
		if ($_SESSION['sel_sui'] != 'on'){
			$sel_sui = 'Sans';
		}
	}
	$sel_sui .= ' suivi simplifié';

	/* Travaux à venir */
	$sel_ave = 'Tous les travaux';
	if (array_key_exists('sel_ave', $_SESSION)) {
		if ($_SESSION['sel_ave'] == 'on'){
			$sel_ave = 'Travaux à venir seulement';
		}
	}

	/* équipe ou application */
	$sel_app = 'Toutes';
	if (array_key_exists('sel_app', $_SESSION)) {
		$id = $_SESSION['sel_app'];
		if ($id != '0') {
			if ($id{0} == 'A'){
				$req = 'SELECT app_nom FROM applications WHERE app_id=$1';
			}else{
				$req = 'SELECT serv_nom FROM services WHERE serv_id=$1';
			}
			$res = pg_query_params($db, $req, array(substr($id, 1)));
			if ($lu = pg_fetch_row($res)){
				$sel_app = $lu[0];
			}
		}
	}

	/* chaîne */
	$sel_chn = 'Toutes';
	if (array_key_exists('sel_chn', $_SESSION)) {
		$id = $_SESSION['sel_chn'];
		if ($id != '0') {
			$req = 'SELECT chn_nom FROM chaines WHERE chn_id=$1';
			$res = pg_query_params($db, $req, array($id));
			if ($lu = pg_fetch_row($res)){
				$sel_chn = $lu[0];
			}
		}
	}

	/* processus */
	$sel_pro = 'Tous';
	if (array_key_exists('sel_pro', $_SESSION)) {
		$id = $_SESSION['sel_pro'];
		if ($id != '0') {
			$req = 'SELECT pro_nom FROM processus WHERE pro_id=$1';
			$res = pg_query_params($db, $req, array($id));
			if ($lu = pg_fetch_row($res)){
				$sel_pro = $lu[0];
			}
		}
	}

	/* affichage */

	if ($pdf->GetY() > $limite - 20) {
		$pdf->AddPage();
	} else {
		$pdf->Ln(8);
	}
	$pdf->SetDrawColor(144,144,144);    // gris foncé
	$pdf->SetFillColor(144,144,144);    // gris foncé
	$pdf->SetTextColor(255,255,255);    // blanc
	$pdf->SetLineWidth(0.2);

	$pdf->SetFont('Times','',8);
	$pdf->SetX(10);
	$pdf->Cell(190,4,utf8_decode('Critères sélectionnés'),1,1,'L',1);

	$pdf->SetTextColor(144,144,144);    // gris foncé

	$pdf->SetX(10);
	$pdf->Cell(20,4,'Domaine :','L',0,'R');
	$pdf->SetFont('','B',8);
	$pdf->Cell(15,4,utf8_decode($sel_dom));
	$pdf->SetFont('','',8);
	$pdf->Cell(15,4,'ESI :',0,0,'R');
	$pdf->SetFont('','B',8);
	$pdf->Cell(40,4,utf8_decode($sel_esi));
	$pdf->Cell(100,4,utf8_decode($sel_sui.', '.$sel_ave),'R',1,'C');

	$pdf->SetFont('Times','',8);
	$pdf->SetX(10);
	$pdf->Cell(20,4,utf8_decode('Équi./appli :'),'LB',0,'R');
	$pdf->SetFont('','B',8);
	$pdf->Cell(15,4,utf8_decode($sel_app),'B');
	$pdf->SetFont('','',8);
	$pdf->Cell(15,4,utf8_decode('Chaîne :'),'B',0,'R');
	$pdf->SetFont('','B',8);
	$pdf->Cell(30,4,utf8_decode($sel_chn),'B');
	$pdf->SetFont('','',8);
	$pdf->Cell(25,4,'Processus :','B',0,'R');
	$pdf->SetFont('','B',8);
	$pdf->Cell(85,4,utf8_decode($sel_pro),'BR');
}

/* Principal ---------------------------------------------------------------- */

/* Préparation */

$etat = '';
$sens = 'P';
$saut = false;

if (getPost('etat')!=''){
	$etat = getPost('etat');
}
if (getPost('sens')!=''){
	$sens = getPost('sens');
}
if (($sens != 'P') && ($sens != 'L')){
	$sens = 'P';
}
if (getPost('saut')!=''){
	$saut = intval(getPost('saut'));
}
if ($saut == 1){
	$saut = true;
}else{
	$saut = false;
}

/* Initialisation */

$pdf = new PDF($sens,'mm','A4');
$pdf->Open();
$pdf->AliasNbPages();
$pdf->SetAutoPageBreak($saut);
$pdf->AddPage();

$pdf->SetFont('Arial','B',12);

$pdf->SetFillColor(224,224,224);

$nom_pdf = 'sppe.pdf';

/* Vérification de la session */

if (array_key_exists('uti_id', $_SESSION)) {
	if ($etat) {
		require $etat.'.php';
	} else {
		$pdf->Write(4, utf8_decode('Erreur : état non précisé.'));

	}
} else {
	$pdf->Write(4, utf8_decode('Erreur : session expirée ; veuillez rafraîchir le calendrier.'));
}

$pdf->Output($nom_pdf, 'I');
exit;
?>
