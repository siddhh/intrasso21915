<?php

    /* entete --------------------------------------------------------------------------------------
     * Entête répété chaque page
     * $pdf : objet PDF
     * $tit : titre calendaire
     * $col_pro : largeur de la colonne processus
     * $tjours : tableau des jours du mois
     * $realise : vrai si calendrier du réalisé
     * $titre_tableau : titre du tableau
     */

    function entete($pdf, $tit, $col_pro, $tjours, $realise, $titre_tableau) {

        if ($realise) $y = 15;
        else $y = 10;

        $pdf->SetDrawColor(169,169,169);    // darkgray
        $pdf->SetFillColor(238,238,238);    // gris léger
        $pdf->SetTextColor(206,140,30);     // jaune DGFIP

        $pdf->SetLineWidth(0.2);

        $pdf->SetFont('Arial','B',9);

        $pdf->SetXY(10,$y);
        $pdf->Cell(25+$col_pro,10,utf8_decode($titre_tableau),1,0,'C',1);

        $pdf->SetTextColor(0,0,0);     // noir
        $pdf->Cell(252-$col_pro,5,utf8_decode($tit),1,1,'C',1);

        $c = $_SESSION['prf_coul_ferie'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));

        $pdf->SetXY(35+$col_pro,$y+5);
        foreach ($tjours as $clef => $jour) {
            if ($jour[2]) {
                /* aujourd'hui */
                $pdf->SetDrawColor(206,140,30);     // jaune DGFIP
                $pdf->SetFillColor(206,140,30);     // jaune DGFIP
                $pdf->SetTextColor(249,231,199);    // beige
                $pdf->Cell(6,5,$clef+1,1,0,'C',1);
                $pdf->SetDrawColor(169,169,169);    // darkgray
                $pdf->SetTextColor(0,0,0);     // noir
                $c = $_SESSION['prf_coul_ferie'];
                $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
            } else {
                $pdf->Cell(6,5,$clef+1,1,0,'C',$jour[1]);
            }
        }

        $pdf->SetFont('Arial','',7);
        $pdf->SetXY(10,$y+10);
        $pdf->Cell($col_pro,5,'Nom du processus',1,0,'C');
        $pdf->Cell(25,5,utf8_decode('Chaînes'),1,0,'C');
        foreach ($tjours as $jour) {
            if ($jour[2]) {
                /* aujourd'hui */
                $pdf->SetDrawColor(206,140,30);     // jaune DGFIP
                $pdf->SetFillColor(206,140,30);     // jaune DGFIP
                $pdf->SetTextColor(249,231,199);    // beige
                $pdf->Cell(6,5,$jour[0],1,0,'C',1);
                $pdf->SetDrawColor(169,169,169);    // darkgray
                $pdf->SetTextColor(0,0,0);     // noir
                $c = $_SESSION['prf_coul_ferie'];
                $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
            } else {
                $pdf->Cell(6,5,$jour[0],1,0,'C',$jour[1]);
            }
        }
    }

    /* ------------------------------------------------------------------------------------------ */

    $deb = $_SESSION['sel_cal'].'-01';      // Date de début incluse

    $un_jour = new DateInterval('P1D');
    $un_mois = new DateInterval('P1M');

    $nwd = new DateTime($deb);
    $tsp = $nwd->getTimeStamp();
    $tit = strftime('%B %Y', $tsp);
    $libjours = '';

    $nwd->add($un_mois);
    $nwd->sub($un_jour);
    $nb_jours = intval($nwd->format('d'), 10);

    $col_pro = 66 + 6 * (31 - $nb_jours);   // Largeur de la colonne processus

    $cell = new Cellule_pdf($deb, $nb_jours, 6, $pdf);

    $tjours = array();
    while ($cell->ok()) {
        array_push($tjours,
            array(strftime('%a', $cell->jour()->getTimeStamp()),
                $cell->est_ferie(), ($cell->iso() == $jour_iso)));
        $cell->suivant();
    }

    entete($pdf, $tit, $col_pro, $tjours, $realise, $titre_tableau);

    $nom_pdf = 'SPPE_'.str_replace(' ', '_', $tit).'.pdf';
?>
