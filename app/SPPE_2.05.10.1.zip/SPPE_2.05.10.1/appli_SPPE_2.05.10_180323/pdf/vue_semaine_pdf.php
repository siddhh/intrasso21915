<?php

    /* entete --------------------------------------------------------------------------------------
     * Entête répété chaque page
     * $pdf : objet PDF
     * $tit : titre calendaire
     * $col_pro : largeur de la colonne processus
     * $tjours : tableau des jours du mois
     * $realise : vrai si calendrier du réalisé
     * $titre_tableau : titre du tableau
     */

    function entete($pdf, $tit, $col_pro, $tjours, $realise, $titre_tableau) {

        if ($realise) $y = 15;
        else $y = 10;

        $pdf->SetDrawColor(169,169,169);    // darkgray
        $pdf->SetFillColor(238,238,238);    // gris léger
        $pdf->SetTextColor(206,140,30);     // jaune DGFIP

        $pdf->SetLineWidth(0.2);

        $pdf->SetFont('Arial','B',9);

        $pdf->SetXY(10,$y);
        $pdf->Cell(117,5,utf8_decode($titre_tableau),1,0,'C',1);

        $pdf->SetTextColor(0,0,0);     // noir
        $pdf->Cell(70,5,utf8_decode($tit),1,0,'C',1);
        $pdf->Cell(90,5,'',1,1,'C',1);

        $c = $_SESSION['prf_coul_ferie'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));

        $pdf->SetFont('','',7);
        $pdf->SetXY(10,$y+5);
        $pdf->Cell(72,5,'Nom du processus',1,0,'C');
        $pdf->Cell(25,5,utf8_decode('Chaînes'),1,0,'C');
        $pdf->Cell(20,5,utf8_decode('Date de début'),1,0,'C');
        $pdf->SetFont('','B',7);
        foreach ($tjours as $jour) {
            if ($jour[2]) {
                /* aujourd'hui */
                $pdf->SetDrawColor(206,140,30);     // jaune DGFIP
                $pdf->SetFillColor(206,140,30);     // jaune DGFIP
                $pdf->SetTextColor(249,231,199);    // beige
                $pdf->Cell(10,5,$jour[0],1,0,'C',1);
                $pdf->SetDrawColor(169,169,169);    // darkgray
                $pdf->SetTextColor(0,0,0);     // noir
                $c = $_SESSION['prf_coul_ferie'];
                $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
            } else {
                $pdf->Cell(10,5,$jour[0],1,0,'C',$jour[1]);
            }
        }
        $pdf->SetFont('','',7);
        $pdf->Cell(20,5,'Date de fin',1,0,'C');
        $pdf->Cell(70,5,'Observations',1,0,'C');
    }

    /* ------------------------------------------------------------------------------------------ */

    $deb = $_SESSION['sel_cal'];    // Date de début incluse
    $nb_jours = 7;                  // Nombre de jours sur la période

    $cell = new Cellule_pdf($deb, 7, 10, $pdf);

    $col_pro = 72;

    $tsp = $cell->jour()->getTimeStamp();
    $tit = strftime('Semaine %V : du %e', $tsp);
    $lbm = strftime('%B', $tsp);
    $lby = strftime('%Y', $tsp);

    $tjours = array();
    while ($cell->ok()) {
        array_push($tjours,
            array(strftime('%a %e', $cell->jour()->getTimeStamp()),
                $cell->est_ferie(), ($cell->iso() == $jour_iso)));
        $cell->suivant();
    }

    $tsp = $cell->jour()->getTimeStamp() - 86400;
    $j = strftime(' au %e %B %Y', $tsp);
    $m = strftime('%B', $tsp);
    $y = strftime('%Y', $tsp);
    if ($m != $lbm) $tit .= ' '.$lbm;
    if ($y != $lby) $tit .= ' '.$lby;
    $tit .= $j;

    entete($pdf, $tit, $col_pro, $tjours, $realise, $titre_tableau);

    $xtit = explode(':', $tit);
    $nom_pdf = 'SPPE_'.str_replace(' ', '_', trim($xtit[1])).'.pdf';
?>
