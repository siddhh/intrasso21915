<?php

    require __DIR__ .'/Cellule_pdf.php';
    require __DIR__ .'/../sql/sql_realise.php';

    /* liste_chaines -------------------------------------------------------------------------------
     * Affiche les chaînes du processus
     * $liste : liste des chaines
     * $pdf : objet PDF
     * $cf : tableau des chaînes en fin de document
     * $pro : nom du processus
     * --> renseigne $cf si nécessaire
     */

    function liste_chaines($liste, $pdf, &$cf, $pro) {

        $x = explode(' ', $liste);
        $n = count($x);
        if ($n > 2) {
            $pdf->SetFont('','I',8);
            $pdf->Cell(25,5,utf8_decode($n.' chaînes'),1);
            if (!array_key_exists($pro, $cf)) {
                // mémorisation de la liste des chaînes du processus
                $cf[$pro] = $liste;
            }
        } else {
            $pdf->SetFont('','',8);
            $pdf->Cell(25,5,utf8_decode($liste),1);
        }
    }

    /* bulle ---------------------------------------------------------------------------------------
     * Construit la bulle d'information comme note de bas de page quand nécessaire
     * $obsv : observations
     * $note : notes de réalisé
     * $indice : retourne l'indice dans cette variable
     * $tableau : tableau des notes à compléter
     * --> retourne true quand une bulle est réellement ajoutée */
    function bulle($obsv, $note, &$indice, &$tableau) {

        static $compteur = 0;

        $texte = '';
        $rc = ($obsv or $note);

        if ($rc) {

            if ($obsv) {
                $texte = $obsv;
                if ($note) {
                    $texte .= ' / ';
                }
            }

            if ($note) {
                $texte .= $note;
            }

            $prec = '';
            $nbtb = count($tableau);
            if ($nbtb) $prec = $tableau[$nbtb - 1];
            if ($texte != $prec) {
                $compteur++;
                $indice = $compteur;
                array_push($tableau, $texte);
            }
        }

        return $rc;
    }

    /* ------------------------------------------------------------------------------------------ */

    /* Grille des processus -- prévisionnel et réalisé -- format PDF */

    $aujourdhui = new DateTime();
    $jour_iso = $aujourdhui->format('Y-m-d');

    $jours = '';

    $titre_tableau = 'Calendrier';
    if (array_key_exists('titre_tableau', $_REQUEST))
        $titre_tableau = $_REQUEST['titre_tableau'];

    /* Légende en réalisé */

    $realise = false;
    if (array_key_exists('realise', $_REQUEST))
        $realise = ($_REQUEST['realise'] == '1');

    if ($realise) {
        $pdf->SetY(10);
        $pdf->SetFont('Arial','B',7);
        $pdf->SetTextColor(255,255,255);   // blanc

        /* terminé */
        $c = $_SESSION['prf_coul_termine'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
        $pdf->SetX(10);
        $pdf->Cell(29,4,utf8_decode('terminé'),0,0,'C',1);

        /* en cours */
        $c = $_SESSION['prf_coul_en_cours'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
        $pdf->SetX(40);
        $pdf->Cell(29,4,utf8_decode('en cours'),0,0,'C',1);

        /* en abort */
        $c = $_SESSION['prf_coul_en_abort'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
        $pdf->SetX(70);
        $pdf->Cell(29,4,utf8_decode('en abort'),0,0,'C',1);

        /* hors délai avant*/
        $c = $_SESSION['prf_coul_hors_delai_avant'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
        $pdf->SetX(100);
        $pdf->Cell(29,4,utf8_decode('avant prévisionnel'),0,0,'C',1);
        
        /* hors délai après*/
        $c = $_SESSION['prf_coul_hors_delai_apres'];
        $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
        $pdf->SetX(100);
        $pdf->Cell(29,4,utf8_decode('après prévisionnel'),0,0,'C',1);
    }

    $vue_semaine = (strlen($_SESSION['sel_cal']) > 7);

    if ($vue_semaine) {

        require 'vue_semaine_pdf.php';
        
    } else {

        require 'vue_mois_pdf.php';

    }

    $fin = $cell->iso();    /* Fin non incluse */

    /* Sélection des processus */
    require __DIR__ .'/../inc/grille_selection.php';

    $suivi_simplif = false;

    if (pg_num_rows($res)) {

        /* Préparation du suivi simplifié et des processus présentant plusieurs occurrences */

        $processus = array();
        prepare_processus($processus, $res);

        /* Affichage des lignes du calendrier */

        $un_mois = 30;
        $manuel = array('t' => '_manuel', 'f' => '');

        $indice = 0;
        $remarques = array();       // Tableau des annotations et observations
        $chaines_fin = array();     // Tableau des chaînes affichées en fin de document

        foreach($processus as $proc) {

            $lu = array_shift($proc);
            $prev_suivante = occurrence_suivante($proc, $realise, $deb);

            $timbre1 = new DateTime($lu['pro_timbre']);

            /* Notes du CQMF */
            $observation = trim($lu['pln_notes'])
            .((estHabil(HABIL_GESTION_DATE,$lu['dom_id'])and trim($lu['pln_prive'])) ?
                    (trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
            $observations = $observation;

            /* Notes du réalisé */
            $annotation = '';
            if (array_key_exists('rea_notes', $lu)) {
                $annotation = trim($lu['rea_notes']);
            }

            /* nom du processus en rouge si modifié depuis moins d'un mois */
            $age = intval($aujourdhui->diff($timbre1)->format('%a'), 10);
            $pro_classe = ($age < $un_mois ? ' class="rouge"' : '');
            $rouge = ($age < $un_mois);
            /* nom du processus en italique s'il comporte une rupture */
            $pro_classe = 'B';
            if ($lu['pro_rupture'] == 't') $pro_classe = 'I'; // en italique

            /* ---------- NOUVELLE LIGNE ---------- */

            if ($pdf->GetY() > 185) {
                $pdf->AddPage();
                entete($pdf, $tit, $col_pro, $tjours, false, $titre_tableau);
            }

            /* mise en évidence du passage aux processus en suivi simplifié */
            $pdf->SetDrawColor(169,169,169);    // darkgray
            if ($lu['tri1'] == 2 and !$suivi_simplif) {
                $suivi_simplif = true;
                $y = $pdf->getY() + 5;
                $c = $_SESSION['prf_coul_ferie'];
                $pdf->SetFillColor(rgb('r', $c),rgb('g', $c),rgb('b', $c));
                $pdf->rect(10,$y,277,3,'DF');
                $pdf->ln(3);
            }

            $pdf->Ln(5);
            $pdf->SetX(10);
            $pdf->SetFillColor(255,255,255);    // blanc
            $pdf->SetFont('Arial',$pro_classe,8);
            if ($rouge) $pdf->SetTextColor(192,12,19);
            else $pdf->SetTextColor(0,0,0);

            /* nom du processus et liste des chaînes */
            $pdf->Cell($col_pro,5,utf8_decode($lu['pro_nom']),1,0,'L');
            $pdf->SetTextColor(0,0,0);

            if (processus_recent($aujourdhui, $jour_iso, $lu, $proc, $age)) {
                // panneau d'avertissement si du jour
                $x = $pdf->getX();
                $y = $pdf->getY();
                $pdf->setXY($x-80,$y);
                $pdf->image('../img/du_jour.png',$x-5.5,$y+0.5,4.5);
                $pdf->setXY($x,$y);
            }

            liste_chaines(trim($lu['lst_chaines']), $pdf, $chaines_fin, $lu['pro_nom']);

            if ($vue_semaine) {
                $pdf->SetFont('','',8);
                $borne = ($lu['pln_debut'] < $deb ? jma($lu['pln_debut']) : '');
                $pdf->Cell(20,5,$borne,1,0,'C');
            }
            $pdf->SetFont('','B',8);

            $recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);

            $j = 0;
            $cell->raz();

            while ($cell->ok()) {

                $j++;
                $raz = false;
                $courant = $cell->iso();

                /* Lecture de l'occurrence suivante pour les processus en suivi simplifié
                 * quand la date courante atteint le début de l'occurrence suivante */

                if ($courant >= $prev_suivante) {
                    $lu = array_shift($proc);
                    $prev_suivante = occurrence_suivante($proc, $realise, $courant);
                    $observation = trim($lu['pln_notes'])
                    .((estHabil(HABIL_GESTION_DATE,$lu['dom_id'])and trim($lu['pln_prive'])) ?
                            (trim($lu['pln_notes']) ? ' / ' : '').trim($lu['pln_prive']) : '');
                    if ($observation) {
                        if ($observations) $observations .= ' / '.$observation;
                        else $observations = $observation;
                    }
                    /* Notes du réalisé */
                    $annotation = '';
                    if (array_key_exists('rea_notes', $lu)) {
                        $annotation = trim($lu['rea_notes']);
                    }
                    $recent = souligne_rouge($lu['pln_timbre'], $un_mois, $aujourdhui);
                }

                /* contenu par défaut */
                $premier = ($lu['pro_premier'] == 't' and
                    $lu['pln_debut'] == $courant and
                    $lu['pln_debut'] != $lu['pln_fin']);
                $contenu = ($premier ? '!' : '');

                if ($realise and ($lu['rea_debut'] != null)) {

                    /* Présentation du réalisé en priorité */

                    /* Définition hors prévisionnel */
                    $hors_previsionnel = (($courant < $lu['pln_debut'] and $courant >= $lu['rea_debut']) or
                        ($courant > $lu['pln_fin'] and $courant <= $jour_iso and
                        ($courant <= $lu['fin_retenue'] or $lu['rea_fin'] == null)));

                    /* Présentation du réalisé en priorité */
                    if ($lu['rea_fin'] == null) {

                        /* Pas encore de date de fin */
                        if ($courant >= $lu['rea_debut'] and
                            $courant <= $jour_iso)
                            $cell->classe(($lu['rea_statut'] == 'A' ? 'abort' : 'encours'));

                        /* pastille noir, processus hors prévisionnel */
                        if ($hors_previsionnel)
                            $cell->pastille(SPPE_ETAT_TERMINE);

                    } else {

                        /* Présence d'une date de fin */
                        if ($hors_previsionnel) {

                            /* Hors période */
                        	if (($courant < $lu['pln_debut']) && ($courant >= $lu['rea_debut'])){
                        		$cell->classe('hors_delai_avant');
                        	}else{
                        		$cell->classe('hors_delai_apres');
                        	}

                        } else {

                            /* Dans les délais */
                            if ($courant <= $lu['rea_fin'] and $courant >= $lu['rea_debut']) {
                                $cell->classe(($lu['rea_statut'] == 'A' ? 'abort' :'termine'));
                            } else {
                                $raz = (($courant > $lu['rea_fin']) and ($lu['rea_statut'] == 'T'));
                            }
                        }
                        /* pastille rouge, processus terminés ayant connu un abort */
                        if ($courant == $lu['rea_fin'] and in_array($lu['pln_id'], $liste_abort))
                            $cell->pastille(SPPE_ETAT_ABORT);
                    }
                }

                /* Mise en évidence d'une information éventuelles */

                $prevision = (($courant >= $lu['pln_debut']) and ($courant <= $lu['pln_fin']));
                $reel = ($cell->etat() != '');

                if (($prevision or $reel) and ($raz == false)) {

                    /* Cellule en évidence */

                    /* Souligner en rouge les modifications récentes */
                    $cell->classe($recent);

                    /* Réalisé seulement */
                    if ($reel) {
                        if (bulle($observation, $annotation, $indice, $remarques)) {
                            $contenu = ($premier ? $contenu : '').'*'.$indice;
                            $cell->classe('cell_info');
                        }
                        $cell->fabrique($contenu, false);
                    } else {
                        /* Prévisions seulement (y compris dans le réalisé) */
                        if ($prevision) {
                            if ($lu['pln_suppr'] == 't') {
                                $cell->classe('supprime');
                                $cell->fabrique('X', false);
                            } else {
                                if ($lu['pln_confirm'] == 't') {
                                    if ($realise and $lu['pro_realise'] == 'f' and
                                        $lu['pln_fin'] < $jour_iso and
                                        $lu['rea_debut'] == null ) {
                                        $cell->classe('termine');
                                    } else {
                                        $cell->classe('sure'.$manuel[$lu['manuel']]);
                                    }
                                    if (bulle($observation, $annotation, $indice, $remarques)) {
                                        $contenu = ($premier ? $contenu : '').'*'.$indice;
                                        $cell->classe('cell_info');
                                    }
                                    $cell->fabrique($contenu, false);
                                } else {
                                    $cell->classe('pas_sure'.$manuel[$lu['manuel']]);
                                    $cell->fabrique(($premier ? $contenu : '?').'??', false);
                                }
                            }
                        }
                    }
                } else {

                    /* Processus pas au plan ou remis à blanc */
                    $cell->fabrique($contenu);
                }

                $cell->suivant();
            }

            if ($vue_semaine) {
                $pdf->SetFont('','',8);
                $pdf->SetTextColor(0,0,0);  // noir
                $borne = ($lu['pln_fin'] >= $fin ? jma($lu['pln_fin']) : '');
                $pdf->Cell(20,5,$borne,1,0,'C');
                $s = utf8_decode($observations);
                if ($pdf->GetStringWidth($s) > 70) {
                    $pdf->MultiCell(70,3.5,utf8_decode($observations),1);
                    $pdf->Ln(-5);
                } else {
                    $pdf->Cell(70,5,utf8_decode($observations),1);
                }
            }
        }
    } else {
        $pdf->Ln(5);
        $pdf->SetX(10);
        $pdf->SetTextColor(192,12,19);  // rouge
        $pdf->SetFont('','B',10);
        $pdf->Cell(277,10,
            utf8_decode('Aucune occurrence pour la période et les critères sélectionnés.'),1,1,'C');
    }

    /* Affichage des observations et des annotations */
    if ($remarques) {
        if ($pdf->GetY() > 184) {
            $pdf->AddPage();
        } else {
            $pdf->Ln(6);
        }
        $pdf->SetTextColor(0,0,0);  // noir
        $pdf->SetDrawColor(0,0,0);  // noir
        $pdf->SetLineWidth(0.1);
        $pdf->SetFont('Times','',8);
        $pdf->Cell(277,4,'Annotations','B');
        $pdf->Ln(4);
        foreach ($remarques as $clef => $rem) {
            $nbrc = strlen($rem) - strlen(preg_replace('/\r\n?/', '', $rem));
            /* Faut-il changer de page ? */
            if ($pdf->GetY()+$nbrc*3 > 190) $pdf->AddPage();
            $pdf->SetX(10);
            $pdf->Cell(7,4,'*'.($clef+1).' :',0,0,'R');
            $pdf->MultiCell(270,4,utf8_decode(trim($rem)));
        }
    }

    /* Liste détaillée des chaînes pour les processus où, dans le tableau, elles sont regroupées */
    if (count($chaines_fin) > 0) {
        if ($pdf->GetY() > 184) {
            $pdf->AddPage();
        } else {
            $pdf->Ln(6);
        }
        $pdf->SetFont('Arial','',8);
        foreach ($chaines_fin as $pro => $lst) {
            /* Faut-il changer de page ? */
            if ($pdf->GetY() > 190) $pdf->AddPage();
            $pdf->SetX(10);
            $pdf->MultiCell(277,4,utf8_decode($pro.' : '.$lst));
        }
    }
    affiche_selections($db, $pdf, $realise, 184);
?>
