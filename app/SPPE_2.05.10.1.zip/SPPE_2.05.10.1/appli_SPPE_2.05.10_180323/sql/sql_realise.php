<?php

/* sql_realise.php
 * Requêtes SQL du suivi du réalisé
 * JMD - 19 avril 2016
 */

/* Note : sauf précision contraire, toutes les fonctions retournent la ressource résultat */

/* existe_realise_supprime -------------------------------------------------------------------------
 * Retourne vrai si du réalisé a été supprimé manuellement
 * $id : identifiant de la mise au plan
 */
function sql_existe_realise_supprime($id) {
	$rc = false;
	$req = "SELECT COUNT(*) FROM jobs_archive WHERE pln_id=$1 AND esi_id=$2";
	$res = sql_gen($req, array($id, ($_SESSION['sel_esi'] ? $_SESSION['sel_esi'] : 1)));
	if ($res) {
		if ($lu = pg_fetch_row($res)){
			$rc = ($lu[0] > 0);
		}
	}
	return $rc;
}

/* sql_jobs ----------------------------------------------------------------------------------------
 * Liste des jobs d'une mise au plan et d'un ESI pour affichage
 * $id : identifiant de la mise au plan
 */
function sql_jobs($idPlan,$idProcessus) {
	$req = "SELECT m.mbx_id,j.job_id, m.mbx_nom, e.ent_code, COALESCE(j.job_etat, $3) as etat,
				((SELECT COUNT(k.*)
					FROM jobs k
					WHERE k.job_etat=$4 
					AND k.pln_id=$1
					AND k.mbx_id=j.mbx_id
					AND k.ent_id=j.ent_id)>0) as abort
			FROM membrex m
			LEFT JOIN jobs j ON m.mbx_id=j.mbx_id AND j.pln_id=$1
			JOIN liens l ON l.mbx_id=m.mbx_id
			JOIN processus p ON p.pro_id=l.pro_id AND p.pro_version=l.pro_version
			JOIN entites e ON e.ent_id=j.ent_id
			WHERE p.pro_id=$5
			AND j.job_dernier
			AND (j.esi_id=$2 OR j.esi_id IS NULL)
			ORDER BY l.lie_rang, e.ent_code";
	$prm = array($idPlan, ($_SESSION['sel_esi'] ? $_SESSION['sel_esi'] : 1), SPPE_ETAT_PREVU, SPPE_ETAT_ABORT, $idProcessus);
//     echo $req.'<hr/>'; var_dump($prm);exit;
	return sql_gen($req, $prm);
}

/* sql_lis_realise_manuel --------------------------------------------------------------------------
 * Lis le commentaire en présence de réalisé manuel
 * $id : identifiant de mise au plan
 * --> retourne la ressource
 */
function sql_lis_realise_manuel($id) {
	$req = "SELECT r.rea_notes, r.rea_timbre
			FROM realise r
			JOIN utilisateurs u ON u.uti_id=r.uti_id AND u.uti_uid_fonctionnel!='automate'
			WHERE r.pln_id=$1
			AND r.esi_id=$2";
	$res = sql_gen($req, array($id, ($_SESSION['sel_esi'] ? $_SESSION['sel_esi'] : 1)));
	return $res;
}

/* sql_liste_proc_abort ----------------------------------------------------------------------------
 * Liste les processus, concernés par la période donnée, qui ont connu un abort
 * $deb : début de la période
 * $fin : fin de la période
 * $esi : identifiant de l'ESI considéré
 * --> retourne un tableau des identifiants de mise au plan
 */
function sql_liste_proc_abort($deb, $fin, $esi) {
	$rc = array();
	$req = "SELECT distinct j.pln_id
			FROM jobs j
			JOIN plan p ON p.pln_id=j.pln_id
			JOIN entites e ON e.ent_id=j.ent_id
			WHERE j.job_etat=$3
			AND (j.esi_id=$4 OR j.esi_id is null)
			AND (
				((p.pln_debut >= $1) AND (p.pln_debut < $2))
				OR
				((p.pln_fin >= $1) AND (p.pln_fin < $2))
				OR
				((p.pln_debut < $1) AND (p.pln_fin >= $2))
				OR
				((j.job_debut >= $1) AND (j.job_debut < $2))
				OR
				((j.job_fin >= $1) AND (j.job_fin < $2))
				OR
				((j.job_debut < $1) AND (j.job_fin >= $2))
			)";
	$res = sql_gen($req, array($deb, $fin, SPPE_ETAT_ABORT, $esi));
	while ($lu = pg_fetch_row($res)) {
		array_push($rc, $lu[0]);
	}
	return $rc;
}

// fin
