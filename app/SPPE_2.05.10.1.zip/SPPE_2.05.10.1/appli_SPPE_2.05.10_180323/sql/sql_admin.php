<?php

/* sql_adminsi.php
 * Requêtes SQL administration SI
 * JMD - 11 février 2016
 */

/* Note : sauf précision contraire, toutes les fonctions retournent la ressource résultat */

/* sql_ajoute_equipe -------------------------------------------------------------------------------
 * Création d'une équipe
 * $nom : nom de l'équipe
 * $lib : libellé
 * $dom : identifiant du domaine
 * $act : actuelle
 */
// function sql_ajoute_equipe($nom, $lib, $dom, $act) {
//     $req = "insert into equipes
//         (eqp_nom, eqp_lib, dom_id, eqp_ok)
//         values ($1, $2, $3, $4)
//         returning eqp_id";
//     $prm = array($nom, $lib, $dom, $act);
//     return sql_gen($req, $prm);
// }

/* sql_existe_service -------------------------------------------------------------------------------
 * Vérifie l'existence d'un nom de service
 * 		$lib : libellé
 * 		$id : identifiant
 * --> retourne vrai si trouvé
 */
function sql_existe_service($nom, $id) {
    $res = sql_gen("SELECT COUNT(*)
    				FROM services
    				WHERE serv_nom ILIKE TRIM($1)
    				AND serv_id!=$2",array($nom, $id));
    $lu = pg_fetch_row($res);
    return ($lu[0] > 0);
}

/* sql_maj_appli -----------------------------------------------------------------------------------
 * Mise-à-jour d'une application
 * $app : identifiant de l'application
 * $lib : libellé
 * $dom : identifiant du domaine associé
 * $serv : identifiant du service responsable
 * $act : actuelle
 */
function sql_maj_appli($app, $lib, $dom, $serv, $act) {
    $req = "UPDATE applications SET
    		app_lib=$1,
    		dom_id=$2,
    		serv_id=$3,
    		app_ok=$4
    		WHERE app_id=$5";
    $prm = array($lib, ($dom == 0 ? null : $dom), ($serv== 0 ? null : $serv), $act, $app);
    return sql_gen($req, $prm);
}

/* sql_maj_equipe ------------------------------------------------------------------------------
 * Mise-à-jour d'une équipe
 * $id : identifiant de l'équipe
 * $nom : nom
 * $lib : libellé
 * $dom : identifiant du domaine associé
 * $act : actuelle
 */
// function sql_maj_equipe($id, $nom, $lib, $dom, $act) {
//     $req = "update equipes set eqp_nom=$1, eqp_lib=$2, dom_id=$3, eqp_ok=$4 where eqp_id=$5";
//     $prm = array($nom, $lib, $dom, $act, $id);
//     return sql_gen($req, $prm);
// }

/* sql_supprime_service -----------------------------------------------------------------------------
 * Inactive ou supprime un service
 * 		$id : identifiant
 * --> retourne I si l'équipe est inactivé, S supprimée ou E en cas d'erreur
 */
function sql_supprime_service($id) {
	$res = sql_gen('DELETE FROM attacher WHERE serv_id=$1',array($id));
    $res = sql_gen("SELECT 
    					(SELECT COUNT(*) FROM applications WHERE serv_id=$1)
    				+
    					(SELECT COUNT(*) FROM utilisateurs WHERE serv_id=$1)", array($id));
    $lu = pg_fetch_row($res);
    if ($lu[0]) {
        $rc = 'I';
        $res = sql_gen("UPDATE services SET serv_ok='f' WHERE serv_id=$1", array($id));
    } else {
        $rc = 'S';
        $res = sql_gen("DELETE FROM services WHERE serv_id=$1", array($id));
    }
    if ($res === false){
    	$rc = false;
    }
    return $rc;
}
/* sql_lis_domainesService --------------------------------------------------------------------------------
 * Requiert tous les domaines
 * $actuel : limite éventuellement aux domaines actuels si vrai
 */
function sql_lis_domainesService($idService) {
	$req = "SELECT d.dom_id, d.dom_nom, a.profil
    		FROM domaines d
    		LEFT JOIN attacher a ON d.dom_id=a.dom_id
    		WHERE a.serv_id=".$idService;
	return sql_gen($req);
}
/* sql_lis_habilitationUtilisateur --------------------------------------------------------------------------------
 * Requiert tous les domaines
 * $actuel : limite éventuellement aux domaines actuels si vrai
 */
function sql_lis_habilitationUtilisateur($idUtilisateur) {
	$req = "SELECT dom_id, habilitation
    		FROM habiliter
    		WHERE uti_id=".$idUtilisateur;
	return sql_gen($req);
}

/* sql_delete_profil --------------------------------------------------------------------------------
 * Reinitialise les profils d'un service à 0
 * 		$idService : identifiant du service
 */
function sql_delete_profil($idService){
	$req = 'UPDATE attacher SET
			profil=0
			WHERE serv_id='.$idService;
	
	sql_gen($req);
}

/* sql_delete_habilitation --------------------------------------------------------------------------------
 * Supprime les habilitations d'un utilisateur
 * 		$idUtilisateur : identifiant de l'utilisateur
 */
function sql_delete_habilitation($idUtilisateur){
	$req = 'DELETE FROM habiliter WHERE uti_id='.$idUtilisateur;
	
	sql_gen($req);
}
/* sql_maj_profil --------------------------------------------------------------------------------
 * Modifie la valeur d'un profil
 * 		$idService 	: identifiant du service
 * 		$idDomaine 	: identifiant du domaine
 * 		$valeur 	: nouvelle valeur du profil
 */
function sql_maj_profil($idService, $idDomaine, $valeur){
	$req = 'UPDATE attacher SET
			profil=$3
			WHERE serv_id=$1 AND dom_id=$2';
	
	return sql_gen($req,array($idService, $idDomaine, $valeur));
	
}
/* sql_maj_habilitation --------------------------------------------------------------------------------
 * Modifie la valeur d'une habilitation d'un utilisateur
 * 		$idUtilisateur 	: identifiant du service
 * 		$idDomaine 		: identifiant du domaine
 * 		$valeur 		: nouvelle valeur du profil
 */
function sql_maj_habilitation($idUtilisateur, $idDomaine, $valeur){
	$req = 'SELECT COUNT(*) as habil FROM habiliter WHERE uti_id=$1 AND dom_id=$2';
	$res = sql_gen($req, array($idUtilisateur,$idDomaine));
	$lu = pg_fetch_assoc($res);
	if ($lu['habil']==0){
		$req = 'INSERT INTO habiliter
					(uti_id,dom_id,habilitation)
				VALUES
					($1,$2,$3)';
	}else{
		$req = 'UPDATE habiliter SET
				habilitation=$3
				WHERE uti_id=$1 AND dom_id=$2';
	}
	
	return sql_gen($req,array($idUtilisateur, $idDomaine, $valeur));
	
}
// fin
