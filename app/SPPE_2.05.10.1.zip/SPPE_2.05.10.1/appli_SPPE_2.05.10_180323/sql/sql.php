<?php

/* sql.php
 * Requêtes SQL partagées
 * JMD - 11 février 2016
 */

/* Note : sauf précision contraire, toutes les fonctions retournent la ressource résultat */

/* sql_gen -----------------------------------------------------------------------------------------
 * Requête SQL générique
 * $req : requête SQL
 * $prm : tableau des paramètres
 * $debug : mode debug si vrai
 */
function sql_gen($req, $prm=array(), $debug=false) {

    global $db;

    if (count($prm)) {
        $res = pg_query_params($db, $req, $prm);
    } else {
        $res = pg_query($db, $req);
    }

    if ((SPPE_MODE_DEBUG and $res === false) or $debug) {
        echo '<div style="font-size:0.9em;color:blue;padding:1em;">';
        $dgt = debug_backtrace();
        echo $dgt[1]['file'].' ('
            .$dgt[1]['line'].') --- '
            .$dgt[1]['function'];
        echo "<br><br>";
        echo pg_last_error($db);
        echo "<br><br>";
        echo $req;
        echo "<br><br>";
        var_dump($prm);
        echo "</div>";
        exit;
    }
    return $res;
}

/* sql_lis_applis ----------------------------------------------------------------------------------
 * Requiert toutes les applications
 * $actuel : limite éventuellement aux applications actuelles si vrai
 */
function sql_lis_applis($actuel=false) {
    $req = "SELECT app_id, app_nom, coalesce(app_lib,'') as app_lib,COALESCE(dom_id,0) as dom_id, COALESCE(serv_id,0) as serv_id, app_ok
    		FROM applications "
        .($actuel ? 'WHERE app_ok' : '')
        ." ORDER BY app_nom";
    return sql_gen($req);
}

/* sql_lis_services --------------------------------------------------------------------------------
 * Requiert tous les services
 * $actuel : limite éventuellement aux services actuels si vrai
 * $idService : restreint au service qui a pour id idService
 */
function sql_lis_services($actuel=false,$idService=NULL) {
    $req = "SELECT serv_id, serv_nom, serv_ok, esi_id
    		FROM services
    		WHERE 1=1  "
        .($actuel ? 'AND serv_ok' : '')
        .(is_null($idService)?'':'AND serv_id='.$idService)
        ." ORDER BY serv_nom";
    return sql_gen($req);
}
/* sql_lis_domaines --------------------------------------------------------------------------------
 * Requiert tous les domaines
 * $actuel : limite éventuellement aux domaines actuels si vrai
 */
function sql_lis_domaines($actuel=false) {
    $req = "SELECT dom_id, dom_nom, COALESCE(dom_lib,'') as dom_lib, dom_ok
    		FROM domaines "
        .($actuel ? 'WHERE dom_ok' : '')
        ." ORDER BY dom_nom";
    return sql_gen($req);
}

/* sql_lis_equipes ---------------------------------------------------------------------------------
 * Requiert toutes les équipes
 * $actuel : limite éventuellement aux équipes actuelles si vrai
 * $id : limite éventuellement à un identifiant donné
 */
// function sql_lis_equipes($actuel=false, $id=null) {
//     $req = "select e.eqp_id, e.eqp_nom, coalesce(e.eqp_lib,'') as eqp_lib,
//             coalesce(e.dom_id,0) as dom_id, e.eqp_ok, d.dom_nom, d.dom_lib, d.dom_ok
//         from equipes e left outer join domaines d on d.dom_id=e.dom_id
//         where 1=1 "
//         .($actuel ? ' and e.eqp_ok' : '')
//         .(is_null($id) ? ' ' : ' and e.eqp_id='.$id)
//         ." order by e.eqp_nom";
//     return sql_gen($req);
// }

/* sql_lis_job -------------------------------------------------------------------------------------
 * Lecture d'un job en détail
 * $id : identifiant du job
 */
function sql_lis_job($id) {
    $req = "select m.mbx_nom, e.ent_code,
            to_char(k.job_debut, 'le DD/MM/YYYY à HH24:MI') as job_debut,
            to_char(k.job_fin, 'le DD/MM/YYYY à HH24:MI') as job_fin,
            k.job_etat, k.job_ron,
            (k.job_fin-k.job_debut) as temps
        from jobs j
            join membrex m on m.mbx_id=j.mbx_id
            join entites e on e.ent_id=j.ent_id
            join jobs k on k.mbx_id=j.mbx_id and k.ent_id=j.ent_id and k.pln_id=j.pln_id
        where
            j.job_id=$1
        order by
            k.job_debut";
    return sql_gen($req, array($id));
}

/* sql_lis_steps -----------------------------------------------------------------------------------
 * Lecture des steps d'un job
 * $id : identifiant du job
 */
function sql_lis_steps($id) {
    $req = "select m.mbx_nom, e.ent_code, k.job_ron,
            s.stp_lib, s.stp_etat,
            to_char(s.stp_debut, 'DD/MM/YYYY HH24:MI') as stp_debut,
            to_char(s.stp_fin, 'DD/MM/YYYY HH24:MI') as stp_fin,
            s.stp_elapsed, s.stp_cpu
        from jobs j
            join membrex m on m.mbx_id=j.mbx_id
            join entites e on e.ent_id=j.ent_id
            join jobs k on k.mbx_id=j.mbx_id and k.ent_id=j.ent_id and k.pln_id=j.pln_id
            join steps s on s.job_id=k.job_id
        where
            j.job_id=$1
        order by
            k.job_debut, s.stp_debut";
    return sql_gen($req, array($id));
}

/* sql_touche_processus ----------------------------------------------------------------------------
 * Actualise l'horodatage du processus transmis en paramètre
 * $id : identifiant du processus
 * $pl : identifiant de mise au plan (utilisée quand id=0)
 */
function sql_touche_processus($id, $pl=null) {
    if ($id > 0) {
        $req = "update processus set pro_timbre=current_timestamp where pro_id=$1";
        $prm = array($id);
    } else {
        $req = "update processus set pro_timbre=current_timestamp
            where pro_id=(select pro_id from plan where pln_id=$1)";
        $prm = array($pl);
    }
    return sql_gen($req, $prm);
}

// fin
