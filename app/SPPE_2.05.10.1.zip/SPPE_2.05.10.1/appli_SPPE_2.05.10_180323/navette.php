<?php

    /* Ouvre le fichier navette */
    $nom = 'fiche_navette.ods';
    $source = 'lo/navette.ods';
    header('Content-Disposition: attachment; filename='.$nom);
    header('Content-Type: application/vnd.oasis.opendocument.spreadsheet' );
    readfile($source);

?>
